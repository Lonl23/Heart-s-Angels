import{i as fe,r as c,j as e,L as te}from"./vendor-react-y2xUrN8v.js";import{u as me,s as x,r as P,n as xe,k as T,E as ge,_ as be,e as ve,c as je}from"./index-BgI-Ldt0.js";import{f as ke,s as Ne,e as we,g as ye,l as ie,h as L,a as B,C as _e}from"./activitesSecours-DKvntiCE.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function g(r){return String(r).padStart(2,"0")}function N(r){const t=new Date(r);return Number.isNaN(t.getTime())?"":`${g(t.getDate())}-${g(t.getMonth()+1)}-${t.getFullYear()}`}function R(r){const t=new Date(r);return Number.isNaN(t.getTime())?"":`${g(t.getHours())}:${g(t.getMinutes())}`}function re(r){const t=new Date(r);return Number.isNaN(t.getTime())?"":`${t.getFullYear()}-${g(t.getMonth()+1)}-${g(t.getDate())}`}function I(r){return r?`${N(r)} ${R(r)}`:""}function Pe(){var ae;const{id:r}=fe(),{profile:t}=me(),[a,d]=c.useState(null),[b,O]=c.useState([]),[H,Q]=c.useState([]),[q,se]=c.useState(null),[w,U]=c.useState("info"),[ne,v]=c.useState(!0),[G,V]=c.useState(!1),[y,_]=c.useState(null),[Y,J]=c.useState(null),[j,K]=c.useState(!1),[A,ce]=c.useState(""),[F,oe]=c.useState("");c.useEffect(()=>{W()},[r,t==null?void 0:t.id]);async function W(i=!1){i||v(!0),_(null),V(!1);const o=await x.from("activites_secours").select("id,numero,titre,type,lieu,debut,fin,places,competences,created_by,created_at").eq("id",r).maybeSingle();if(o.error){_(o.error.message||"Chargement impossible."),i||d(null),v(!1);return}if(!o.data){V(!0),d(null),v(!1);return}const n=await x.from("activites_secours_inscrits").select("id,user_id,created_at").eq("activite_id",r);if(n.error){_(n.error.message||"Chargement des inscriptions impossible."),d(o.data),O([]),Q([]),v(!1);return}const s=n.data||[],m=[...new Set(s.map(h=>h.user_id).filter(Boolean))];let k=[];if(m.length){const h=await x.from("profiles").select("id,prenom,nom,role,fiche").in("id",m);h.error?_(h.error.message||"Chargement du personnel impossible."):k=h.data||[]}let E=null;if(o.data.created_by){const h=await x.from("profiles").select("id,prenom,nom").eq("id",o.data.created_by).maybeSingle();h.error||(E=h.data)}d(o.data),O(s),Q(k),se(E),v(!1)}const X=c.useMemo(()=>ke(t),[t]),z=b.some(i=>i.user_id===(t==null?void 0:t.id)),p=Number(a==null?void 0:a.places)||0,u=b.length,C=a?Ne(a):"a_venir",le=a?we(a):!1,he=p>0&&u>=p,f=Array.isArray(a==null?void 0:a.competences)?a.competences:[],$=a?ye(a):null,de=a&&re(a.debut)===re(a.fin||a.debut),Z=c.useMemo(()=>{const i=new Map(H.map(n=>[n.id,n])),o=F.trim().toLowerCase();return b.map(n=>{const s=i.get(n.user_id),m=(s==null?void 0:s.fiche)||{},k=Array.isArray(m.qualifications)?m.qualifications:[],E=f.some(h=>k.includes(h)||Ae(h,s));return{id:n.user_id,inscription:n.created_at,prenom:(s==null?void 0:s.prenom)||"",nom:(s==null?void 0:s.nom)||"",photo:m.photo_url||"",role:(s==null?void 0:s.role)||"",quals:k,manque:f.length>0&&!E}}).filter(n=>A&&!n.quals.includes(A)?!1:o?`${n.prenom} ${n.nom}`.toLowerCase().includes(o):!0).sort((n,s)=>`${n.nom} ${n.prenom}`.localeCompare(`${s.nom} ${s.prenom}`,"fr"))},[b,H,F,A,f]);async function ee(){if(!(t!=null&&t.id)||!a||j)return;K(!0),J(null);const i=z?await x.from("activites_secours_inscrits").delete().eq("activite_id",a.id).eq("user_id",t.id):await x.from("activites_secours_inscrits").insert({activite_id:a.id,user_id:t.id});i.error?J(i.error.message||"Inscription impossible."):await W(!0),K(!1)}let S="S’inscrire",D=!1;z?S="Se désinscrire":le?he&&(S="Complet",D=!0):(S="Terminée",D=!0);const ue=((ae=be.organisation)==null?void 0:ae.nom)||"Heart’s Angels ASBL",pe=a!=null&&a.lieu?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.lieu)}`:"";return ne?e.jsx(P,{title:"Activité",children:e.jsx(xe,{})}):a?e.jsxs(P,{children:[e.jsx("style",{children:Se}),y&&e.jsx(T,{kind:"err",children:y}),Y&&e.jsx(T,{kind:"err",children:Y}),e.jsxs("div",{className:"ha-afiche",children:[e.jsxs("header",{className:"ha-afiche-head",children:[e.jsxs("div",{className:"ha-afiche-top",children:[e.jsxs("div",{children:[e.jsx(te,{to:"/app/secours/activites",className:"ha-afiche-retour",children:"Activités"}),e.jsx("p",{className:"ha-afiche-type",children:ie(a.type)}),e.jsx("h1",{children:a.titre}),e.jsxs("p",{className:"ha-afiche-quand",children:[de?N(a.debut):`du ${N(a.debut)} au ${N(a.fin||a.debut)}`," · ",R(a.debut),a.fin?` – ${R(a.fin)}`:"",$?` (${$})`:""]})]}),e.jsx("span",{className:"ha-afiche-etat is-"+C,children:L(C)})]}),e.jsxs("div",{className:"ha-afiche-chiffres",children:[e.jsx(M,{label:"Personnel inscrit",valeur:u}),e.jsx(M,{label:"Places",valeur:`${u} / ${p}`}),e.jsx(M,{label:"Durée",valeur:$||"—"})]})]}),e.jsxs("nav",{className:"ha-afiche-onglets","aria-label":"Fiche de l’activité",children:[e.jsx("button",{type:"button",className:w==="info"?"is-on":"",onClick:()=>U("info"),children:"Information"}),e.jsxs("button",{type:"button",className:w==="personnel"?"is-on":"",onClick:()=>U("personnel"),children:["Personnel",u?` ${u}`:""]})]}),w==="info"&&e.jsxs("div",{className:"ha-afiche-grille",children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Détails de l’activité"}),e.jsx("p",{className:"ha-afiche-sec",children:"Identité"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(l,{k:"N°",v:a.numero??"—"}),e.jsx(l,{k:"Statut",v:L(C)}),e.jsx(l,{k:"Type",v:ie(a.type)}),e.jsx(l,{k:"Nom",v:a.titre})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Organisation"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(l,{k:"Organisée par",v:ue}),e.jsx(l,{k:"Créée par",v:q?`${q.prenom||""} ${q.nom||""}`.trim():"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Date et horaires"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(l,{k:"Début",v:I(a.debut)}),e.jsx(l,{k:"Fin",v:a.fin?I(a.fin):"—"}),e.jsx(l,{k:"Durée",v:$||"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Suivi"}),e.jsx(l,{k:"Créée le",v:I(a.created_at)||"—"})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Inscription"}),e.jsx("p",{className:"ha-afiche-sec",children:"État"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(l,{k:"Statut",v:L(C)}),e.jsx(l,{k:"Places",v:p?`${Math.max(p-u,0)} libre${p-u>1?"s":""}`:"—"}),e.jsx(l,{k:"Qui peut s’inscrire",v:"Personnel de l’association"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Compétences demandées"}),f.length===0?e.jsx("p",{className:"ha-afiche-vide",children:"Aucune compétence exigée."}):e.jsx("div",{className:"ha-afiche-chips",children:f.map(i=>e.jsxs("span",{className:"ha-act-chip"+(X.has(i)?" is-moi":" is-autre"),children:[X.has(i)?"✓":"•"," ",B(i)]},i))}),e.jsx("div",{style:{marginTop:14},children:e.jsx(ve,{onClick:ee,disabled:D||j,kind:z?"danger":"primary",children:j?"…":S})})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Lieu"}),a.lieu?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-lieu",children:a.lieu}),e.jsx("a",{className:"ha-afiche-maps",href:pe,target:"_blank",rel:"noreferrer",children:"Ouvrir dans Google Maps"})]}):e.jsx("p",{className:"ha-afiche-vide",children:"Aucun lieu renseigné."})]})]}),w==="personnel"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsxs("div",{className:"ha-afiche-outils",children:[e.jsxs("select",{"aria-label":"Compétence",value:A,onChange:i=>ce(i.target.value),children:[e.jsx("option",{value:"",children:"Toutes les compétences"}),_e.filter(i=>i.v!=="medical"&&i.v!=="non_medical").map(i=>e.jsx("option",{value:i.v,children:i.l},i.v))]}),e.jsx("input",{type:"search",placeholder:"Rechercher","aria-label":"Rechercher une personne",value:F,onChange:i=>oe(i.target.value)})]}),Z.length===0?e.jsx("p",{className:"ha-afiche-vide",children:b.length===0?"Personne n’est inscrit pour le moment.":"Aucune personne ne correspond."}):e.jsx("div",{className:"ha-afiche-table-wrap",children:e.jsxs("table",{className:"ha-afiche-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Photo"}),e.jsx("th",{children:"Personnel"}),e.jsx("th",{children:"Fonction"}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:Z.map(i=>e.jsxs("tr",{className:i.manque?"is-manque":void 0,children:[e.jsx("td",{children:e.jsx($e,{url:i.photo,prenom:i.prenom,nom:i.nom})}),e.jsxs("td",{children:[e.jsx("strong",{children:`${i.prenom} ${i.nom}`.trim()||"Compte retiré"}),e.jsx("span",{className:"ha-afiche-sous",children:N(i.inscription)})]}),e.jsx("td",{children:Ce(i)}),e.jsx("td",{children:i.quals.length===0?e.jsx("span",{className:"ha-afiche-vide",children:"—"}):i.quals.map(o=>e.jsx("span",{className:"ha-act-chip"+(f.includes(o)?" is-moi":""),children:B(o)},o))}),e.jsx("td",{children:i.id===(t==null?void 0:t.id)&&e.jsx("button",{type:"button",className:"ha-afiche-moi",onClick:ee,disabled:j,children:j?"…":"Se désinscrire"})})]},i.id))})]})})]})]})]}):e.jsxs(P,{title:"Activité",children:[y&&e.jsx(T,{kind:"err",children:y}),e.jsx(ge,{title:G?"Activité introuvable":"Activité indisponible",hint:G?"Elle a été retirée, ou le lien ne correspond à rien.":"Le chargement a échoué.",action:e.jsx(te,{to:"/app/secours/activites",children:"Retour aux activités"})})]})}function Ae(r,t){var a,d;return t?r==="medical"?((a=t.fiche)==null?void 0:a.type_benevole)==="medical"||t.role==="volontaire_medical":r==="non_medical"?((d=t.fiche)==null?void 0:d.type_benevole)==="non_medical"||t.role==="volontaire_non_medical":!1:!1}function Ce(r){const t=r.quals.find(a=>a!=="autre")||r.quals[0];return t?B(t):r.role?je(r.role):"—"}function l({k:r,v:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:r}),e.jsx("div",{className:"ha-afiche-v",children:t||"—"})]})}function M({label:r,valeur:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:r}),e.jsx("div",{className:"ha-afiche-nb",children:t})]})}function $e({url:r,prenom:t,nom:a}){const d=`${(t||"").charAt(0)}${(a||"").charAt(0)}`.toUpperCase()||"?";return e.jsx("span",{className:"ha-afiche-photo",children:r?e.jsx("img",{src:r,alt:""}):e.jsx("span",{children:d})})}const Se=`
.ha-afiche { display: flex; flex-direction: column; gap: 12px; }
.ha-afiche-head, .ha-afiche-carte {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 14px 16px 12px;
}
.ha-afiche-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.ha-afiche-retour { font-size: 12.5px; font-weight: 700; color: var(--accent); text-decoration: none; }
.ha-afiche-type { margin: 6px 0 0; font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche h1 { margin: 2px 0 0; font-size: 1.35rem; color: var(--heading); line-height: 1.2; }
.ha-afiche-quand { margin: 4px 0 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-etat {
  flex: none;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
}
.ha-afiche-etat.is-a_venir { background: #E6F1FB; color: #185FA5; }
.ha-afiche-etat.is-en_cours { background: #E7F6EE; color: #1E7A45; }
.ha-afiche-etat.is-terminee { background: var(--bg-alt); color: var(--text-muted); }
.ha-afiche-chiffres {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.ha-afiche-nb { font-size: 1.35rem; font-weight: 700; color: var(--heading); font-variant-numeric: tabular-nums; }
.ha-afiche-onglets { display: flex; gap: 6px; border-bottom: 1px solid var(--border); }
.ha-afiche-onglets button {
  border: none;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-weight: 700;
  font-size: 14px;
  padding: 8px 12px 10px;
  border-bottom: 2px solid transparent;
  cursor: pointer;
}
.ha-afiche-onglets button.is-on { color: var(--accent-blue); border-bottom-color: var(--accent); }
.ha-afiche-grille {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr) minmax(220px, .8fr);
  gap: 12px;
  align-items: start;
}
.ha-afiche-carte h2 { margin: 0; font-size: 1rem; color: var(--heading); }
.ha-afiche-sec {
  margin: 14px 0 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ha-afiche-kv { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.ha-afiche-k { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche-v { margin-top: 2px; font-size: 14px; font-weight: 650; color: var(--text); }
.ha-afiche-vide { margin: 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-lieu { margin: 8px 0; font-weight: 700; color: var(--heading); }
.ha-afiche-maps { color: var(--accent); font-weight: 700; font-size: 13px; }
.ha-afiche-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.ha-act-chip {
  display: inline-flex; align-items: center; gap: 4px;
  margin: 2px 4px 2px 0; padding: 2px 8px; border-radius: 999px;
  font-size: 11.5px; font-weight: 700; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--text-2); white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-afiche-outils { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.ha-afiche-outils select, .ha-afiche-outils input {
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font: inherit; font-size: 13px; padding: 7px 10px;
}
.ha-afiche-outils input { margin-left: auto; min-width: min(240px, 70vw); }
.ha-afiche-table-wrap { overflow: auto; }
.ha-afiche-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 640px; }
.ha-afiche-table th {
  text-align: left; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  color: var(--text-muted); font-weight: 700; padding: 8px 10px; border-bottom: 1px solid var(--border);
}
.ha-afiche-table td { padding: 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.ha-afiche-table tr.is-manque td { background: #fff6f6; }
.ha-afiche-table td strong { display: block; color: var(--accent-blue); }
.ha-afiche-sous { display: block; color: var(--text-muted); font-size: 12px; font-weight: 500; }
.ha-afiche-photo {
  width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
  display: grid; place-items: center; background: var(--accent); color: #fff; font-weight: 700; font-size: 12px;
}
.ha-afiche-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ha-afiche-moi {
  border: 1px solid var(--border); background: var(--card); color: #A32D2D;
  border-radius: 8px; padding: 5px 8px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
}
[data-theme="dark"] .ha-afiche-etat.is-a_venir { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-afiche-etat.is-en_cours { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-afiche-table tr.is-manque td { background: rgba(163,45,45,.16); }
[data-theme="dark"] .ha-afiche-onglets button.is-on,
[data-theme="dark"] .ha-afiche-table td strong { color: var(--heading); }
[data-theme="dark"] .ha-afiche-moi { color: #F0A0A0; }
@media (max-width: 980px) {
  .ha-afiche-grille { grid-template-columns: 1fr; }
  .ha-afiche-chiffres { grid-template-columns: 1fr; }
  .ha-afiche-outils input { margin-left: 0; width: 100%; }
}
`;export{Pe as default};
