import{r as l,j as t,L as ke}from"./vendor-react-y2xUrN8v.js";import{u as we,s as k,r as Ce,k as Z,o as Ae,q as N,e as _,n as Ne,E as ee}from"./index-DktHEao-.js";import{p as Se,c as Ee,e as V,r as De,d as qe,C as te,T as W,D as Fe,s as O,l as $e,a as z,b as Ie,f as _e,g as ze,h as U,i as re,j as Le}from"./activitesSecours-DbORx6Jf.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const Me={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",dispositifs:[],competences:[]};function m(r){return String(r).padStart(2,"0")}function J(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${i.getFullYear()}-${m(i.getMonth()+1)}-${m(i.getDate())}`}function ie(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${m(i.getDate())}-${m(i.getMonth()+1)}-${i.getFullYear()}`}function Y(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${m(i.getHours())}:${m(i.getMinutes())}`}function Te(r){const i=ie(r.debut),d=Y(r.debut);if(!r.fin)return{date:i,heures:d};const x=J(r.debut)===J(r.fin)?Y(r.fin):`${ie(r.fin)} ${Y(r.fin)}`;return{date:i,heures:d&&x?`${d}–${x}`:d}}function ae(r){if(!r)return"";const i=new Date(r);return Number.isNaN(i.getTime())?"":`${i.getFullYear()}-${m(i.getMonth()+1)}-${m(i.getDate())}T${m(i.getHours())}:${m(i.getMinutes())}`}function se(r){if(!r)return null;const i=new Date(r);return Number.isNaN(i.getTime())?null:i.toISOString()}function ne(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Be(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Pe(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Je(){const{profile:r}=we(),i=Se(r),[d,b]=l.useState([]),[x,E]=l.useState([]),[w,Q]=l.useState(!0),[G,L]=l.useState(null),[K,u]=l.useState(null),[g,oe]=l.useState(null),[D,ce]=l.useState(""),[q,le]=l.useState(""),[F,de]=l.useState(""),[M,ue]=l.useState(""),[T,pe]=l.useState("asc"),[B,P]=l.useState(null),[n,f]=l.useState(null),[S,$]=l.useState(!1);l.useEffect(()=>{I()},[r==null?void 0:r.id]);async function I(e=!1){var c,o;e||Q(!0),L(null);const[a,s]=await Promise.all([k.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),k.from("activites_secours_inscrits").select("id,activite_id,user_id")]);a.error||s.error?(L(((c=a.error)==null?void 0:c.message)||((o=s.error)==null?void 0:o.message)||"Chargement impossible."),b([]),E([])):(b(Array.isArray(a.data)?a.data:[]),E(Array.isArray(s.data)?s.data:[])),Q(!1)}const p=l.useMemo(()=>Ee(d,x,r),[d,x,r]),X=l.useMemo(()=>{const e=M.trim().toLowerCase(),a=d.filter(s=>{const c=p.nombres.get(s.id)||0;if(g==="possible"&&!(V(s)&&c<Number(s.places)&&!p.miennes.has(s.id))||g==="competence"&&!(V(s)&&De(s,p.mes))||g==="bientot"&&!qe(s.debut)||D&&!(s.competences||[]).includes(D))return!1;const o=J(s.debut);return!(q&&o&&o<q||F&&o&&o>F||e&&!`${s.numero||""} ${s.titre||""} ${s.lieu||""}`.toLowerCase().includes(e))});return a.sort((s,c)=>{const o=String(s.debut).localeCompare(String(c.debut));return T==="asc"?o:-o}),a},[d,p,g,D,q,F,M,T]);function R(e){oe(a=>a===e?null:e)}async function he(e){if(!(r!=null&&r.id)||B)return;P(e.id),u(null);const a=p.miennes.has(e.id);if(!a&&ze(r,e)){u("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),P(null);return}const s=a?await k.from("activites_secours_inscrits").delete().eq("activite_id",e.id).eq("user_id",r.id):await k.from("activites_secours_inscrits").insert({activite_id:e.id,user_id:r.id});s.error?u(s.error.message||"Inscription impossible."):await I(!0),P(null)}function me(){L(null),f({...Me,competences:[]})}function xe(e){const a=z(e);f({id:e.id,titre:e.titre||"",type:W.some(s=>s.v===e.type)?e.type:"activite",lieu:e.lieu||"",debut:ae(e.debut),fin:ae(e.fin),places:String(e.places??1),publicAttendu:e.public_attendu==null?"":String(e.public_attendu),dispositifs:a,competences:U(e.competences)})}function v(e){f(a=>({...a,...e}))}function be(e){re.has(e)&&f(a=>{const c=a.dispositifs.includes(e)?a.dispositifs.filter(j=>j!==e):[...a.dispositifs,e],o=O(c);return{...a,dispositifs:c,places:o?o.places:a.places,competences:o?U(o.competences):a.competences}})}function fe(e){f(a=>{const s=a.competences.includes(e)?a.competences.filter(c=>c!==e):[...a.competences,e];return{...a,competences:s}})}async function ge(e){if(e.preventDefault(),!n||S)return;const a=n.titre.trim(),s=se(n.debut),c=se(n.fin),o=Number(n.places);if(!a){u("Indiquez le titre.");return}if(!s){u("Indiquez le début.");return}if(n.fin&&!c){u("La fin est illisible.");return}if(c&&c<s){u("La fin est avant le début.");return}if(!Number.isInteger(o)||o<1||o>500){u("Le nombre de places doit être entre 1 et 500.");return}const j=Le(n.publicAttendu);if(j===void 0){u("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}const C=z(n.dispositifs);if((n.dispositifs||[]).some(h=>!re.has(h))){u("Une des équipes est inconnue.");return}$(!0),u(null);const y={titre:a,type:W.some(h=>h.v===n.type)?n.type:"activite",dispositifs:C,dispositif:C[0]||null,public_attendu:j,lieu:n.lieu.trim()||null,debut:s,fin:c,places:o,competences:U(n.competences)},A=n.id?await k.from("activites_secours").update(y).eq("id",n.id):await k.from("activites_secours").insert({...y,created_by:(r==null?void 0:r.id)||null});A.error?u(A.error.message||"Enregistrement impossible."):(f(null),await I(!0)),$(!1)}async function ve(e){if(!e||S||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;$(!0),u(null);const a=await k.from("activites_secours").delete().eq("id",e);a.error?u(a.error.message||"Suppression impossible."):(f(null),await I(!0)),$(!1)}const je=!w&&d.length===0,ye=!w&&d.length>0&&X.length===0;return t.jsxs(Ce,{title:"Activités",subtitle:"Département secours. Une activité se dimensionne, s’arme, puis se rend en bilan.",action:i?t.jsx(_,{onClick:me,children:"+ Activité"}):null,children:[t.jsx("style",{children:Ve}),G&&t.jsx(Z,{kind:"err",children:G}),K&&t.jsx(Z,{kind:"err",children:K}),t.jsxs("div",{className:"ha-act-cartes",children:[t.jsx(H,{tone:"possible",on:g==="possible",n:w?"…":p.possible,label:"Inscription possible",icone:t.jsx(ne,{}),onClick:()=>R("possible")}),t.jsx(H,{tone:"competence",on:g==="competence",n:w?"…":p.competence,label:"Requiert ma compétence",icone:t.jsx(Be,{}),onClick:()=>R("competence")}),t.jsx(H,{tone:"bientot",on:g==="bientot",n:w?"…":p.bientot,label:"Sur les 30 prochains jours",icone:t.jsx(Pe,{}),onClick:()=>R("bientot")})]}),t.jsxs("div",{className:"ha-act-filtres",children:[t.jsxs("select",{"aria-label":"Compétence",value:D,onChange:e=>ce(e.target.value),children:[t.jsx("option",{value:"",children:"Toutes les activités"}),te.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))]}),t.jsxs("label",{className:"ha-act-dates",children:[t.jsx("span",{className:"ha-sr",children:"Du"}),t.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:q,onChange:e=>le(e.target.value)}),t.jsx("span",{children:"au"}),t.jsx("span",{className:"ha-sr",children:"Au"}),t.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:F,onChange:e=>de(e.target.value)})]}),t.jsxs("label",{className:"ha-act-recherche",children:[t.jsx("span",{className:"ha-sr",children:"Rechercher"}),t.jsx("input",{type:"search",placeholder:"Rechercher",value:M,onChange:e=>ue(e.target.value)})]})]}),n&&t.jsx(Ae,{style:{marginBottom:14},children:t.jsxs("form",{onSubmit:ge,children:[t.jsxs("div",{className:"ha-act-form",children:[t.jsx(N,{label:"Titre",value:n.titre,set:e=>v({titre:e}),required:!0}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),t.jsx("select",{value:n.type,onChange:e=>v({type:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:W.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))})]}),t.jsx(N,{label:"Lieu",value:n.lieu,set:e=>v({lieu:e})}),t.jsx(N,{label:"Début",type:"datetime-local",value:n.debut,set:e=>v({debut:e}),required:!0}),t.jsx(N,{label:"Fin",type:"datetime-local",value:n.fin,set:e=>v({fin:e})}),t.jsx(N,{label:"Places",type:"number",value:n.places,set:e=>v({places:e}),required:!0}),t.jsx(N,{label:"Public attendu",type:"number",value:n.publicAttendu,set:e=>v({publicAttendu:e})}),t.jsxs("div",{style:{marginBottom:10},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Équipes / dispositifs"}),t.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Équipes du préventif",children:Fe.map(e=>t.jsx("button",{type:"button",className:"ha-act-choix-btn"+(n.dispositifs.includes(e.v)?" is-on":""),"aria-pressed":n.dispositifs.includes(e.v),onClick:()=>be(e.v),children:e.court},e.v))})]})]}),n.dispositifs.length>0&&O(n.dispositifs)&&t.jsxs("p",{className:"ha-act-note",style:{color:"var(--heading)"},children:["Effectif minimum : ",O(n.dispositifs).resume,". Places et compétences sont préremplies — vous pouvez encore les ajuster."]}),t.jsx("p",{className:"ha-act-note",children:"Un préventif peut combiner plusieurs équipes (AMBU, PMA, PAPS, Écho…). Le type n’est pas calculé à partir du public. Matrices = département secours uniquement (pas les souhaits). « Secouriste minimum » suit l’ordre des qualifications (1→7)."}),t.jsxs("div",{style:{marginBottom:8},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),t.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:te.map(e=>t.jsx("button",{type:"button",className:"ha-act-choix-btn"+(n.competences.includes(e.v)?" is-on":""),"aria-pressed":n.competences.includes(e.v),onClick:()=>fe(e.v),children:e.l},e.v))}),t.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, SIAMU, et type médical ou non médical."})]}),t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(_,{type:"submit",disabled:S,children:n.id?"Enregistrer":"Créer l’activité"}),t.jsx(_,{kind:"soft",onClick:()=>f(null),disabled:S,children:"Annuler"}),n.id&&t.jsx(_,{kind:"danger",onClick:()=>ve(n.id),disabled:S,children:"Retirer"})]})]})}),w?t.jsx(Ne,{}):je?t.jsx(ee,{title:"Aucune activité pour le moment",hint:i?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):ye?t.jsx(ee,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):t.jsx("div",{className:"ha-act-table-wrap",children:t.jsxs("table",{className:"ha-act-table",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"ID"}),t.jsx("th",{children:"Activité"}),t.jsx("th",{children:"Lieu"}),t.jsx("th",{children:t.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>pe(e=>e==="asc"?"desc":"asc"),children:["Date ",t.jsx("span",{"aria-hidden":!0,children:T==="asc"?"↑":"↓"})]})}),t.jsx("th",{children:"Compétence"}),t.jsx("th",{children:"Inscrit"}),t.jsx("th",{children:"Actions"})]})}),t.jsx("tbody",{children:X.map(e=>{const a=p.nombres.get(e.id)||0,s=Number(e.places)||0,c=p.miennes.has(e.id),o=V(e),j=a>=s,C=Te(e);let y="S’inscrire",A=!1;return c?y="Se désinscrire":o?j&&(y="Complet",A=!0):(y="Terminée",A=!0),t.jsxs("tr",{children:[t.jsx("td",{className:"ha-act-id",children:e.numero}),t.jsxs("td",{children:[t.jsx(ke,{to:`/app/secours/activites/${e.id}`,className:"ha-act-titre",children:e.titre}),t.jsxs("div",{className:"ha-act-type",children:[$e(e.type),z(e).length?` · ${z(e).map(h=>Ie(h,!0)).join(" + ")}`:""]})]}),t.jsx("td",{className:"ha-act-lieu",children:e.lieu||"—"}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-quand",children:[t.jsx("strong",{children:C.date}),C.heures&&t.jsx("span",{children:C.heures})]})}),t.jsx("td",{children:(e.competences||[]).length===0?t.jsx("span",{className:"ha-act-aucune",children:"—"}):(e.competences||[]).map(h=>t.jsxs("span",{className:"ha-act-chip"+(p.mes.has(h)?" is-moi":" is-autre"),children:[p.mes.has(h)?"✓":"•"," ",_e(h)]},h))}),t.jsx("td",{children:t.jsx(Re,{inscrits:a,places:s})}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-actions",children:[t.jsxs("button",{type:"button",className:"ha-act-go"+(c?" is-off":""),disabled:A||B===e.id,onClick:()=>he(e),children:[t.jsx(ne,{}),B===e.id?"…":y]}),i&&t.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>xe(e),children:"Modifier"})]})})]},e.id)})})]})})]})}function H({tone:r,on:i,n:d,label:b,icone:x,onClick:E}){return t.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(i?" is-on":""),"aria-pressed":i,onClick:E,children:[t.jsx("span",{className:"ha-act-carte-n",children:d}),t.jsx("span",{className:"ha-act-carte-l",children:b}),t.jsx("span",{className:"ha-act-carte-ico is-"+r,children:x})]})}function Re({inscrits:r,places:i}){const d=i>0?Math.min(1,r/i):0,b=i>0&&r>=i,x=r===0?0:Math.max(d*100,18);return t.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${i} place${i>1?"s":""}`,children:[t.jsx("span",{style:{width:`${x}%`,background:b?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),t.jsxs("em",{style:{color:d>=.55||b?"#fff":"var(--text)"},children:[r,"/",i]})]})}const Ve=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Je as default};
