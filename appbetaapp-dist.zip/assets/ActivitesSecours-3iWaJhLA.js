import{r as c,j as e,L as ge}from"./vendor-react-y2xUrN8v.js";import{u as ve,s as g,r as je,k as K,o as ye,q as N,e as z,n as ke,E as U}from"./index-DhKFmBS0.js";import{p as we,c as Ce,e as R,r as Ne,d as Ae,C as X,T as P,l as Se,a as Ee,b as Z}from"./activitesSecours-WddlkkAk.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const Fe={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",competences:[]};function h(r){return String(r).padStart(2,"0")}function Y(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${h(a.getMonth()+1)}-${h(a.getDate())}`}function ee(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${h(a.getDate())}-${h(a.getMonth()+1)}-${a.getFullYear()}`}function W(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${h(a.getHours())}:${h(a.getMinutes())}`}function De(r){const a=ee(r.debut),l=W(r.debut);if(!r.fin)return{date:a,heures:l};const m=Y(r.debut)===Y(r.fin)?W(r.fin):`${ee(r.fin)} ${W(r.fin)}`;return{date:a,heures:l&&m?`${l}–${m}`:l}}function te(r){if(!r)return"";const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${h(a.getMonth()+1)}-${h(a.getDate())}T${h(a.getHours())}:${h(a.getMinutes())}`}function re(r){if(!r)return null;const a=new Date(r);return Number.isNaN(a.getTime())?null:a.toISOString()}function ae(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function $e(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function qe(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Re(){const{profile:r}=ve(),a=we(r),[l,x]=c.useState([]),[m,A]=c.useState([]),[v,H]=c.useState(!0),[J,T]=c.useState(null),[O,p]=c.useState(null),[b,ie]=c.useState(null),[S,se]=c.useState(""),[E,ne]=c.useState(""),[F,oe]=c.useState(""),[_,ce]=c.useState(""),[L,le]=c.useState("asc"),[I,Q]=c.useState(null),[n,f]=c.useState(null),[w,D]=c.useState(!1);c.useEffect(()=>{$()},[r==null?void 0:r.id]);async function $(t=!1){var d,o;t||H(!0),T(null);const[s,i]=await Promise.all([g.from("activites_secours").select("id,numero,titre,type,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),g.from("activites_secours_inscrits").select("id,activite_id,user_id")]);s.error||i.error?(T(((d=s.error)==null?void 0:d.message)||((o=i.error)==null?void 0:o.message)||"Chargement impossible."),x([]),A([])):(x(Array.isArray(s.data)?s.data:[]),A(Array.isArray(i.data)?i.data:[])),H(!1)}const u=c.useMemo(()=>Ce(l,m,r),[l,m,r]),G=c.useMemo(()=>{const t=_.trim().toLowerCase(),s=l.filter(i=>{const d=u.nombres.get(i.id)||0;if(b==="possible"&&!(R(i)&&d<Number(i.places)&&!u.miennes.has(i.id))||b==="competence"&&!(R(i)&&Ne(i,u.mes))||b==="bientot"&&!Ae(i.debut)||S&&!(i.competences||[]).includes(S))return!1;const o=Y(i.debut);return!(E&&o&&o<E||F&&o&&o>F||t&&!`${i.numero||""} ${i.titre||""} ${i.lieu||""}`.toLowerCase().includes(t))});return s.sort((i,d)=>{const o=String(i.debut).localeCompare(String(d.debut));return L==="asc"?o:-o}),s},[l,u,b,S,E,F,_,L]);function M(t){ie(s=>s===t?null:t)}async function de(t){if(!(r!=null&&r.id)||I)return;Q(t.id),p(null);const i=u.miennes.has(t.id)?await g.from("activites_secours_inscrits").delete().eq("activite_id",t.id).eq("user_id",r.id):await g.from("activites_secours_inscrits").insert({activite_id:t.id,user_id:r.id});i.error?p(i.error.message||"Inscription impossible."):await $(!0),Q(null)}function ue(){T(null),f({...Fe,competences:[]})}function pe(t){f({id:t.id,titre:t.titre||"",type:P.some(s=>s.v===t.type)?t.type:"activite",lieu:t.lieu||"",debut:te(t.debut),fin:te(t.fin),places:String(t.places??1),competences:Z(t.competences)})}function j(t){f(s=>({...s,...t}))}function he(t){f(s=>{const i=s.competences.includes(t)?s.competences.filter(d=>d!==t):[...s.competences,t];return{...s,competences:i}})}async function me(t){if(t.preventDefault(),!n||w)return;const s=n.titre.trim(),i=re(n.debut),d=re(n.fin),o=Number(n.places);if(!s){p("Indiquez le titre.");return}if(!i){p("Indiquez le début.");return}if(n.fin&&!d){p("La fin est illisible.");return}if(d&&d<i){p("La fin est avant le début.");return}if(!Number.isInteger(o)||o<1||o>500){p("Le nombre de places doit être entre 1 et 500.");return}D(!0),p(null);const C={titre:s,type:P.some(k=>k.v===n.type)?n.type:"activite",lieu:n.lieu.trim()||null,debut:i,fin:d,places:o,competences:Z(n.competences)},y=n.id?await g.from("activites_secours").update(C).eq("id",n.id):await g.from("activites_secours").insert({...C,created_by:(r==null?void 0:r.id)||null});y.error?p(y.error.message||"Enregistrement impossible."):(f(null),await $(!0)),D(!1)}async function xe(t){if(!t||w||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;D(!0),p(null);const s=await g.from("activites_secours").delete().eq("id",t);s.error?p(s.error.message||"Suppression impossible."):(f(null),await $(!0)),D(!1)}const be=!v&&l.length===0,fe=!v&&l.length>0&&G.length===0;return e.jsxs(je,{title:"Activités",subtitle:"Département secours. Tout le personnel retrouve ici les activités et peut s’inscrire.",action:a?e.jsx(z,{onClick:ue,children:"+ Activité"}):null,children:[e.jsx("style",{children:Te}),J&&e.jsx(K,{kind:"err",children:J}),O&&e.jsx(K,{kind:"err",children:O}),e.jsxs("div",{className:"ha-act-cartes",children:[e.jsx(V,{tone:"possible",on:b==="possible",n:v?"…":u.possible,label:"Inscription possible",icone:e.jsx(ae,{}),onClick:()=>M("possible")}),e.jsx(V,{tone:"competence",on:b==="competence",n:v?"…":u.competence,label:"Requiert ma compétence",icone:e.jsx($e,{}),onClick:()=>M("competence")}),e.jsx(V,{tone:"bientot",on:b==="bientot",n:v?"…":u.bientot,label:"Sur les 30 prochains jours",icone:e.jsx(qe,{}),onClick:()=>M("bientot")})]}),e.jsxs("div",{className:"ha-act-filtres",children:[e.jsxs("select",{"aria-label":"Compétence",value:S,onChange:t=>se(t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les activités"}),X.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]}),e.jsxs("label",{className:"ha-act-dates",children:[e.jsx("span",{className:"ha-sr",children:"Du"}),e.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:E,onChange:t=>ne(t.target.value)}),e.jsx("span",{children:"au"}),e.jsx("span",{className:"ha-sr",children:"Au"}),e.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:F,onChange:t=>oe(t.target.value)})]}),e.jsxs("label",{className:"ha-act-recherche",children:[e.jsx("span",{className:"ha-sr",children:"Rechercher"}),e.jsx("input",{type:"search",placeholder:"Rechercher",value:_,onChange:t=>ce(t.target.value)})]})]}),n&&e.jsx(ye,{style:{marginBottom:14},children:e.jsxs("form",{onSubmit:me,children:[e.jsxs("div",{className:"ha-act-form",children:[e.jsx(N,{label:"Titre",value:n.titre,set:t=>j({titre:t}),required:!0}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),e.jsx("select",{value:n.type,onChange:t=>j({type:t.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:P.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))})]}),e.jsx(N,{label:"Lieu",value:n.lieu,set:t=>j({lieu:t})}),e.jsx(N,{label:"Début",type:"datetime-local",value:n.debut,set:t=>j({debut:t}),required:!0}),e.jsx(N,{label:"Fin",type:"datetime-local",value:n.fin,set:t=>j({fin:t})}),e.jsx(N,{label:"Places",type:"number",value:n.places,set:t=>j({places:t}),required:!0})]}),e.jsxs("div",{style:{marginBottom:8},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),e.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:X.map(t=>e.jsx("button",{type:"button",className:"ha-act-choix-btn"+(n.competences.includes(t.v)?" is-on":""),"aria-pressed":n.competences.includes(t.v),onClick:()=>he(t.v),children:t.l},t.v))}),e.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, et type médical ou non médical."})]}),e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[e.jsx(z,{type:"submit",disabled:w,children:n.id?"Enregistrer":"Créer l’activité"}),e.jsx(z,{kind:"soft",onClick:()=>f(null),disabled:w,children:"Annuler"}),n.id&&e.jsx(z,{kind:"danger",onClick:()=>xe(n.id),disabled:w,children:"Retirer"})]})]})}),v?e.jsx(ke,{}):be?e.jsx(U,{title:"Aucune activité pour le moment",hint:a?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):fe?e.jsx(U,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):e.jsx("div",{className:"ha-act-table-wrap",children:e.jsxs("table",{className:"ha-act-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Activité"}),e.jsx("th",{children:"Lieu"}),e.jsx("th",{children:e.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>le(t=>t==="asc"?"desc":"asc"),children:["Date ",e.jsx("span",{"aria-hidden":!0,children:L==="asc"?"↑":"↓"})]})}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{children:"Inscrit"}),e.jsx("th",{children:"Actions"})]})}),e.jsx("tbody",{children:G.map(t=>{const s=u.nombres.get(t.id)||0,i=Number(t.places)||0,d=u.miennes.has(t.id),o=R(t),C=s>=i,y=De(t);let k="S’inscrire",B=!1;return d?k="Se désinscrire":o?C&&(k="Complet",B=!0):(k="Terminée",B=!0),e.jsxs("tr",{children:[e.jsx("td",{className:"ha-act-id",children:t.numero}),e.jsxs("td",{children:[e.jsx(ge,{to:`/app/secours/activites/${t.id}`,className:"ha-act-titre",children:t.titre}),e.jsx("div",{className:"ha-act-type",children:Se(t.type)})]}),e.jsx("td",{className:"ha-act-lieu",children:t.lieu||"—"}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-quand",children:[e.jsx("strong",{children:y.date}),y.heures&&e.jsx("span",{children:y.heures})]})}),e.jsx("td",{children:(t.competences||[]).length===0?e.jsx("span",{className:"ha-act-aucune",children:"—"}):(t.competences||[]).map(q=>e.jsxs("span",{className:"ha-act-chip"+(u.mes.has(q)?" is-moi":" is-autre"),children:[u.mes.has(q)?"✓":"•"," ",Ee(q)]},q))}),e.jsx("td",{children:e.jsx(ze,{inscrits:s,places:i})}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-actions",children:[e.jsxs("button",{type:"button",className:"ha-act-go"+(d?" is-off":""),disabled:B||I===t.id,onClick:()=>de(t),children:[e.jsx(ae,{}),I===t.id?"…":k]}),a&&e.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>pe(t),children:"Modifier"})]})})]},t.id)})})]})})]})}function V({tone:r,on:a,n:l,label:x,icone:m,onClick:A}){return e.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(a?" is-on":""),"aria-pressed":a,onClick:A,children:[e.jsx("span",{className:"ha-act-carte-n",children:l}),e.jsx("span",{className:"ha-act-carte-l",children:x}),e.jsx("span",{className:"ha-act-carte-ico is-"+r,children:m})]})}function ze({inscrits:r,places:a}){const l=a>0?Math.min(1,r/a):0,x=a>0&&r>=a,m=r===0?0:Math.max(l*100,18);return e.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${a} place${a>1?"s":""}`,children:[e.jsx("span",{style:{width:`${m}%`,background:x?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),e.jsxs("em",{style:{color:l>=.55||x?"#fff":"var(--text)"},children:[r,"/",a]})]})}const Te=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Re as default};
