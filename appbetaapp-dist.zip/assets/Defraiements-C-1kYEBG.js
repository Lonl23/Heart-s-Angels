import{r as d,j as e}from"./vendor-react-CvGqxUS4.js";import{u as lt,s as A,p as Je,k as xe,i as ve,e as dt,E as ct,c as m,b as B,n as Ye,S as se,o as X,l as Le}from"./index-RU3nPa_d.js";import{e as c,h as ut,i as mt,a as pt,t as ft}from"./documentA4-Hr013hEr.js";import{n as Ge,t as be,a as ye,b as de,e as Qe,f as je,O as qe,F as gt,c as _,M as _e,T as ke,d as Me,o as he,s as Ze,g as Oe,h as G,i as re,j as ht,l as xt,P as We,k as vt,m as bt,p as Pe,q as oe,r as Ke,u as yt,v as Ve}from"./constantes-DgLb-Tv1.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const M="#EC7C30",jt=8,_t=8,kt=`
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #fff; }
  body {
    font-family: Calibri, 'Segoe UI', Arial, Helvetica, sans-serif;
    color: #000; font-size: 10pt;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  /* @page : voir cssPapierOfficiel */
  .page { width: 100%; margin: 0 auto; }
  .head { position: relative; min-height: 28mm; margin-bottom: 2mm; }
  .org {
    text-align: center; font-style: italic; font-size: 13.5pt;
    padding-top: 8mm; margin: 0;
  }
  .logo {
    position: absolute; right: 0; top: 0;
    width: 24mm; height: 24mm; object-fit: contain;
  }
  .titre {
    border: 1px solid #000; text-align: center; color: ${M};
    font-size: 14.5pt; font-weight: 700; letter-spacing: .2px;
    padding: 4px 8px 5px; margin: 0 0 8px;
  }
  .intro {
    text-align: center; font-size: 9.5pt; line-height: 1.35;
    margin: 0 4mm 8px;
  }
  .intro b { font-weight: 700; }
  .intro .asbl { font-style: italic; font-weight: 700; }
  .periode {
    text-align: center; color: ${M}; font-weight: 700; font-size: 13.5pt;
    border-top: 1px solid #000; border-bottom: 1.6px solid #000;
    padding: 3px 0 4px; margin: 0 0 0;
  }
  table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  table.bloc { margin: 0; }
  td, th {
    border: 1px solid #000; padding: 2px 4px; text-align: center;
    vertical-align: middle; font-size: 9.5pt; font-weight: 400;
  }
  th { font-weight: 400; height: 9mm; }
  .th-2 { line-height: 1.15; }
  .sec td {
    border: 1px solid #000; color: ${M}; font-style: italic; font-weight: 700;
    font-size: 9.5pt; padding: 3px 6px 2px; text-align: center;
  }
  .legal {
    display: block; font-weight: 400; font-style: italic; font-size: 9.5pt;
    color: ${M}; margin-top: 1px;
  }
  tr.data td { height: 5.2mm; }
  tr.tot td { height: 9mm; color: ${M}; font-weight: 700; font-style: italic; }
  tr.tot td.vide { color: #000; font-weight: 400; font-style: normal; border-right: 1px solid #000; }
  .grand-wrap { display: flex; margin-top: 0; }
  .grand-wrap .sp { flex: 0 0 32%; }
  .grand-wrap table { flex: 1; }
  .grand td {
    color: ${M}; font-weight: 700; font-size: 11pt; height: 8mm;
    font-style: normal;
  }
  .ogm-box {
    margin-top: 6mm; border: 1.6px solid #000; padding: 3mm 4mm; text-align: center;
  }
  .ogm-box .lbl { font-size: 9pt; color: ${M}; font-weight: 700; letter-spacing: .3px; }
  .ogm-box .num {
    font-family: 'Courier New', Courier, monospace;
    font-size: 16pt; font-weight: 700; letter-spacing: 1px; margin-top: 1mm;
  }
  .legal-sig {
    font-size: 8.5pt; font-style: italic; text-align: center; margin: 3mm 0 2mm;
  }
  table.trace { margin-top: 2mm; }
  table.trace th, table.trace td { font-size: 9pt; text-align: left; padding: 2px 5px; }
  table.trace th { background: #f4f4f4; font-weight: 700; }
  @media print {
    .page { width: auto; }
  }
`;function Xe(i,u,k){const o=[];for(let v=0;v<u;v++){const f=i[v];o.push('<tr class="data">'+k(f,v)+"</tr>")}return o.join("")}function St(i,u){const k=Ge(u).replace(/[^\p{L}\p{N}]+/gu,"-")||"volontaire",o=String(i.periode_mois||"").padStart(2,"0");return`Note-de-frais-${k}-${i.periode_annee}-${o}.html`}async function At({note:i,profil:u,logoDataUrl:k}){const o=Ge(u),v=i.lignes_forfait||[],f=i.lignes_km||[],O=be(v),b=Number.isFinite(Number(i.total_km))?Number(i.total_km):ye(f),W=Number.isFinite(Number(i.total))?Number(i.total):Math.round((O+b)*100)/100,h=de(i.periode_mois,i.periode_annee),P=i.iban||"—",I=i.communication||"— (attribuée à la soumission)",R=Qe(i),j=k?`<img class="logo" alt="" src="${c(k)}">`:"",$=Xe(v,jt,r=>`<td>${c((r==null?void 0:r.activite)||"")}</td><td>${c((r==null?void 0:r.lieu)||"")}</td><td>${c(r?Me(r.date):"")}</td><td>${r?c(_(r.montant)):""}</td>`),N=Xe(f,Math.max(_t,f.length),r=>`<td>${c(r?Me(r.date):"")}</td><td>${c((r==null?void 0:r.activite)||"")}</td><td>${c((r==null?void 0:r.lieux)||"")}</td><td>${r&&r.km?c(String(r.km).replace(".",",")):""}</td><td>${r?c(_(r.montant)):""}</td>`),D=R.map(r=>`<tr><td>${c(r.l)}</td><td>${c(r.nom||"—")}</td><td>${c(r.fonc||"")}</td><td>${c(r.at?je(r.at):"—")}</td></tr>`).join(""),y=`<div class="page">
    <div class="head">
      <p class="org">${c(qe)}</p>
      ${j}
    </div>
    <div class="titre">NOTE DE FRAIS VOLONTARIAT - SYSTÈME DES FRAIS FORFAITAIRES</div>
    <p class="intro">Je soussigné <b>${c(o)}</b> sollicite de <span class="asbl">${c(qe)}</span> le remboursement des frais suivants, exposés dans le cadre de mes activités bénévoles, <b>sur le compte bancaire ${c(P)}</b></p>
    <div class="periode">PERIODE : ${c(h)}</div>

    <table class="bloc">
      <tr class="sec"><td colspan="4">DEFRAIEMENTS FORFAITAIRES DE VOLONTARIAT<br><span class="legal">(max. 44,02€ par jour et 1760,83 €- montants valables jusqu’au ${c(gt)})</span></td></tr>
      <tr>
        <th>ACTIVITES</th>
        <th>LIEU</th>
        <th>DATE(S)</th>
        <th>TOTAL</th>
      </tr>
      ${$}
      <tr class="tot">
        <td class="vide" colspan="2"></td>
        <td>Total défraiement forfaitaire</td>
        <td>${c(_(O))}</td>
      </tr>
    </table>

    <table class="bloc" style="margin-top:3mm">
      <tr class="sec"><td colspan="5">FRAIS DE DEPLACEMENT<br><span class="legal">Max. ${c(String(_e))} kms remboursés à max. ${c(String(ke).replace(".",","))}€/km voiture (montant 2026) , ou en frais réels pour les transports en commun</span></td></tr>
      <tr>
        <th>DATE</th>
        <th>ACTIVITES</th>
        <th class="th-2">LIEUX DE DEPART ET<br>D'ARRIVEE</th>
        <th class="th-2">KILOMETRAGE<br>A/R</th>
        <th>TOTAL</th>
      </tr>
      ${N}
      <tr class="tot">
        <td class="vide" colspan="3"></td>
        <td>Total frais de déplacements</td>
        <td>${c(_(b))}</td>
      </tr>
    </table>

    <div class="grand-wrap">
      <div class="sp"></div>
      <table>
        <tr class="grand">
          <td>TOTAL NOTE DE FRAIS</td>
          <td style="width:22%">${c(_(W))}</td>
        </tr>
      </table>
    </div>

    <div class="ogm-box">
      <div class="lbl">COMMUNICATION STRUCTURÉE (virement / comptabilité)</div>
      <div class="num">${c(I)}</div>
    </div>
    <p class="legal-sig">Valider dans l’application vaut signature. Chaque étape est nominative et horodatée. Aucune signature manuscrite n’est requise.</p>
    <table class="trace">
      <tr><th>Étape</th><th>Personne</th><th>Fonction</th><th>Date et heure</th></tr>
      ${D}
    </table>
  </div>`;return ut(`Note de frais — ${o} — ${h}`,y,kt)}let le=null;async function wt(){if(le)return le;try{const i=await fetch("/icons/ha-logo-rond.png");if(!i.ok)return"";const u=await i.blob();return le=await new Promise((k,o)=>{const v=new FileReader;v.onload=()=>k(v.result),v.onerror=o,v.readAsDataURL(u)}),le}catch{return""}}const Q=new Date,Ct=Array.from({length:12},(i,u)=>{const k=new Date(2026,u,1).toLocaleDateString("fr-BE",{month:"long"});return{v:String(u+1),l:k.charAt(0).toUpperCase()+k.slice(1)}}),Tt=[Q.getFullYear()-1,Q.getFullYear(),Q.getFullYear()+1].map(i=>({v:String(i),l:String(i)}));function Z(i){return[i==null?void 0:i.prenom,i==null?void 0:i.nom].filter(Boolean).join(" ")||(i==null?void 0:i.email)||"Volontaire"}function Ue(i,u){return(i==null?void 0:i.message)||u||"Erreur"}function Bt(){const{profile:i,peutGererDefraiements:u,peutSupprimerNoteFrais:k}=lt(),o=u(),v=k(),[f,O]=d.useState([]),[b,W]=d.useState({}),[h,P]=d.useState(!0),[I,R]=d.useState(null),[j,$]=d.useState("miennes"),[N,D]=d.useState(""),[y,r]=d.useState(null);d.useEffect(()=>{U()},[i==null?void 0:i.id,o]);async function U(){if(!(i!=null&&i.id))return;P(!0),R(null);let s=A.from("notes_frais").select("*").order("periode_annee",{ascending:!1}).order("periode_mois",{ascending:!1});o||(s=s.eq("user_id",i.id));const{data:E,error:w}=await s;w&&R(w.message);const H=E||[];O(H);const te=[...new Set(H.map(K=>K.user_id).filter(Boolean))];if(o&&te.length){const{data:K}=await A.from("profiles").select("id,prenom,nom,email,fiche").in("id",te);W(Object.fromEntries((K||[]).map(ie=>[ie.id,ie])))}else W({[i.id]:i});P(!1)}const ee=f.filter(s=>j==="a_verifier"?s.statut==="soumise":j==="a_autoriser"?s.statut==="verifiee":j==="a_virer"?s.statut==="approuve_n1"||s.statut==="approuve_n2":j==="payees"?s.statut==="paye":j==="miennes"?s.user_id===(i==null?void 0:i.id):!0).filter(s=>{const E=N.trim().toLowerCase();if(!E)return!0;const w=b[s.user_id];return[s.communication,he(s.communication),Z(w),de(s.periode_mois,s.periode_annee)].join(" ").toLowerCase().includes(E)||he(s.communication).includes(he(E))});return y?e.jsx(Nt,{initiale:y,tresorier:o,peutSupprimer:v,moi:i,onClose:()=>{r(null),U()}}):e.jsxs(Je,{title:"Défraiements",subtitle:"Valider dans l’app vaut signature. Chaque note a une communication structurée pour le virement et la comptabilité.",action:e.jsx(m,{onClick:()=>r({nouveau:!0}),children:"Nouvelle note"}),children:[I&&e.jsx(xe,{kind:"err",children:I}),o&&e.jsx("div",{className:"ha-tabs",style:{marginBottom:12},children:[{v:"miennes",l:"Mes notes"},{v:"a_verifier",l:"À vérifier"},{v:"a_autoriser",l:"À autoriser"},{v:"a_virer",l:"À virer"},{v:"toutes",l:"Toutes"},{v:"payees",l:"Payées"}].map(s=>e.jsx("button",{type:"button",className:"ha-tab"+(j===s.v?" is-on":""),onClick:()=>$(s.v),children:s.l},s.v))}),o&&e.jsx("div",{style:{marginBottom:14},children:e.jsx("input",{value:N,onChange:s=>D(s.target.value),placeholder:"N° de communication ou nom…",style:ve})}),h?e.jsx(dt,{}):ee.length===0?e.jsx(ct,{title:"Aucune note pour le moment",hint:"Créez une note, puis validez-la : cela signe la demande et attribue le numéro de communication.",action:e.jsx(m,{onClick:()=>r({nouveau:!0}),children:"Créer une note"})}):e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:10},children:ee.map(s=>{const E=Ze(s.statut),w=b[s.user_id]||(s.user_id===(i==null?void 0:i.id)?i:null);return e.jsx(B,{clickable:!0,onClick:()=>r(s),style:{padding:"14px 16px"},children:e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:12,alignItems:"flex-start",flexWrap:"wrap"},children:[e.jsxs("div",{children:[e.jsx("div",{style:{fontWeight:700,color:"var(--text)"},children:de(s.periode_mois,s.periode_annee)}),e.jsxs("div",{style:{fontSize:13,color:"var(--text-muted)",marginTop:3},children:[Z(w),s.iban?` · ${s.iban}`:""]}),s.communication&&e.jsx("div",{style:{fontFamily:"ui-monospace, monospace",fontSize:13,fontWeight:700,color:"var(--heading)",marginTop:4},children:s.communication})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10},children:[e.jsx("span",{style:{fontWeight:700,color:"var(--heading)"},children:_(s.total)}),e.jsx(Ye,{color:E.c,bg:E.bg,children:E.l})]})]})},s.id)})})]})}function Nt({initiale:i,tresorier:u,peutSupprimer:k,moi:o,onClose:v}){const[f,O]=d.useState(i.user_id||o.id),[b,W]=d.useState(String(i.periode_mois||Q.getMonth()+1)),[h,P]=d.useState(String(i.periode_annee||Q.getFullYear())),[I,R]=d.useState(i.iban||""),[j,$]=d.useState(i.lignes_forfait||[]),[N,D]=d.useState(i.lignes_km||[]),[y,r]=d.useState(i.statut||"en_attente"),[U,ee]=d.useState(i.motif_refus||""),[s,E]=d.useState([]),[w,H]=d.useState(o),[te,K]=d.useState(0),[ie,Se]=d.useState(0),[F,V]=d.useState(!1),[ce,C]=d.useState(null),[ne,Ae]=d.useState(null),[p,we]=d.useState(i.id||null),[S,et]=d.useState(i.nouveau?null:i),Ce=d.useRef(null),x=!(y==="en_attente"||y==="refuse"),ae=be(j),ue=ye(N),tt=Math.round((ae+ue)*100)/100,Te=Oe(N),Ne=te+(y==="refuse"?0:ae),Ee=ie+(y==="refuse"?0:Te),me=f===o.id;d.useEffect(()=>(document.body.classList.toggle("ha-fiche-ouverte",!!ne),()=>document.body.classList.remove("ha-fiche-ouverte")),[ne]),d.useEffect(()=>{u&&A.from("profiles").select("id,prenom,nom,email,fiche").neq("role","partenaire").eq("actif",!0).order("nom").then(({data:t})=>E(t||[]))},[u]),d.useEffect(()=>{nt()},[f,b,h]);async function it(t){if(t===o.id)return o;const{data:a}=await A.from("profiles").select("id,prenom,nom,email,fiche").eq("id",t).maybeSingle();return a||{id:t}}async function Ie(t,a,n){const{data:g}=await A.from("notes_frais").select("id,total_forfait,total,lignes_km,statut").eq("user_id",t).eq("periode_annee",Number(a)).neq("statut","refuse"),l=(g||[]).filter(q=>q.id!==n),T=l.reduce((q,Y)=>q+Number(Y.total_forfait!=null?Y.total_forfait:Y.total||0),0),z=l.reduce((q,Y)=>q+Oe(Y.lignes_km),0);return{forfait:T,km:z}}function pe(t){t&&(et(t),we(t.id),r(t.statut),ee(t.motif_refus||""),R(t.iban||""),$(t.lignes_forfait||[]),D(t.lignes_km||[]))}async function nt(){const t=await it(f);H(t);const{data:a}=await A.from("notes_frais").select("*").eq("user_id",f).eq("periode_mois",Number(b)).eq("periode_annee",Number(h)).maybeSingle();if(a&&a.id!==p){pe(a);const l=await Ie(f,h,a.id);K(l.forfait),Se(l.km);return}const n=await Ie(f,h,p);if(K(n.forfait),Se(n.km),p)return;R(l=>{var T,z;return l||G(((T=t==null?void 0:t.fiche)==null?void 0:T.iban)||((z=o==null?void 0:o.fiche)==null?void 0:z.iban)||"")});const{data:g}=await A.rpc("missions_pour_note_frais",{p_user:f,p_mois:Number(b),p_annee:Number(h)});$(re(Array.isArray(g)?g:[])),D([])}async function at(){const{data:t,error:a}=await A.rpc("missions_pour_note_frais",{p_user:f,p_mois:Number(b),p_annee:Number(h)});if(a){C({t:a.message,ok:!1});return}$(re(Array.isArray(t)?t:[]))}function $e(){const t=re(j).map(l=>({date:l.date,activite:l.activite||"Souhait",lieu:l.lieu||"",souhait_id:l.souhait_id||null,montant:oe})),a=Ve(N),n=be(t),g=ye(a);return{user_id:f,periode_mois:Number(b),periode_annee:Number(h),iban:G(I),lignes_forfait:t,lignes_km:a,total_forfait:n,total_km:g,total:Math.round((n+g)*100)/100}}async function De(){if(!yt(I))return C({t:"Indiquez un IBAN belge valide (BE + 14 chiffres).",ok:!1}),null;const t=$e();if(!t.lignes_forfait.length&&!t.lignes_km.length)return C({t:"Ajoutez au moins un jour d’activité ou une ligne de kilomètres.",ok:!1}),null;const a={iban:t.iban,lignes_forfait:t.lignes_forfait,lignes_km:t.lignes_km,total_forfait:t.total_forfait,total_km:t.total_km,total:t.total};V(!0);let n;if(p?n=await A.from("notes_frais").update(a).eq("id",p).select("*").maybeSingle():n=await A.from("notes_frais").insert({...t,statut:"en_attente"}).select("*").maybeSingle(),n.error&&/duplicate|unique/i.test(n.error.message)){const{data:T}=await A.from("notes_frais").select("*").eq("user_id",f).eq("periode_mois",Number(b)).eq("periode_annee",Number(h)).maybeSingle();T&&(we(T.id),n=await A.from("notes_frais").update(a).eq("id",T.id).select("*").maybeSingle())}if(V(!1),n.error)return C({t:n.error.message,ok:!1}),null;const g=n.data;pe(g);const l={...(w==null?void 0:w.fiche)||{},iban:G(I)};return(f===o.id||u)&&await A.from("profiles").update({fiche:l}).eq("id",f),C({t:"Note enregistrée.",ok:!0}),setTimeout(()=>C(null),2500),g}async function L(t,a={}){V(!0);const{data:n,error:g}=await A.rpc(t,a);if(V(!1),g){C({t:Ue(g),ok:!1});return}const l=Array.isArray(n)?n[0]:n;pe(l),C({t:"Enregistré.",ok:!0}),setTimeout(()=>C(null),2500)}async function st(){const t=await De(),a=(t==null?void 0:t.id)||p;a&&await L("soumettre_note_frais",{p_id:a})}function Fe(){return{...$e(),...S||{},id:p,statut:y,iban:G(I),lignes_forfait:re(j),lignes_km:Ve(N)}}async function Re(){const t=await wt();return At({note:Fe(),profil:w,logoDataUrl:t})}async function rt(){pt(await Re(),Ae)}async function ze(){const t=Fe();ft(St(t,w),await Re())}async function ot(){const t=S==null?void 0:S.communication;if(t)try{await navigator.clipboard.writeText(t),C({t:"Communication copiée.",ok:!0}),setTimeout(()=>C(null),2e3)}catch{C({t,ok:!0})}}function fe(t,a,n){$(g=>g.map((l,T)=>T===t?{...l,[a]:a==="montant"?oe:n}:l))}function J(t,a,n){D(g=>g.map((l,T)=>{if(T!==t)return l;const z={...l,[a]:n};if(a==="motif"){const q=Ke(n);(!l.activite||l.activite===Ke(l.motif))&&(z.activite=q)}return a==="km"&&(z.montant=Pe(n)),z}))}const ge=Ze(y),Be=ht(Number(b),Number(h));return e.jsxs(Je,{title:p?`Note — ${de(Number(b),Number(h))}`:"Nouvelle note de frais",subtitle:"Valider la demande vaut signature. Le numéro de communication sert au virement et à la comptabilité.",action:e.jsx(m,{kind:"soft",onClick:v,children:"← Retour"}),children:[ce&&e.jsx(xe,{kind:ce.ok?"ok":"err",children:ce.t}),e.jsx("div",{style:{marginBottom:12},children:e.jsx(Ye,{color:ge.c,bg:ge.bg,children:ge.l})}),e.jsxs(B,{style:{marginBottom:14,background:"var(--bg-alt)"},children:[e.jsx("div",{style:{fontWeight:700,color:"var(--heading)",marginBottom:6},children:"Communication structurée"}),S!=null&&S.communication?e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"},children:[e.jsx("div",{style:{fontFamily:"ui-monospace, Consolas, monospace",fontSize:20,fontWeight:700,letterSpacing:.6,color:"var(--heading)"},children:S.communication}),e.jsx(m,{kind:"soft",onClick:ot,children:"Copier"})]}):e.jsx("div",{style:{fontSize:13.5,color:"var(--text-muted)"},children:"Attribuée automatiquement quand le volontaire valide sa demande."}),e.jsx("div",{style:{fontSize:12.5,color:"var(--text-muted)",marginTop:6},children:"À coller comme communication du virement (format belge +++XXX/XXXX/XXXXX+++)."})]}),e.jsxs(B,{style:{marginBottom:14},children:[e.jsx("div",{style:{fontWeight:700,color:"var(--heading)",marginBottom:8},children:"Circuit de validation"}),e.jsx("div",{style:{fontSize:13,color:"var(--text-muted)",marginBottom:10},children:"Pas de signature dessinée : chaque validation est horodatée au nom de la personne connectée."}),e.jsx("div",{style:{display:"grid",gap:8},children:Qe(S).map(t=>e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"minmax(140px,1fr) minmax(140px,1.4fr) minmax(120px,1fr)",gap:8,alignItems:"baseline",borderBottom:"1px solid var(--border)",paddingBottom:6},children:[e.jsx("div",{style:{fontSize:12.5,color:"var(--text-muted)"},children:t.l}),e.jsxs("div",{style:{fontWeight:600,color:"var(--text)"},children:[t.nom||"—",t.fonc?e.jsxs("span",{style:{fontWeight:400,color:"var(--text-muted)"},children:[" · ",t.fonc]}):null]}),e.jsx("div",{style:{fontSize:12.5,color:"var(--text-muted)",textAlign:"right"},children:t.at?je(t.at):"—"})]},t.k))}),(S==null?void 0:S.refuse_nom)&&e.jsxs("div",{style:{fontSize:13,color:"#A32D2D",marginTop:10},children:["Refusée par ",S.refuse_nom,S.refuse_at?` le ${je(S.refuse_at)}`:"","."]})]}),e.jsxs(B,{style:{marginBottom:14},children:[e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:"0 16px"},children:[u&&i.nouveau&&!p&&e.jsx(se,{label:"Volontaire",value:f,set:O,options:[{v:o.id,l:Z(o)+" (moi)"},...s.filter(t=>t.id!==o.id).map(t=>({v:t.id,l:Z(t)}))]}),e.jsx(se,{label:"Mois",value:b,set:W,options:Ct,disabled:!!p}),e.jsx(se,{label:"Année",value:h,set:P,options:Tt,disabled:!!p}),e.jsx(X,{label:"IBAN (compte du volontaire)",value:I,set:t=>R(G(t)),placeholder:"BE00 0000 0000 0000",required:!0,disabled:x})]}),u&&!i.nouveau&&e.jsx("div",{style:{fontSize:13,color:"var(--text-muted)"},children:Z(w)})]}),e.jsxs(B,{style:{marginBottom:14},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap",marginBottom:10},children:[e.jsx("div",{style:{fontWeight:700,color:"var(--heading)"},children:"Jours d’activité (forfait)"}),!x&&e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[e.jsx(m,{kind:"soft",onClick:at,children:"Reprendre les missions du mois"}),e.jsx(m,{kind:"soft",onClick:()=>$(t=>[...t,xt(`${h}-${String(b).padStart(2,"0")}-01`)]),children:"+ Jour"})]})]}),j.length===0&&e.jsx("div",{style:{fontSize:13,color:"var(--text-muted)",marginBottom:8},children:"Aucun jour. Les missions où vous étiez d’équipage se proposent automatiquement."}),j.map((t,a)=>e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:"0 10px",alignItems:"end",marginBottom:6,borderBottom:"1px solid var(--border)",paddingBottom:4},children:[e.jsxs("div",{children:[e.jsx("label",{style:Le,children:"Date"}),e.jsxs("select",{value:t.date||"",onChange:n=>fe(a,"date",n.target.value),disabled:x,style:{...ve,opacity:x?.65:1},children:[e.jsx("option",{value:"",children:"—"}),Be.map(n=>e.jsx("option",{value:n,children:He(n)},n))]})]}),e.jsx(X,{label:"Activité",value:t.activite||"Souhait",set:n=>fe(a,"activite",n),disabled:x}),e.jsx(X,{label:"Lieu",value:t.lieu||"",set:n=>fe(a,"lieu",n),disabled:x}),e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,paddingBottom:10},children:[e.jsx("span",{style:{fontWeight:700,color:"var(--heading)"},children:_(oe)}),!x&&e.jsx(m,{kind:"danger",onClick:()=>$(n=>n.filter((g,l)=>l!==a)),style:{padding:"6px 10px"},children:"Retirer"})]})]},a)),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap",borderTop:"1px solid var(--border)",paddingTop:12,marginTop:4},children:[e.jsxs("div",{style:{fontSize:13,color:"var(--text-muted)"},children:[j.length," jour",j.length>1?"s":""," × ",_(oe),Ne>We&&e.jsxs("span",{style:{color:"#A32D2D",display:"block",marginTop:4},children:["Attention : le plafond annuel (",_(We),") serait dépassé (",_(Ne),")."]})]}),e.jsx("div",{style:{fontWeight:700,fontSize:16,color:"var(--heading)"},children:_(ae)})]})]}),e.jsxs(B,{style:{marginBottom:14},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap",marginBottom:10},children:[e.jsx("div",{style:{fontWeight:700,color:"var(--heading)"},children:"Frais de déplacement"}),!x&&e.jsx(m,{kind:"soft",onClick:()=>D(t=>[...t,vt(`${h}-${String(b).padStart(2,"0")}-01`)]),children:"+ Trajet"})]}),e.jsxs("div",{style:{fontSize:13,color:"var(--text-2)",marginBottom:12,lineHeight:1.45},children:["Indemnité de ",String(ke).replace(".",",")," €/km (A/R). Pas pour un souhait qui part de la base de la semaine (aujourd’hui Solumob Jemeppe-sur-Meuse ; plus tard, la base personnelle). Oui pour une récolte de souhaits, ou pour un souhait dont la base n’était pas celle de la semaine. Les km du véhicule de mission ne se reprennent pas."]}),N.length===0&&e.jsx("div",{style:{fontSize:13,color:"var(--text-muted)",marginBottom:8},children:"Aucun trajet. Ajoutez une ligne seulement si le motif le permet."}),N.map((t,a)=>e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:"0 10px",alignItems:"end",marginBottom:6,borderBottom:"1px solid var(--border)",paddingBottom:4},children:[e.jsxs("div",{children:[e.jsx("label",{style:Le,children:"Date"}),e.jsxs("select",{value:t.date||"",onChange:n=>J(a,"date",n.target.value),disabled:x,style:{...ve,opacity:x?.65:1},children:[e.jsx("option",{value:"",children:"—"}),Be.map(n=>e.jsx("option",{value:n,children:He(n)},n))]})]}),e.jsx(se,{label:"Motif",value:t.motif||"recolte",set:n=>J(a,"motif",n),options:bt,disabled:x}),e.jsx(X,{label:"Activité",value:t.activite||"",set:n=>J(a,"activite",n),disabled:x}),e.jsx(X,{label:"Lieux (départ → arrivée)",value:t.lieux||"",set:n=>J(a,"lieux",n),disabled:x}),e.jsx(X,{label:"Km A/R",value:t.km===0||t.km?String(t.km):"",set:n=>J(a,"km",n),disabled:x}),e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,paddingBottom:10},children:[e.jsx("span",{style:{fontWeight:700,color:"var(--heading)"},children:_(Pe(t.km))}),!x&&e.jsx(m,{kind:"danger",onClick:()=>D(n=>n.filter((g,l)=>l!==a)),style:{padding:"6px 10px"},children:"Retirer"})]})]},a)),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap",borderTop:"1px solid var(--border)",paddingTop:12,marginTop:4},children:[e.jsxs("div",{style:{fontSize:13,color:"var(--text-muted)"},children:[Te||0," km × ",String(ke).replace(".",",")," €",Ee>_e&&e.jsxs("span",{style:{color:"#A32D2D",display:"block",marginTop:4},children:["Attention : le plafond annuel (",_e," km) serait dépassé (",Ee," km)."]})]}),e.jsx("div",{style:{fontWeight:700,fontSize:16,color:"var(--heading)"},children:_(ue)})]})]}),e.jsxs(B,{style:{marginBottom:14,background:"var(--bg-alt)"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap"},children:[e.jsx("div",{style:{fontWeight:700,color:"var(--heading)"},children:"Total de la note"}),e.jsx("div",{style:{fontWeight:700,fontSize:18,color:"var(--heading)"},children:_(tt)})]}),e.jsxs("div",{style:{fontSize:13,color:"var(--text-muted)",marginTop:4},children:["Forfait ",_(ae)," + déplacements ",_(ue)]})]}),y==="refuse"&&U&&e.jsxs(xe,{kind:"err",children:["Motif du refus : ",U]}),e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[!x&&e.jsx(m,{onClick:()=>De(),disabled:F,children:F?"Enregistrement…":"Enregistrer le brouillon"}),!x&&me&&e.jsx(m,{kind:"ok",onClick:st,disabled:F,children:"Valider ma demande"}),!x&&!me&&e.jsx("div",{style:{fontSize:13,color:"#BA7517",alignSelf:"center"},children:"Le volontaire doit ouvrir sa note et toucher « Valider ma demande » (cela signe)."}),me&&y==="soumise"&&e.jsx(m,{kind:"soft",onClick:()=>L("retirer_note_frais",{p_id:p}),disabled:F,children:"Retirer la demande"}),e.jsx(m,{kind:"soft",onClick:rt,children:"Ouvrir la note A4"}),e.jsx(m,{kind:"soft",onClick:ze,children:"Télécharger"}),u&&y==="soumise"&&p&&e.jsxs(e.Fragment,{children:[e.jsx(m,{kind:"ok",onClick:()=>L("verifier_note_frais",{p_id:p}),disabled:F,children:"Vérifier la demande"}),e.jsx(m,{kind:"danger",onClick:()=>{const t=window.prompt("Motif du refus ?")||"";t.trim()&&L("refuser_note_frais",{p_id:p,p_motif:t.trim()})},children:"Refuser"})]}),u&&y==="verifiee"&&p&&e.jsxs(e.Fragment,{children:[e.jsx(m,{kind:"ok",onClick:()=>L("autoriser_note_frais",{p_id:p}),disabled:F,children:"Autoriser le paiement"}),e.jsx(m,{kind:"danger",onClick:()=>{const t=window.prompt("Motif du refus ?")||"";t.trim()&&L("refuser_note_frais",{p_id:p,p_motif:t.trim()})},children:"Refuser"})]}),u&&(y==="approuve_n1"||y==="approuve_n2")&&p&&e.jsx(m,{kind:"ok",onClick:()=>L("virer_note_frais",{p_id:p}),disabled:F,children:"Virement effectué"})]}),k&&p&&e.jsxs(B,{style:{marginTop:18,borderColor:"#E8B4B4",background:"#FDF6F6"},children:[e.jsx("div",{style:{fontWeight:700,color:"#A32D2D",marginBottom:6},children:"Suppression complète"}),e.jsx("div",{style:{fontSize:13,color:"var(--text-muted)",marginBottom:12,lineHeight:1.45},children:"Réservé au responsable informatique. La demande disparaît définitivement, quel que soit son statut (brouillon, soumise, payée…). Le mois redevient libre pour une nouvelle note."}),e.jsx(m,{kind:"danger",disabled:F,onClick:async()=>{if(!window.confirm(`Supprimer définitivement cette demande de défraiement ?

La note disparaîtra complètement, y compris si elle a déjà été validée ou payée. Le volontaire pourra recréer une note pour le même mois.

Cette action est irréversible.`))return;V(!0);const{error:a}=await A.rpc("supprimer_note_frais",{p_id:p});if(V(!1),a){C({t:Ue(a,"Impossible de supprimer la demande."),ok:!1});return}v()},style:{background:"#A32D2D",color:"#fff"},children:F?"Suppression…":"Supprimer complètement"})]}),ne&&e.jsxs("div",{className:"ha-fiche-apercu",children:[e.jsxs("div",{className:"ha-fiche-apercu-bar no-print",children:[e.jsx(m,{onClick:()=>mt(Ce.current),children:"🖨 Imprimer / PDF"}),e.jsx(m,{kind:"soft",onClick:ze,children:"Télécharger"}),e.jsx(m,{kind:"soft",onClick:()=>Ae(null),children:"Fermer"}),e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",alignSelf:"center"},children:"C’est la note A4 générée. Si l’app capture l’écran, utilisez Télécharger puis imprimez le fichier."})]}),e.jsx("iframe",{ref:Ce,title:"Note de frais",srcDoc:ne})]})]})}function He(i){return new Date(i+"T12:00:00").toLocaleDateString("fr-BE",{weekday:"short",day:"numeric",month:"short"})}export{Bt as default};
