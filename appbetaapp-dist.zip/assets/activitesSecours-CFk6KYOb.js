import{ad as _,H as N}from"./index-9BH8jMAM.js";const E=[{v:"activite",l:"Activité"},{v:"garde",l:"Garde"},{v:"manoeuvre",l:"Manœuvre"},{v:"formation",l:"Formation"}];function q(e){var t;return((t=E.find(n=>n.v===e))==null?void 0:t.l)||"Activité"}const C=[{v:"paps",l:"Point d’alerte et de premiers secours",court:"PAPS"},{v:"pe",l:"DPS petite envergure",court:"Petite envergure"},{v:"me",l:"DPS moyenne envergure",court:"Moyenne envergure"},{v:"ge",l:"DPS grande envergure",court:"Grande envergure"}];function M(e,t=!1){const n=C.find(r=>r.v===e);return n?t?n.court:n.l:""}function k(e){if(e===""||e==null)return null;const t=Number(e);if(!(!Number.isInteger(t)||t<0||t>5e5))return t}function F(e,t,n=new Date){var a,s;if(!(Array.isArray(t==null?void 0:t.competences)?t.competences:[]).includes("chauffeur"))return!1;const o=(s=(a=e==null?void 0:e.fiche)==null?void 0:a.permis)==null?void 0:s.selection_validite;if(!o||!/^\d{4}-\d{2}-\d{2}$/.test(String(o)))return!1;const[i,u,c]=String(o).split("-").map(Number),l=new Date(i,u-1,c,23,59,59,999);return n.getTime()>l.getTime()}const x=[..._,{v:"medical",l:"Type médical"},{v:"non_medical",l:"Type non médical"}],L=new Set(x.map(e=>e.v));function O(e){var t;return((t=x.find(n=>n.v===e))==null?void 0:t.l)||e}function H(e){const t=new Set,n=[];for(const r of Array.isArray(e)?e:[])!L.has(r)||t.has(r)||(t.add(r),n.push(r));return n}function v(e){const t=(e==null?void 0:e.fiche)||{},n=new Set(N(e==null?void 0:e.role,t));return(t.type_benevole==="medical"||(e==null?void 0:e.role)==="volontaire_medical")&&n.add("medical"),(t.type_benevole==="non_medical"||(e==null?void 0:e.role)==="volontaire_non_medical")&&n.add("non_medical"),n}function P(e,t){const n=Array.isArray(e==null?void 0:e.competences)?e.competences:[];return!n.length||!t||t.size===0?!1:n.some(r=>t.has(r))}function V(e,t=new Date){const n=new Date(e==null?void 0:e.debut),r=e!=null&&e.fin?new Date(e.fin):null,o=t.getTime();return Number.isNaN(n.getTime())||o<n.getTime()?"a_venir":r&&!Number.isNaN(r.getTime())&&o<=r.getTime()?"en_cours":"terminee"}function G(e){return e==="en_cours"?"En cours":e==="terminee"?"Terminée":"À venir"}function Y(e){if(!(e!=null&&e.debut)||!(e!=null&&e.fin))return null;const t=new Date(e.fin).getTime()-new Date(e.debut).getTime();if(!(t>0))return null;const n=Math.round(t/6e4),r=Math.floor(n/60),o=n%60;return r&&o?`${r} h ${String(o).padStart(2,"0")}`:r?`${r} h`:`${o} min`}function j(e,t=new Date){const n=e!=null&&e.fin?new Date(e.fin):new Date(e==null?void 0:e.debut);return!Number.isNaN(n.getTime())&&n.getTime()>=t.getTime()}function I(e,t=new Date){const n=new Date(e);if(Number.isNaN(n.getTime()))return!1;const r=new Date(t.getFullYear(),t.getMonth(),t.getDate()),o=new Date(r);return o.setDate(o.getDate()+30),n>=r&&n<o}function J(e){var r;const t=e==null?void 0:e.role;return!t||t==="partenaire"?!1:t==="admin"||t==="president"?!0:(((r=e==null?void 0:e.fiche)==null?void 0:r.roles_asbl)||[]).some(o=>o==="president"||o==="vice_president")}function U(e,t){const n=new Map,r=new Set;for(const o of e||[])n.set(o.activite_id,(n.get(o.activite_id)||0)+1),t&&o.user_id===t&&r.add(o.activite_id);return{nombres:n,miennes:r}}function Q(e,t,n,r=new Date){const{nombres:o,miennes:i}=U(t,n==null?void 0:n.id),u=v(n);let c=0,l=0,a=0;for(const s of e||[]){const p=o.get(s.id)||0,m=j(s,r);m&&p<Number(s.places)&&!i.has(s.id)&&(c+=1),m&&P(s,u)&&(l+=1),I(s.debut,r)&&(a+=1)}return{possible:c,competence:l,bientot:a,nombres:o,miennes:i,mes:u}}function d(e){return String(e??"").replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t])}function B({organisation:e,adresse:t,logo:n,imprimePar:r,numero:o,titre:i,type:u,dispositif:c,publicAttendu:l,debut:a,fin:s,duree:p,lieu:m,places:A,inscrits:y,competences:h,personnel:b,statut:w}){const g=new Date,D=`imprimé par ${r||"Heart’s Angels"} le ${g.toLocaleDateString("fr-BE")} à ${String(g.getHours()).padStart(2,"0")}:${String(g.getMinutes()).padStart(2,"0")}`,S=(b||[]).length?b.map(f=>`<tr><td>${d(`${f.prenom||""} ${f.nom||""}`.trim()||"Compte retiré")}</td><td>${d(f.fonction||"—")}</td><td>${d(f.couverture||"—")}</td></tr>`).join(""):'<tr><td colspan="3">Personne n’est inscrite.</td></tr>',T=(h||[]).length?h.map(d).join(", "):"Aucune";return`<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>Bilan de fin — ${d(i)}</title>
<style>
  body { margin: 24px; color: #1A1514; font: 13px/1.4 "Segoe UI", system-ui, sans-serif; }
  header { display: flex; justify-content: space-between; gap: 16px; align-items: center; border-bottom: 3px solid #0E4A5A; padding-bottom: 10px; }
  header img { width: 64px; height: 64px; object-fit: contain; }
  header h1 { margin: 0; font-size: 16px; color: #0E4A5A; text-align: right; }
  header p { margin: 2px 0 0; text-align: right; color: #5c564f; }
  h2 { margin: 22px 0 8px; color: #0E4A5A; font-size: 22px; border-bottom: 3px solid #0E4A5A; display: flex; justify-content: space-between; gap: 12px; }
  h2 span { font-size: 11px; font-weight: 500; color: #5c564f; }
  h3 { margin: 18px 0 8px; color: #0E4A5A; font-size: 15px; border-left: 4px solid #1BB0CE; padding-left: 8px; }
  dl { display: grid; grid-template-columns: 180px 1fr; gap: 4px 12px; margin: 0; }
  dt { color: #7A7470; }
  dd { margin: 0; font-weight: 650; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th { background: #0E4A5A; color: #fff; text-align: left; padding: 6px 8px; }
  td { padding: 5px 8px; border-bottom: 1px solid #e3eaf3; }
  tbody tr:nth-child(even) td { background: #f7fafc; }
  .note { margin-top: 10px; color: #5c564f; font-size: 11.5px; }
  footer { margin-top: 28px; border-top: 1px solid #d5dee8; padding-top: 8px; color: #7A7470; font-size: 11px; }
  @media print { body { margin: 12mm; } }
</style></head><body>
<header>
  ${n?`<img src="${d(n)}" alt="">`:"<div></div>"}
  <div><h1>${d(e)}</h1><p>${d(t)}</p></div>
</header>
<h2>Bilan de fin <span>${d(D)}</span></h2>
<h3>${d(i||"Activité")}</h3>
<dl>
  <dt>N°</dt><dd>${d(o??"—")}</dd>
  <dt>Statut</dt><dd>${d(w||"—")}</dd>
  <dt>Type</dt><dd>${d(u||"—")}</dd>
  <dt>Dispositif</dt><dd>${d(c||"—")}</dd>
  <dt>Public attendu</dt><dd>${d(l??"—")}</dd>
  <dt>Début</dt><dd>${d(a||"—")}</dd>
  <dt>Fin</dt><dd>${d(s||"—")}</dd>
  <dt>Durée</dt><dd>${d(p||"—")}</dd>
  <dt>Lieu</dt><dd>${d(m||"—")}</dd>
  <dt>Équipe</dt><dd>${d(y)} / ${d(A)}</dd>
  <dt>Compétences demandées</dt><dd>${d(T)}</dd>
</dl>
<h3>Équipe armée</h3>
<table><thead><tr><th>Personne</th><th>Fonction</th><th>Compétences demandées</th></tr></thead><tbody>${S}</tbody></table>
<p class="note">Document généré à partir des inscriptions. Il ne contient ni victime, ni devis, ni facture.</p>
<footer>${d(e)}${t?" · "+d(t):""}</footer>
</body></html>`}function $(e){return new Blob([B(e)],{type:"text/html;charset=utf-8"})}function z(e){return`${`bilan-dispositif-${e||""}`.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"bilan-dispositif"}.html`}function K(e){if(typeof document>"u")return!1;const t=URL.createObjectURL($(e)),n=document.createElement("a");return n.href=t,n.download=z(e.titre),document.body.appendChild(n),n.click(),n.remove(),setTimeout(()=>URL.revokeObjectURL(t),1500),!0}function W(e){if(typeof window>"u")return!1;const t=URL.createObjectURL($(e)),n=window.open(t,"_blank");if(!n)return URL.revokeObjectURL(t),!1;const r=()=>{try{n.focus(),n.print()}catch{}};return n.addEventListener("load",r),setTimeout(r,400),setTimeout(()=>URL.revokeObjectURL(t),6e4),!0}export{x as C,C as D,E as T,M as a,O as b,Q as c,I as d,j as e,H as f,k as g,v as h,V as i,Y as j,G as k,q as l,W as o,J as p,P as r,F as s,K as t};
