import{r as l,j as e,L as qe}from"./vendor-react-y2xUrN8v.js";import{u as Ce,s as q,r as Ne,k as ee,o as Ae,q as N,e as I,n as Se,E as te}from"./index-CrILBbmT.js";import{p as Ee,c as De,e as O,r as Fe,d as ze,C as re,T as V,D as le,s as W,l as $e,a as ae,b as Ie,f as _e,g as U,h as Me,i as ie,j as Le,k as Te}from"./activitesSecours-pgaT3M_v.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function H(){return Object.fromEntries(le.map(r=>[r.v,0]))}const Be={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",equipes:H(),competences:[]};function x(r){return String(r).padStart(2,"0")}function J(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${x(a.getMonth()+1)}-${x(a.getDate())}`}function se(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${x(a.getDate())}-${x(a.getMonth()+1)}-${a.getFullYear()}`}function Q(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${x(a.getHours())}:${x(a.getMinutes())}`}function Pe(r){const a=se(r.debut),u=Q(r.debut);if(!r.fin)return{date:a,heures:u};const b=J(r.debut)===J(r.fin)?Q(r.fin):`${se(r.fin)} ${Q(r.fin)}`;return{date:a,heures:u&&b?`${u}–${b}`:u}}function ne(r){if(!r)return"";const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${x(a.getMonth()+1)}-${x(a.getDate())}T${x(a.getHours())}:${x(a.getMinutes())}`}function oe(r){if(!r)return null;const a=new Date(r);return Number.isNaN(a.getTime())?null:a.toISOString()}function ce(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Re(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Oe(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Ge(){const{profile:r}=Ce(),a=Ee(r),[u,v]=l.useState([]),[b,S]=l.useState([]),[C,G]=l.useState(!0),[K,_]=l.useState(null),[X,d]=l.useState(null),[w,ue]=l.useState(null),[E,de]=l.useState(""),[D,pe]=l.useState(""),[F,he]=l.useState(""),[M,me]=l.useState(""),[L,xe]=l.useState("asc"),[T,B]=l.useState(null),[n,j]=l.useState(null),[A,z]=l.useState(!1);l.useEffect(()=>{$()},[r==null?void 0:r.id]);async function $(t=!1){var o,c;t||G(!0),_(null);const[i,s]=await Promise.all([q.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),q.from("activites_secours_inscrits").select("id,activite_id,user_id")]);i.error||s.error?(_(((o=i.error)==null?void 0:o.message)||((c=s.error)==null?void 0:c.message)||"Chargement impossible."),v([]),S([])):(v(Array.isArray(i.data)?i.data:[]),S(Array.isArray(s.data)?s.data:[])),G(!1)}const p=l.useMemo(()=>De(u,b,r),[u,b,r]),Z=l.useMemo(()=>{const t=M.trim().toLowerCase(),i=u.filter(s=>{const o=p.nombres.get(s.id)||0;if(w==="possible"&&!(O(s)&&o<Number(s.places)&&!p.miennes.has(s.id))||w==="competence"&&!(O(s)&&Fe(s,p.mes))||w==="bientot"&&!ze(s.debut)||E&&!(s.competences||[]).includes(E))return!1;const c=J(s.debut);return!(D&&c&&c<D||F&&c&&c>F||t&&!`${s.numero||""} ${s.titre||""} ${s.lieu||""}`.toLowerCase().includes(t))});return i.sort((s,o)=>{const c=String(s.debut).localeCompare(String(o.debut));return L==="asc"?c:-c}),i},[u,p,w,E,D,F,M,L]);function P(t){ue(i=>i===t?null:t)}async function be(t){if(!(r!=null&&r.id)||T)return;B(t.id),d(null);const i=p.miennes.has(t.id);if(!i&&_e(r,t)){d("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),B(null);return}const s=i?await q.from("activites_secours_inscrits").delete().eq("activite_id",t.id).eq("user_id",r.id):await q.from("activites_secours_inscrits").insert({activite_id:t.id,user_id:r.id});s.error?d(s.error.message||"Inscription impossible."):await $(!0),B(null)}function fe(){_(null),j({...Be,equipes:H(),competences:[]})}function ge(t){j({id:t.id,titre:t.titre||"",type:V.some(i=>i.v===t.type)?t.type:"activite",lieu:t.lieu||"",debut:ne(t.debut),fin:ne(t.fin),places:String(t.places??1),publicAttendu:t.public_attendu==null?"":String(t.public_attendu),equipes:{...H(),...Me(t)},competences:U(t.competences)})}function k(t){j(i=>({...i,...t}))}function R(t,i,s=!1){ie.has(t)&&j(o=>{var g;const c=Number(((g=o.equipes)==null?void 0:g[t])||0);let h=s?Number(i):c+Number(i);(!Number.isFinite(h)||h<0)&&(h=0),h=Math.min(20,Math.floor(h));const f={...o.equipes,[t]:h},m=W(f);return{...o,equipes:f,places:m?m.places:o.places,competences:m?U(m.competences):[]}})}function ve(t){j(i=>{const s=i.competences.includes(t)?i.competences.filter(o=>o!==t):[...i.competences,t];return{...i,competences:s}})}async function je(t){if(t.preventDefault(),!n||A)return;const i=n.titre.trim(),s=oe(n.debut),o=oe(n.fin),c=Number(n.places);if(!i){d("Indiquez le titre.");return}if(!s){d("Indiquez le début.");return}if(n.fin&&!o){d("La fin est illisible.");return}if(o&&o<s){d("La fin est avant le début.");return}if(!Number.isInteger(c)||c<1||c>500){d("Le nombre de places doit être entre 1 et 500.");return}const h=Le(n.publicAttendu);if(h===void 0){d("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}const f=Te(n.equipes);if(Object.keys(n.equipes||{}).some(y=>!ie.has(y))){d("Une des équipes est inconnue.");return}z(!0),d(null);const m={titre:i,type:V.some(y=>y.v===n.type)?n.type:"activite",dispositifs:f,dispositif:f[0]||null,public_attendu:h,lieu:n.lieu.trim()||null,debut:s,fin:o,places:c,competences:U(n.competences)},g=n.id?await q.from("activites_secours").update(m).eq("id",n.id):await q.from("activites_secours").insert({...m,created_by:(r==null?void 0:r.id)||null});g.error?d(g.error.message||"Enregistrement impossible."):(j(null),await $(!0)),z(!1)}async function ye(t){if(!t||A||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;z(!0),d(null);const i=await q.from("activites_secours").delete().eq("id",t);i.error?d(i.error.message||"Suppression impossible."):(j(null),await $(!0)),z(!1)}const we=!C&&u.length===0,ke=!C&&u.length>0&&Z.length===0;return e.jsxs(Ne,{title:"Activités",subtitle:"Département secours. Une activité se dimensionne, s’arme, puis se rend en bilan.",action:a?e.jsx(I,{onClick:fe,children:"+ Activité"}):null,children:[e.jsx("style",{children:We}),K&&e.jsx(ee,{kind:"err",children:K}),X&&e.jsx(ee,{kind:"err",children:X}),e.jsxs("div",{className:"ha-act-cartes",children:[e.jsx(Y,{tone:"possible",on:w==="possible",n:C?"…":p.possible,label:"Inscription possible",icone:e.jsx(ce,{}),onClick:()=>P("possible")}),e.jsx(Y,{tone:"competence",on:w==="competence",n:C?"…":p.competence,label:"Requiert ma compétence",icone:e.jsx(Re,{}),onClick:()=>P("competence")}),e.jsx(Y,{tone:"bientot",on:w==="bientot",n:C?"…":p.bientot,label:"Sur les 30 prochains jours",icone:e.jsx(Oe,{}),onClick:()=>P("bientot")})]}),e.jsxs("div",{className:"ha-act-filtres",children:[e.jsxs("select",{"aria-label":"Compétence",value:E,onChange:t=>de(t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les activités"}),re.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]}),e.jsxs("label",{className:"ha-act-dates",children:[e.jsx("span",{className:"ha-sr",children:"Du"}),e.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:D,onChange:t=>pe(t.target.value)}),e.jsx("span",{children:"au"}),e.jsx("span",{className:"ha-sr",children:"Au"}),e.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:F,onChange:t=>he(t.target.value)})]}),e.jsxs("label",{className:"ha-act-recherche",children:[e.jsx("span",{className:"ha-sr",children:"Rechercher"}),e.jsx("input",{type:"search",placeholder:"Rechercher",value:M,onChange:t=>me(t.target.value)})]})]}),n&&e.jsx(Ae,{style:{marginBottom:14},children:e.jsxs("form",{onSubmit:je,children:[e.jsxs("div",{className:"ha-act-form",children:[e.jsx(N,{label:"Titre",value:n.titre,set:t=>k({titre:t}),required:!0}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),e.jsx("select",{value:n.type,onChange:t=>k({type:t.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:V.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))})]}),e.jsx(N,{label:"Lieu",value:n.lieu,set:t=>k({lieu:t})}),e.jsx(N,{label:"Début",type:"datetime-local",value:n.debut,set:t=>k({debut:t}),required:!0}),e.jsx(N,{label:"Fin",type:"datetime-local",value:n.fin,set:t=>k({fin:t})}),e.jsx(N,{label:"Places",type:"number",value:n.places,set:t=>k({places:t}),required:!0}),e.jsx(N,{label:"Public attendu",type:"number",value:n.publicAttendu,set:t=>k({publicAttendu:t})})]}),e.jsxs("div",{style:{marginBottom:10},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Équipes / dispositifs"}),e.jsx("div",{className:"ha-act-equipes-qte",role:"group","aria-label":"Quantité par équipe",children:le.map(t=>{var s;const i=Number(((s=n.equipes)==null?void 0:s[t.v])||0);return e.jsxs("div",{className:"ha-act-equipe-ligne"+(i>0?" is-on":""),children:[e.jsxs("div",{className:"ha-act-equipe-nom",children:[e.jsx("strong",{children:t.court}),e.jsx("span",{children:t.l.replace(/^[^—]+—\s*/,"")})]}),e.jsxs("div",{className:"ha-act-equipe-stepper",children:[e.jsx("button",{type:"button","aria-label":`Retirer un ${t.court}`,disabled:i<=0,onClick:()=>R(t.v,-1),children:"−"}),e.jsx("input",{type:"number",min:0,max:20,value:i,"aria-label":`Nombre de ${t.court}`,onChange:o=>R(t.v,o.target.value,!0)}),e.jsx("button",{type:"button","aria-label":`Ajouter un ${t.court}`,disabled:i>=20,onClick:()=>R(t.v,1),children:"+"})]})]},t.v)})})]}),Object.values(n.equipes||{}).some(t=>t>0)&&W(n.equipes)&&e.jsxs("p",{className:"ha-act-note",style:{color:"var(--heading)"},children:["Effectif minimum : ",W(n.equipes).resume,". Places et compétences sont préremplies — vous pouvez encore les ajuster."]}),e.jsx("p",{className:"ha-act-note",children:"Indiquez combien de chaque équipe (ex. 2 AMBU + 1 PMA). Un préventif peut en combiner plusieurs. Matrices = département secours uniquement. « Secouriste minimum » = ordre des qualifications 1→7."}),e.jsxs("div",{style:{marginBottom:8},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),e.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:re.map(t=>e.jsx("button",{type:"button",className:"ha-act-choix-btn"+(n.competences.includes(t.v)?" is-on":""),"aria-pressed":n.competences.includes(t.v),onClick:()=>ve(t.v),children:t.l},t.v))}),e.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, SIAMU, et type médical ou non médical."})]}),e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[e.jsx(I,{type:"submit",disabled:A,children:n.id?"Enregistrer":"Créer l’activité"}),e.jsx(I,{kind:"soft",onClick:()=>j(null),disabled:A,children:"Annuler"}),n.id&&e.jsx(I,{kind:"danger",onClick:()=>ye(n.id),disabled:A,children:"Retirer"})]})]})}),C?e.jsx(Se,{}):we?e.jsx(te,{title:"Aucune activité pour le moment",hint:a?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):ke?e.jsx(te,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):e.jsx("div",{className:"ha-act-table-wrap",children:e.jsxs("table",{className:"ha-act-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Activité"}),e.jsx("th",{children:"Lieu"}),e.jsx("th",{children:e.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>xe(t=>t==="asc"?"desc":"asc"),children:["Date ",e.jsx("span",{"aria-hidden":!0,children:L==="asc"?"↑":"↓"})]})}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{children:"Inscrit"}),e.jsx("th",{children:"Actions"})]})}),e.jsx("tbody",{children:Z.map(t=>{const i=p.nombres.get(t.id)||0,s=Number(t.places)||0,o=p.miennes.has(t.id),c=O(t),h=i>=s,f=Pe(t);let m="S’inscrire",g=!1;return o?m="Se désinscrire":c?h&&(m="Complet",g=!0):(m="Terminée",g=!0),e.jsxs("tr",{children:[e.jsx("td",{className:"ha-act-id",children:t.numero}),e.jsxs("td",{children:[e.jsx(qe,{to:`/app/secours/activites/${t.id}`,className:"ha-act-titre",children:t.titre}),e.jsxs("div",{className:"ha-act-type",children:[$e(t.type),ae(t)?` · ${ae(t)}`:""]})]}),e.jsx("td",{className:"ha-act-lieu",children:t.lieu||"—"}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-quand",children:[e.jsx("strong",{children:f.date}),f.heures&&e.jsx("span",{children:f.heures})]})}),e.jsx("td",{children:(t.competences||[]).length===0?e.jsx("span",{className:"ha-act-aucune",children:"—"}):(t.competences||[]).map(y=>e.jsxs("span",{className:"ha-act-chip"+(p.mes.has(y)?" is-moi":" is-autre"),children:[p.mes.has(y)?"✓":"•"," ",Ie(y)]},y))}),e.jsx("td",{children:e.jsx(Ve,{inscrits:i,places:s})}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-actions",children:[e.jsxs("button",{type:"button",className:"ha-act-go"+(o?" is-off":""),disabled:g||T===t.id,onClick:()=>be(t),children:[e.jsx(ce,{}),T===t.id?"…":m]}),a&&e.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>ge(t),children:"Modifier"})]})})]},t.id)})})]})})]})}function Y({tone:r,on:a,n:u,label:v,icone:b,onClick:S}){return e.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(a?" is-on":""),"aria-pressed":a,onClick:S,children:[e.jsx("span",{className:"ha-act-carte-n",children:u}),e.jsx("span",{className:"ha-act-carte-l",children:v}),e.jsx("span",{className:"ha-act-carte-ico is-"+r,children:b})]})}function Ve({inscrits:r,places:a}){const u=a>0?Math.min(1,r/a):0,v=a>0&&r>=a,b=r===0?0:Math.max(u*100,18);return e.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${a} place${a>1?"s":""}`,children:[e.jsx("span",{style:{width:`${b}%`,background:v?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),e.jsxs("em",{style:{color:u>=.55||v?"#fff":"var(--text)"},children:[r,"/",a]})]})}const We=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-equipes-qte { display: flex; flex-direction: column; gap: 8px; margin-top: 8px; }
.ha-act-equipe-ligne {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface);
  grid-column: 1 / -1;
}
.ha-act-equipe-ligne.is-on { border-color: var(--accent); }
.ha-act-equipe-nom { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.ha-act-equipe-nom strong { font-size: 13.5px; color: var(--heading); }
.ha-act-equipe-nom span { font-size: 11.5px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 52vw; }
.ha-act-equipe-stepper { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }
.ha-act-equipe-stepper button {
  width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--heading); font-size: 18px; line-height: 1;
  font-family: inherit; cursor: pointer;
}
.ha-act-equipe-stepper button:disabled { opacity: .35; cursor: default; }
.ha-act-equipe-stepper input {
  width: 44px; text-align: center; padding: 6px 4px; border: 1px solid var(--border);
  border-radius: 8px; background: var(--surface); color: var(--text); font-family: inherit; font-size: 14px;
}
.ha-act-equipe-stepper input::-webkit-outer-spin-button,
.ha-act-equipe-stepper input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ha-act-equipe-stepper input[type=number] { -moz-appearance: textfield; appearance: textfield; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Ge as default};
