import{r as d,j as t,L as ce}from"./vendor-react-B2tzVpxG.js";import{u as Te,s as w,r as Ve,k as de,o as We,q as x,e as I,n as Oe,E as pe}from"./index--U4HYe16.js";import{p as Ue,c as Qe,e as O,r as Ye,d as He,C as ue,T as U,P as he,a as Q,b as me,f as Y,g as xe,h as be,D as Ce,s as H,l as Je,i as fe,j as Ge,k as Ke,m as J,n as Xe,o as ge,q as Ze}from"./activitesSecours-B7gs1zNO.js";import"./vendor-gshAQajk.js";import"./vendor-supabase-1THz1qjC.js";function Z(){return Object.fromEntries(Ce.map(a=>[a.v,0]))}const et={id:null,titre:"",type:"preventif",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",adresseMode:"exacte",adresseRue:"",adresseNumero:"",adresseCp:"",adresseVille:"",adresseProvince:"",organisateurNom:"",organisateurContact:"",responsablePreventifId:"",dispAlphaId:"",dispBravoId:"",equipes:Z(),competences:[]};function G(a){return a?`${a.prenom||""} ${a.nom||""}`.trim()||a.email||a.id:"—"}function y(a){return String(a).padStart(2,"0")}function ee(a){const s=new Date(a);return Number.isNaN(s.getTime())?"":`${s.getFullYear()}-${y(s.getMonth()+1)}-${y(s.getDate())}`}function ve(a){const s=new Date(a);return Number.isNaN(s.getTime())?"":`${y(s.getDate())}-${y(s.getMonth()+1)}-${s.getFullYear()}`}function K(a){const s=new Date(a);return Number.isNaN(s.getTime())?"":`${y(s.getHours())}:${y(s.getMinutes())}`}function tt(a){const s=ve(a.debut),u=K(a.debut);if(!a.fin)return{date:s,heures:u};const b=ee(a.debut)===ee(a.fin)?K(a.fin):`${ve(a.fin)} ${K(a.fin)}`;return{date:s,heures:u&&b?`${u}–${b}`:u}}function je(a){if(!a)return"";const s=new Date(a);return Number.isNaN(s.getTime())?"":`${s.getFullYear()}-${y(s.getMonth()+1)}-${y(s.getDate())}T${y(s.getHours())}:${y(s.getMinutes())}`}function ye(a){if(!a)return null;const s=new Date(a);return Number.isNaN(s.getTime())?null:s.toISOString()}function ke(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function rt(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function at(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function pt(){const{profile:a}=Te(),s=Ue(a),[u,k]=d.useState([]),[b,D]=d.useState([]),[q,te]=d.useState(!0),[re,F]=d.useState(null),[ae,p]=d.useState(null),[N,we]=d.useState(null),[E,Ne]=d.useState(""),[B,qe]=d.useState(""),[z,Ae]=d.useState(""),[$,_e]=d.useState(""),[R,Se]=d.useState("asc"),[L,T]=d.useState(null),[r,C]=d.useState(null),[S,P]=d.useState(!1),[A,Ie]=d.useState([]);d.useEffect(()=>{M()},[a==null?void 0:a.id]);async function M(e=!1){var o,h;e||te(!0),F(null);const[i,n,l]=await Promise.all([w.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,adresse,adresse_mode,adresse_rue,adresse_numero,adresse_cp,adresse_ville,adresse_province,organisateur_nom,organisateur_contact,responsable_preventif_id,disp_alpha_id,disp_bravo_id,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),w.from("activites_secours_inscrits").select("id,activite_id,user_id"),s?w.from("profiles").select("id,prenom,nom,email,role,fiche,actif").neq("role","partenaire").eq("actif",!0).order("nom"):Promise.resolve({data:[],error:null})]);i.error||n.error?(F(((o=i.error)==null?void 0:o.message)||((h=n.error)==null?void 0:h.message)||"Chargement impossible."),k([]),D([])):(k(Array.isArray(i.data)?i.data:[]),D(Array.isArray(n.data)?n.data:[])),l.error||Ie(Array.isArray(l.data)?l.data:[]),te(!1)}const f=d.useMemo(()=>Qe(u,b,a),[u,b,a]),se=d.useMemo(()=>{const e=$.trim().toLowerCase(),i=u.filter(n=>{const l=f.nombres.get(n.id)||0;if(N==="possible"&&!(O(n)&&l<Number(n.places)&&!f.miennes.has(n.id))||N==="competence"&&!(O(n)&&Ye(n,f.mes))||N==="bientot"&&!He(n.debut)||E&&!(n.competences||[]).includes(E))return!1;const o=ee(n.debut);return!(B&&o&&o<B||z&&o&&o>z||e&&!`${n.numero||""} ${n.titre||""} ${n.lieu||""}`.toLowerCase().includes(e))});return i.sort((n,l)=>{const o=String(n.debut).localeCompare(String(l.debut));return R==="asc"?o:-o}),i},[u,f,N,E,B,z,$,R]);function V(e){we(i=>i===e?null:e)}async function De(e){if(!(a!=null&&a.id)||L)return;T(e.id),p(null);const i=f.miennes.has(e.id);if(!i&&Ke(a,e)){p("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),T(null);return}const n=i?await w.from("activites_secours_inscrits").delete().eq("activite_id",e.id).eq("user_id",a.id):await w.from("activites_secours_inscrits").insert({activite_id:e.id,user_id:a.id});n.error?p(n.error.message||"Inscription impossible."):await M(!0),T(null)}function Ee(){F(null),C({...et,equipes:Z(),competences:[],responsablePreventifId:(a==null?void 0:a.id)||"",dispAlphaId:me(a)&&(a==null?void 0:a.id)||""})}function Be(e){const i=b.filter(o=>o.activite_id===e.id).map(o=>o.user_id),n=new Map(A.map(o=>[o.id,o])),l=Y(i,n);C({id:e.id,titre:e.titre||"",type:U.some(o=>o.v===e.type)?e.type:"preventif",lieu:e.lieu||"",debut:je(e.debut),fin:je(e.fin),places:String(e.places??1),publicAttendu:e.public_attendu==null?"":String(e.public_attendu),adresseMode:e.adresse_mode==="approximative"?"approximative":"exacte",adresseRue:e.adresse_rue||"",adresseNumero:e.adresse_numero||"",adresseCp:e.adresse_cp||"",adresseVille:e.adresse_ville||"",adresseProvince:e.adresse_province||"",organisateurNom:e.organisateur_nom||"",organisateurContact:e.organisateur_contact||"",responsablePreventifId:e.responsable_preventif_id||"",dispAlphaId:l||e.disp_alpha_id||"",dispBravoId:e.disp_bravo_id||"",equipes:{...Z(),...Xe(e)},competences:J(e.competences)})}function c(e){C(i=>({...i,...e}))}function W(e,i,n=!1){ge.has(e)&&C(l=>{var v;const o=Number(((v=l.equipes)==null?void 0:v[e])||0);let h=n?Number(i):o+Number(i);(!Number.isFinite(h)||h<0)&&(h=0),h=Math.min(20,Math.floor(h));const g={...l.equipes,[e]:h},m=H(g);return{...l,equipes:g,places:m?m.places:l.places,competences:m?J(m.competences):[]}})}function ze(e){C(i=>{const n=i.competences.includes(e)?i.competences.filter(l=>l!==e):[...i.competences,e];return{...i,competences:n}})}async function Pe(e){if(e.preventDefault(),!r||S)return;const i=r.titre.trim(),n=ye(r.debut),l=ye(r.fin),o=Number(r.places);if(!i){p("Indiquez le titre.");return}if(!n){p("Indiquez le début.");return}if(r.fin&&!l){p("La fin est illisible.");return}if(l&&l<n){p("La fin est avant le début.");return}if(!Number.isInteger(o)||o<1||o>500){p("Le nombre de places doit être entre 1 et 500.");return}const h=Ze(r.publicAttendu);if(h===void 0){p("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}const g=be(r.equipes);if(Object.keys(r.equipes||{}).some(j=>!ge.has(j))){p("Une des équipes est inconnue.");return}const m=r.adresseMode==="approximative"?"approximative":"exacte";if(m==="exacte"&&!r.adresseRue.trim()&&!r.adresseNumero.trim()&&r.adresseVille.trim(),m==="approximative"&&r.adresseCp.trim()&&!r.adresseVille.trim()){p("En mode approximatif, indiquez au moins la ville avec le code postal.");return}const v=he.includes(r.adresseProvince)?r.adresseProvince:null;if(r.type==="preventif"&&!v){p("Indiquez la province du préventif (lien RescueTrack).");return}const _=Q({mode:m,rue:r.adresseRue.trim(),numero:r.adresseNumero.trim(),cp:r.adresseCp.trim(),ville:r.adresseVille.trim(),province:v})||null,Re=r.id?b.filter(j=>j.activite_id===r.id).map(j=>j.user_id):[],Le=new Map(A.map(j=>[j.id,j])),ie=Y(Re,Le);let ne=r.dispAlphaId||null;if(ie&&(ne=ie),xe(o,g)&&!r.dispBravoId){p("Sur un gros préventif, désignez un Disp Bravo.");return}P(!0),p(null);const oe={titre:i,type:U.some(j=>j.v===r.type)?r.type:"preventif",dispositifs:g,dispositif:g[0]||null,public_attendu:h,lieu:r.lieu.trim()||null,adresse_mode:m,adresse_rue:r.adresseRue.trim()||null,adresse_numero:r.adresseNumero.trim()||null,adresse_cp:r.adresseCp.trim()||null,adresse_ville:r.adresseVille.trim()||null,adresse_province:v,adresse:_,organisateur_nom:r.organisateurNom.trim()||null,organisateur_contact:r.organisateurContact.trim()||null,responsable_preventif_id:r.responsablePreventifId||null,disp_alpha_id:ne||null,disp_bravo_id:r.dispBravoId||null,debut:n,fin:l,places:o,competences:J(r.competences)},le=r.id?await w.from("activites_secours").update(oe).eq("id",r.id):await w.from("activites_secours").insert({...oe,created_by:(a==null?void 0:a.id)||null});le.error?p(le.error.message||"Enregistrement impossible."):(C(null),await M(!0)),P(!1)}async function Me(e){if(!e||S||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;P(!0),p(null);const i=await w.from("activites_secours").delete().eq("id",e);i.error?p(i.error.message||"Suppression impossible."):(C(null),await M(!0)),P(!1)}const Fe=!q&&u.length===0,$e=!q&&u.length>0&&se.length===0;return t.jsxs(Ve,{title:"Activités",subtitle:s?"DPS : adresse rue/n° ou CP/ville · responsable · Disp Alpha/Bravo · types élargis · conventions.":"Département secours. Inscriptions — création réservée aux responsables / adjoints DPS.",action:s?t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(ce,{to:"/app/secours/conventions",children:t.jsx(I,{kind:"soft",children:"Conventions DPS"})}),t.jsx(I,{onClick:Ee,children:"+ Activité"})]}):null,children:[t.jsx("style",{children:it}),re&&t.jsx(de,{kind:"err",children:re}),ae&&t.jsx(de,{kind:"err",children:ae}),t.jsxs("div",{className:"ha-act-cartes",children:[t.jsx(X,{tone:"possible",on:N==="possible",n:q?"…":f.possible,label:"Inscription possible",icone:t.jsx(ke,{}),onClick:()=>V("possible")}),t.jsx(X,{tone:"competence",on:N==="competence",n:q?"…":f.competence,label:"Requiert ma compétence",icone:t.jsx(rt,{}),onClick:()=>V("competence")}),t.jsx(X,{tone:"bientot",on:N==="bientot",n:q?"…":f.bientot,label:"Sur les 30 prochains jours",icone:t.jsx(at,{}),onClick:()=>V("bientot")})]}),t.jsxs("div",{className:"ha-act-filtres",children:[t.jsxs("select",{"aria-label":"Compétence",value:E,onChange:e=>Ne(e.target.value),children:[t.jsx("option",{value:"",children:"Toutes les activités"}),ue.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))]}),t.jsxs("label",{className:"ha-act-dates",children:[t.jsx("span",{className:"ha-sr",children:"Du"}),t.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:B,onChange:e=>qe(e.target.value)}),t.jsx("span",{children:"au"}),t.jsx("span",{className:"ha-sr",children:"Au"}),t.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:z,onChange:e=>Ae(e.target.value)})]}),t.jsxs("label",{className:"ha-act-recherche",children:[t.jsx("span",{className:"ha-sr",children:"Rechercher"}),t.jsx("input",{type:"search",placeholder:"Rechercher",value:$,onChange:e=>_e(e.target.value)})]})]}),r&&t.jsx(We,{style:{marginBottom:14},children:t.jsxs("form",{onSubmit:Pe,children:[t.jsxs("div",{className:"ha-act-form",children:[t.jsx(x,{label:"Titre",value:r.titre,set:e=>c({titre:e}),required:!0}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),t.jsx("select",{value:r.type,onChange:e=>c({type:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:U.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))})]}),t.jsx(x,{label:"Lieu (libellé)",value:r.lieu,set:e=>c({lieu:e})}),t.jsx(x,{label:"Organisateur",value:r.organisateurNom,set:e=>c({organisateurNom:e})}),t.jsx(x,{label:"Contact organisateur",value:r.organisateurContact,set:e=>c({organisateurContact:e})}),t.jsx(x,{label:"Début",type:"datetime-local",value:r.debut,set:e=>c({debut:e}),required:!0}),t.jsx(x,{label:"Fin",type:"datetime-local",value:r.fin,set:e=>c({fin:e})}),t.jsx(x,{label:"Places",type:"number",value:r.places,set:e=>c({places:e}),required:!0}),t.jsx(x,{label:"Public attendu",type:"number",value:r.publicAttendu,set:e=>c({publicAttendu:e})})]}),t.jsxs("div",{style:{marginBottom:12,padding:"10px 12px",border:"1px solid var(--border)",borderRadius:10},children:[t.jsxs("div",{style:{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center",marginBottom:8},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",fontWeight:650},children:"Adresse du site"}),t.jsxs("label",{style:{fontSize:13,display:"flex",gap:6,alignItems:"center"},children:[t.jsx("input",{type:"radio",name:"adresseMode",checked:r.adresseMode==="exacte",onChange:()=>c({adresseMode:"exacte"})}),"Exacte (rue + n°)"]}),t.jsxs("label",{style:{fontSize:13,display:"flex",gap:6,alignItems:"center"},children:[t.jsx("input",{type:"radio",name:"adresseMode",checked:r.adresseMode==="approximative",onChange:()=>c({adresseMode:"approximative"})}),"Approximative (CP + ville)"]})]}),t.jsxs("div",{className:"ha-act-form",children:[r.adresseMode==="exacte"?t.jsxs(t.Fragment,{children:[t.jsx(x,{label:"Rue",value:r.adresseRue,set:e=>c({adresseRue:e})}),t.jsx(x,{label:"Numéro",value:r.adresseNumero,set:e=>c({adresseNumero:e})}),t.jsx(x,{label:"Code postal",value:r.adresseCp,set:e=>c({adresseCp:e})}),t.jsx(x,{label:"Ville",value:r.adresseVille,set:e=>c({adresseVille:e})})]}):t.jsxs(t.Fragment,{children:[t.jsx(x,{label:"Code postal",value:r.adresseCp,set:e=>c({adresseCp:e})}),t.jsx(x,{label:"Ville",value:r.adresseVille,set:e=>c({adresseVille:e})})]}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsxs("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:["Province",r.type==="preventif"?" (requise — RescueTrack)":""]}),t.jsxs("select",{value:r.adresseProvince||"",onChange:e=>c({adresseProvince:e.target.value}),required:r.type==="preventif",style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[t.jsx("option",{value:"",children:"— Choisir —"}),he.map(e=>t.jsx("option",{value:e,children:e},e))]})]})]}),Q({mode:r.adresseMode,rue:r.adresseRue,numero:r.adresseNumero,cp:r.adresseCp,ville:r.adresseVille,province:r.adresseProvince})&&t.jsxs("p",{className:"ha-act-note",style:{marginBottom:0},children:["Affichage : ",Q({mode:r.adresseMode,rue:r.adresseRue,numero:r.adresseNumero,cp:r.adresseCp,ville:r.adresseVille,province:r.adresseProvince})]})]}),t.jsxs("div",{style:{marginBottom:12,padding:"10px 12px",border:"1px solid var(--border)",borderRadius:10},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",fontWeight:650,display:"block",marginBottom:8},children:"Commandement du préventif"}),t.jsxs("div",{className:"ha-act-form",children:[t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Responsable de préventif"}),t.jsxs("select",{value:r.responsablePreventifId,onChange:e=>c({responsablePreventifId:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[t.jsx("option",{value:"",children:"—"}),A.map(e=>t.jsx("option",{value:e.id,children:G(e)},e.id))]})]}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Disp Alpha"}),t.jsxs("select",{value:r.dispAlphaId,disabled:!!Y(r.id?b.filter(e=>e.activite_id===r.id).map(e=>e.user_id):[],new Map(A.map(e=>[e.id,e]))),onChange:e=>c({dispAlphaId:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[t.jsx("option",{value:"",children:"—"}),A.map(e=>t.jsxs("option",{value:e.id,children:[G(e),me(e)?" (resp. DPS)":""]},e.id))]})]}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsxs("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:["Disp Bravo",xe(Number(r.places),be(r.equipes))?" (requis)":" (optionnel)"]}),t.jsxs("select",{value:r.dispBravoId,onChange:e=>c({dispBravoId:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[t.jsx("option",{value:"",children:"—"}),A.map(e=>t.jsx("option",{value:e.id,children:G(e)},e.id))]})]})]}),t.jsx("p",{className:"ha-act-note",style:{marginBottom:0},children:"Si un responsable DPS est inscrit sur le préventif, il devient d’office Disp Alpha. Les adjoints DPS gèrent aussi les préventifs dans l’app."})]}),t.jsxs("div",{style:{marginBottom:10},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Équipes / dispositifs"}),t.jsx("div",{className:"ha-act-equipes-qte",role:"group","aria-label":"Quantité par équipe",children:Ce.map(e=>{var n;const i=Number(((n=r.equipes)==null?void 0:n[e.v])||0);return t.jsxs("div",{className:"ha-act-equipe-ligne"+(i>0?" is-on":""),children:[t.jsxs("div",{className:"ha-act-equipe-nom",children:[t.jsx("strong",{children:e.court}),t.jsx("span",{children:e.l.replace(/^[^—]+—\s*/,"")})]}),t.jsxs("div",{className:"ha-act-equipe-stepper",children:[t.jsx("button",{type:"button","aria-label":`Retirer un ${e.court}`,disabled:i<=0,onClick:()=>W(e.v,-1),children:"−"}),t.jsx("input",{type:"number",min:0,max:20,value:i,"aria-label":`Nombre de ${e.court}`,onChange:l=>W(e.v,l.target.value,!0)}),t.jsx("button",{type:"button","aria-label":`Ajouter un ${e.court}`,disabled:i>=20,onClick:()=>W(e.v,1),children:"+"})]})]},e.v)})})]}),Object.values(r.equipes||{}).some(e=>e>0)&&H(r.equipes)&&t.jsxs("p",{className:"ha-act-note",style:{color:"var(--heading)"},children:["Effectif minimum : ",H(r.equipes).resume,". Places et compétences sont préremplies — vous pouvez encore les ajuster."]}),t.jsx("p",{className:"ha-act-note",children:"Indiquez combien de chaque équipe (ex. 2 AMBU + 1 PMA). Un préventif peut en combiner plusieurs. Matrices = département secours uniquement. « Secouriste minimum » = ordre des qualifications 1→7."}),t.jsxs("div",{style:{marginBottom:8},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),t.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:ue.map(e=>t.jsx("button",{type:"button",className:"ha-act-choix-btn"+(r.competences.includes(e.v)?" is-on":""),"aria-pressed":r.competences.includes(e.v),onClick:()=>ze(e.v),children:e.l},e.v))}),t.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, SIAMU, et type médical ou non médical."})]}),t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(I,{type:"submit",disabled:S,children:r.id?"Enregistrer":"Créer l’activité"}),t.jsx(I,{kind:"soft",onClick:()=>C(null),disabled:S,children:"Annuler"}),r.id&&t.jsx(I,{kind:"danger",onClick:()=>Me(r.id),disabled:S,children:"Retirer"})]})]})}),q?t.jsx(Oe,{}):Fe?t.jsx(pe,{title:"Aucune activité pour le moment",hint:s?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):$e?t.jsx(pe,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):t.jsx("div",{className:"ha-act-table-wrap",children:t.jsxs("table",{className:"ha-act-table",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"ID"}),t.jsx("th",{children:"Activité"}),t.jsx("th",{children:"Lieu"}),t.jsx("th",{children:t.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>Se(e=>e==="asc"?"desc":"asc"),children:["Date ",t.jsx("span",{"aria-hidden":!0,children:R==="asc"?"↑":"↓"})]})}),t.jsx("th",{children:"Compétence"}),t.jsx("th",{children:"Inscrit"}),t.jsx("th",{children:"Actions"})]})}),t.jsx("tbody",{children:se.map(e=>{const i=f.nombres.get(e.id)||0,n=Number(e.places)||0,l=f.miennes.has(e.id),o=O(e),h=i>=n,g=tt(e);let m="S’inscrire",v=!1;return l?m="Se désinscrire":o?h&&(m="Complet",v=!0):(m="Terminée",v=!0),t.jsxs("tr",{children:[t.jsx("td",{className:"ha-act-id",children:e.numero}),t.jsxs("td",{children:[t.jsx(ce,{to:`/app/secours/activites/${e.id}`,className:"ha-act-titre",children:e.titre}),t.jsxs("div",{className:"ha-act-type",children:[Je(e.type),fe(e)?` · ${fe(e)}`:""]})]}),t.jsx("td",{className:"ha-act-lieu",children:e.lieu||"—"}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-quand",children:[t.jsx("strong",{children:g.date}),g.heures&&t.jsx("span",{children:g.heures})]})}),t.jsx("td",{children:(e.competences||[]).length===0?t.jsx("span",{className:"ha-act-aucune",children:"—"}):(e.competences||[]).map(_=>t.jsxs("span",{className:"ha-act-chip"+(f.mes.has(_)?" is-moi":" is-autre"),children:[f.mes.has(_)?"✓":"•"," ",Ge(_)]},_))}),t.jsx("td",{children:t.jsx(st,{inscrits:i,places:n})}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-actions",children:[t.jsxs("button",{type:"button",className:"ha-act-go"+(l?" is-off":""),disabled:v||L===e.id,onClick:()=>De(e),children:[t.jsx(ke,{}),L===e.id?"…":m]}),s&&t.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>Be(e),children:"Modifier"})]})})]},e.id)})})]})})]})}function X({tone:a,on:s,n:u,label:k,icone:b,onClick:D}){return t.jsxs("button",{type:"button",className:"ha-act-carte is-"+a+(s?" is-on":""),"aria-pressed":s,onClick:D,children:[t.jsx("span",{className:"ha-act-carte-n",children:u}),t.jsx("span",{className:"ha-act-carte-l",children:k}),t.jsx("span",{className:"ha-act-carte-ico is-"+a,children:b})]})}function st({inscrits:a,places:s}){const u=s>0?Math.min(1,a/s):0,k=s>0&&a>=s,b=a===0?0:Math.max(u*100,18);return t.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${a} inscrit${a>1?"s":""} sur ${s} place${s>1?"s":""}`,children:[t.jsx("span",{style:{width:`${b}%`,background:k?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),t.jsxs("em",{style:{color:u>=.55||k?"#fff":"var(--text)"},children:[a,"/",s]})]})}const it=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-equipes-qte { display: flex; flex-direction: column; gap: 8px; margin-top: 8px; }
.ha-act-equipe-ligne {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface);
  grid-column: 1 / -1;
}
.ha-act-equipe-ligne.is-on { border-color: var(--accent); }
.ha-act-equipe-nom { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.ha-act-equipe-nom strong { font-size: 13.5px; color: var(--heading); }
.ha-act-equipe-nom span { font-size: 11.5px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 52vw; }
.ha-act-equipe-stepper { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }
.ha-act-equipe-stepper button {
  width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--heading); font-size: 18px; line-height: 1;
  font-family: inherit; cursor: pointer;
}
.ha-act-equipe-stepper button:disabled { opacity: .35; cursor: default; }
.ha-act-equipe-stepper input {
  width: 44px; text-align: center; padding: 6px 4px; border: 1px solid var(--border);
  border-radius: 8px; background: var(--surface); color: var(--text); font-family: inherit; font-size: 14px;
}
.ha-act-equipe-stepper input::-webkit-outer-spin-button,
.ha-act-equipe-stepper input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ha-act-equipe-stepper input[type=number] { -moz-appearance: textfield; appearance: textfield; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{pt as default};
