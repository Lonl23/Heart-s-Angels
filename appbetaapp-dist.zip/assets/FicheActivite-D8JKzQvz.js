import{i as He,r as c,j as e,L as Ne}from"./vendor-react-y2xUrN8v.js";import{u as Qe,s as y,r as ee,n as Ge,k as ae,E as We,e as O,_ as ie,c as Ye}from"./index-DktHEao-.js";import{n as te,k as we,m as Je,e as Ke,o as Xe,a as Ze,q as ea,s as aa,l as se,t as V,b as H,u as qe,f as Q,v as ia,w as ta,C as sa,x as ra,y as na,g as oa,z as ca}from"./activitesSecours-DbORx6Jf.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function $(n){return String(n).padStart(2,"0")}function B(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${$(t.getDate())}-${$(t.getMonth()+1)}-${t.getFullYear()}`}function ne(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${$(t.getHours())}:${$(t.getMinutes())}`}function Ae(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${t.getFullYear()}-${$(t.getMonth()+1)}-${$(t.getDate())}`}function F(n){return n?`${B(n)} ${ne(n)}`:""}function xa(){var ke;const{id:n}=He(),{profile:t}=Qe(),[i,m]=c.useState(null),[q,oe]=c.useState([]),[S,ce]=c.useState([]),[G,$e]=c.useState(null),[P,le]=c.useState("info"),[N,Se]=c.useState("dimensionner"),[De,D]=c.useState(!0),[de,he]=c.useState(!1),[T,L]=c.useState(null),[ue,v]=c.useState(null),[E,W]=c.useState(!1),[M,Ee]=c.useState(""),[Y,ze]=c.useState(""),[u,J]=c.useState(null),[Fe,Be]=c.useState([]),[K,pe]=c.useState(!1);c.useEffect(()=>{me()},[n,t==null?void 0:t.id]);async function me(a=!1){a||D(!0),L(null),he(!1);const s=await y.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,debut,fin,places,competences,armement,created_by,created_at").eq("id",n).maybeSingle();if(s.error){L(s.error.message||"Chargement impossible."),a||m(null),D(!1);return}if(!s.data){he(!0),m(null),D(!1);return}const o=await y.from("activites_secours_inscrits").select("id,user_id,created_at").eq("activite_id",n);if(o.error){L(o.error.message||"Chargement des inscriptions impossible."),m(s.data),oe([]),ce([]),D(!1);return}const r=o.data||[],f=[...new Set(r.map(h=>h.user_id).filter(Boolean))];let p=[];if(f.length){const h=await y.from("profiles").select("id,prenom,nom,role,fiche").in("id",f);h.error?L(h.error.message||"Chargement du personnel impossible."):p=h.data||[]}let b=null;if(s.data.created_by){const h=await y.from("profiles").select("id,prenom,nom").eq("id",s.data.created_by).maybeSingle();h.error||(b=h.data)}m(s.data),J(te(s.data.armement,s.data)),oe(r),ce(p),$e(b);const l=await y.from("plaques_vehicules").select("plaque,libelle").eq("actif",!0).order("plaque");l.error||Be(l.data||[]),D(!1)}const fe=c.useMemo(()=>we(t),[t]),I=q.some(a=>a.user_id===(t==null?void 0:t.id)),j=Number(i==null?void 0:i.places)||0,x=q.length,A=i?Je(i):"a_venir",Pe=i?Ke(i):!1,Te=j>0&&x>=j,g=Array.isArray(i==null?void 0:i.competences)?i.competences:[],_=i?Xe(i):null,Le=i&&Ae(i.debut)===Ae(i.fin||i.debut),k=c.useMemo(()=>Ze(i),[i]),C=c.useMemo(()=>ea(i,S),[i,S]),w=c.useMemo(()=>aa(k),[k]),xe=c.useMemo(()=>{const a=new Map(S.map(o=>[o.id,o])),s=Y.trim().toLowerCase();return q.map(o=>{const r=a.get(o.user_id),f=(r==null?void 0:r.fiche)||{},p=r?[...we(r)]:[],b=p.filter(h=>h!=="medical"&&h!=="non_medical"&&h!=="volontaire_non_medical"),l=g.some(h=>p.includes(h)||_e(h,r));return{id:o.user_id,inscription:o.created_at,prenom:(r==null?void 0:r.prenom)||"",nom:(r==null?void 0:r.nom)||"",photo:f.photo_url||"",role:(r==null?void 0:r.role)||"",quals:b,manque:g.length>0&&!l}}).filter(o=>M&&!o.quals.includes(M)?!1:s?`${o.prenom} ${o.nom}`.toLowerCase().includes(s):!0).sort((o,r)=>`${o.nom} ${o.prenom}`.localeCompare(`${r.nom} ${r.prenom}`,"fr"))},[q,S,Y,M,g]);function z(a){Se(a),a==="dimensionner"&&le("info"),a==="armer"&&le("personnel")}function ge(a){J(s=>({...s||te(null,i),...a}))}function Me(a){J(s=>{const o=s||te(null,i);return{...o,items:o.items.map(r=>r.id===a?{...r,ok:!r.ok}:r)}})}async function Ie(){if(!(i!=null&&i.id)||!u||K)return;pe(!0),v(null);const a={plaque:u.plaque||"",note:u.note||"",items:u.items||[]},{error:s}=await y.from("activites_secours").update({armement:a}).eq("id",i.id);s?v(s.message||"Armement non enregistré."):(m(o=>({...o,armement:a})),v(null)),pe(!1)}function be(){var r,f,p;const a=((f=(r=ie.bases)==null?void 0:r[0])==null?void 0:f.adresse)||{},s=[[a.rue,a.numero].filter(Boolean).join(" "),[a.cp,a.localite].filter(Boolean).join(" ")].filter(Boolean).join(", "),o=q.map(b=>{const l=S.find(U=>U.id===b.user_id),h=(l==null?void 0:l.fiche)||{},ye=Array.isArray(h.qualifications)?h.qualifications:[],Z={prenom:(l==null?void 0:l.prenom)||"",nom:(l==null?void 0:l.nom)||"",quals:ye,role:(l==null?void 0:l.role)||""},Ve=g.some(U=>ye.includes(U)||_e(U,l));return{prenom:Z.prenom,nom:Z.nom,fonction:Ce(Z),couverture:g.length===0?"Aucune exigée":Ve?"Couvre au moins une compétence":"Aucune des compétences demandées"}}).sort((b,l)=>`${b.nom} ${b.prenom}`.localeCompare(`${l.nom} ${l.prenom}`,"fr"));return{organisation:je,adresse:s,logo:`${window.location.origin}${((p=ie.organisation)==null?void 0:p.logoUrl)||"/icons/ha-logo-512-v4.png"}`,imprimePar:`${((t==null?void 0:t.nom)||"").toUpperCase()} ${(t==null?void 0:t.prenom)||""}`.trim(),numero:i.numero,titre:i.titre,type:se(i.type),dispositif:H(i.dispositif)||"",publicAttendu:i.public_attendu==null?"":String(i.public_attendu),debut:F(i.debut),fin:i.fin?F(i.fin):"",duree:_||"",lieu:i.lieu||"",places:j,competences:g.map(Q),personnel:o,statut:V(A),inscrits:x}}function Re(){ra(be())||v("Le bilan n’a pas pu être téléchargé.")}function Ue(){na(be())||v("Le navigateur a bloqué la fenêtre du bilan. Utilisez Récupérer.")}async function ve(){if(!(t!=null&&t.id)||!i||E)return;if(W(!0),v(null),!I&&oa(t,i)){v("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),W(!1);return}const a=I?await y.from("activites_secours_inscrits").delete().eq("activite_id",i.id).eq("user_id",t.id):await y.from("activites_secours_inscrits").insert({activite_id:i.id,user_id:t.id});a.error?v(a.error.message||"Inscription impossible."):await me(!0),W(!1)}let R="S’inscrire",X=!1;I?R="Se désinscrire":Pe?Te&&(R="Complet",X=!0):(R="Terminée",X=!0);const je=((ke=ie.organisation)==null?void 0:ke.nom)||"Heart’s Angels ASBL",Oe=i!=null&&i.lieu?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.lieu)}`:"";return De?e.jsx(ee,{title:"Activité",children:e.jsx(Ge,{})}):i?e.jsxs(ee,{children:[e.jsx("style",{children:da}),T&&e.jsx(ae,{kind:"err",children:T}),ue&&e.jsx(ae,{kind:"err",children:ue}),e.jsxs("div",{className:"ha-afiche",children:[e.jsxs("header",{className:"ha-afiche-head",children:[e.jsxs("div",{className:"ha-afiche-top",children:[e.jsxs("div",{children:[e.jsx(Ne,{to:"/app/secours/activites",className:"ha-afiche-retour",children:"Activités"}),e.jsx("p",{className:"ha-afiche-type",children:se(i.type)}),e.jsx("h1",{children:i.titre}),e.jsxs("p",{className:"ha-afiche-quand",children:[Le?B(i.debut):`du ${B(i.debut)} au ${B(i.fin||i.debut)}`," · ",ne(i.debut),i.fin?` – ${ne(i.fin)}`:"",_?` (${_})`:""]})]}),e.jsx("span",{className:"ha-afiche-etat is-"+A,children:V(A)})]}),e.jsxs("div",{className:"ha-afiche-chiffres",children:[e.jsx(re,{label:"Personnel inscrit",valeur:x}),e.jsx(re,{label:"Places",valeur:`${x} / ${j}`}),e.jsx(re,{label:"Durée",valeur:_||"—"})]})]}),e.jsxs("nav",{className:"ha-dps-temps","aria-label":"Déroulement du dispositif",children:[e.jsxs("button",{type:"button",className:N==="dimensionner"?"is-on":"",onClick:()=>z("dimensionner"),children:[e.jsx("span",{children:"1"})," Dimensionner"]}),e.jsxs("button",{type:"button",className:N==="armer"?"is-on":"",onClick:()=>z("armer"),children:[e.jsx("span",{children:"2"})," Armer"]}),e.jsxs("button",{type:"button",className:N==="rendre"?"is-on":"",onClick:()=>z("rendre"),children:[e.jsx("span",{children:"3"})," Rendre"]})]}),N!=="rendre"&&e.jsxs("nav",{className:"ha-afiche-onglets","aria-label":"Fiche de l’activité",children:[e.jsx("button",{type:"button",className:P==="info"?"is-on":"",onClick:()=>z("dimensionner"),children:"Information"}),e.jsxs("button",{type:"button",className:P==="personnel"?"is-on":"",onClick:()=>z("armer"),children:["Personnel",x?` ${x}`:""]})]}),N==="rendre"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Bilan de fin"}),e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:8},children:A==="terminee"?"Le dispositif est terminé. Le bilan reprend l’équipe inscrite, la durée et le dimensionnement.":"Le dispositif n’est pas encore terminé. Le bilan reprend déjà ce qui est enregistré."}),e.jsxs("div",{className:"ha-afiche-kv",style:{marginTop:14},children:[e.jsx(d,{k:"Équipes",v:k.length?k.map(a=>H(a,!0)).join(" + "):"—"}),e.jsx(d,{k:"Public attendu",v:i.public_attendu==null?"—":String(i.public_attendu)}),e.jsx(d,{k:"Personnel",v:`${x} / ${j}`}),e.jsx(d,{k:"Durée",v:_||"—"})]}),e.jsxs("div",{className:"ha-dps-actions",children:[e.jsx(O,{onClick:Re,children:"Récupérer"}),e.jsx(O,{kind:"soft",onClick:Ue,children:"Imprimer"})]})]}),N!=="rendre"&&P==="info"&&e.jsxs("div",{className:"ha-afiche-grille",children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Détails de l’activité"}),e.jsx("p",{className:"ha-afiche-sec",children:"Identité"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"N°",v:i.numero??"—"}),e.jsx(d,{k:"Statut",v:V(A)}),e.jsx(d,{k:"Type",v:se(i.type)}),e.jsx(d,{k:"Nom",v:i.titre}),e.jsx(d,{k:"Équipes",v:k.length?k.map(a=>H(a,!0)).join(" + "):"—"}),e.jsx(d,{k:"Effectif min.",v:(w==null?void 0:w.resume)||"—"}),e.jsx(d,{k:"Public attendu",v:i.public_attendu==null?"—":String(i.public_attendu)})]}),e.jsx("p",{className:"ha-afiche-vide",children:"Les équipes se choisissent à la création (plusieurs possibles). Pas de calcul depuis le public. « Minimum » = ordre des qualifications 1→7."}),w&&e.jsx("p",{className:"ha-afiche-vide",style:{color:C.ok?"var(--heading)":"#A32D2D",marginTop:8},children:C.ok?"Équipes inscrites : effectifs minimum atteints.":`Équipe incomplète — manque : ${qe(C)}.`}),e.jsx("p",{className:"ha-afiche-sec",children:"Organisation"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Organisée par",v:je}),e.jsx(d,{k:"Créée par",v:G?`${G.prenom||""} ${G.nom||""}`.trim():"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Date et horaires"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Début",v:F(i.debut)}),e.jsx(d,{k:"Fin",v:i.fin?F(i.fin):"—"}),e.jsx(d,{k:"Durée",v:_||"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Suivi"}),e.jsx(d,{k:"Créée le",v:F(i.created_at)||"—"})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Inscription"}),e.jsx("p",{className:"ha-afiche-sec",children:"État"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Statut",v:V(A)}),e.jsx(d,{k:"Places",v:j?`${Math.max(j-x,0)} libre${j-x>1?"s":""}`:"—"}),e.jsx(d,{k:"Qui peut s’inscrire",v:"Personnel de l’association"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Compétences demandées"}),g.length===0?e.jsx("p",{className:"ha-afiche-vide",children:"Aucune compétence exigée."}):e.jsx("div",{className:"ha-afiche-chips",children:g.map(a=>e.jsxs("span",{className:"ha-act-chip"+(fe.has(a)?" is-moi":" is-autre"),children:[fe.has(a)?"✓":"•"," ",Q(a)]},a))}),e.jsx("div",{style:{marginTop:14},children:e.jsx(O,{onClick:ve,disabled:X||E,kind:I?"danger":"primary",children:E?"…":R})})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Lieu"}),i.lieu?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-lieu",children:i.lieu}),e.jsx("a",{className:"ha-afiche-maps",href:Oe,target:"_blank",rel:"noreferrer",children:"Ouvrir dans Google Maps"})]}):e.jsx("p",{className:"ha-afiche-vide",children:"Aucun lieu renseigné."})]})]}),N!=="rendre"&&P==="personnel"&&e.jsxs(e.Fragment,{children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Effectif requis"}),k.length?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:w==null?void 0:w.resume}),e.jsx("p",{style:{marginTop:10,fontWeight:650,color:C.ok?"var(--heading)":"#A32D2D"},children:C.ok?"Minimum atteint avec les inscrits.":`Manque : ${qe(C)}`}),k.map(a=>{var o;const s=ca(a);return(o=s==null?void 0:s.alternatives)!=null&&o.length?e.jsxs("p",{className:"ha-afiche-vide",style:{marginTop:8},children:[e.jsx("strong",{children:H(a,!0)}),s.alternatives.length>1?" — compositions : ":" — ",s.alternatives.map((r,f)=>e.jsxs("span",{children:[f?" · ou · ":"",r.map(p=>`${p.n} ${ia(p.role)}`).join(" + ")]},f))]},a):null})]}):e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:"Aucune équipe choisie à la création."})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Armement"}),u&&e.jsxs(e.Fragment,{children:[e.jsxs("label",{style:{display:"block",marginTop:8,marginBottom:10},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Véhicule (plaque)"}),e.jsxs("select",{value:u.plaque||"",onChange:a=>ge({plaque:a.target.value}),style:{width:"100%",maxWidth:320,padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[e.jsx("option",{value:"",children:"—"}),Fe.map(a=>e.jsxs("option",{value:a.plaque,children:[a.plaque,a.libelle?` — ${a.libelle}`:""]},a.plaque))]})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:8,marginBottom:12},children:u.items.map(a=>e.jsxs("label",{style:{display:"flex",alignItems:"center",gap:10,cursor:"pointer"},children:[e.jsx("input",{type:"checkbox",checked:!!a.ok,onChange:()=>Me(a.id)}),e.jsx("span",{children:a.label})]},a.id))}),e.jsxs("label",{style:{display:"block",marginBottom:12},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Note / dérogation"}),e.jsx("textarea",{value:u.note||"",onChange:a=>ge({note:a.target.value}),rows:2,style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit",resize:"vertical"}})]}),e.jsxs("p",{className:"ha-afiche-vide",style:{marginBottom:10},children:[ta(u)?"Checklist complète.":"Checklist incomplète — précisez une dérogation si besoin.",u.plaque?` Véhicule : ${u.plaque}.`:" Aucune plaque choisie."]}),e.jsx(O,{onClick:Ie,disabled:K,children:K?"…":"Enregistrer l’armement"})]})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Personnel inscrit"}),e.jsxs("div",{className:"ha-afiche-outils",children:[e.jsxs("select",{"aria-label":"Compétence",value:M,onChange:a=>Ee(a.target.value),children:[e.jsx("option",{value:"",children:"Toutes les compétences"}),sa.filter(a=>a.v!=="medical"&&a.v!=="non_medical").map(a=>e.jsx("option",{value:a.v,children:a.l},a.v))]}),e.jsx("input",{type:"search",placeholder:"Rechercher","aria-label":"Rechercher une personne",value:Y,onChange:a=>ze(a.target.value)})]}),xe.length===0?e.jsx("p",{className:"ha-afiche-vide",children:q.length===0?"Personne n’est inscrit pour le moment.":"Aucune personne ne correspond."}):e.jsx("div",{className:"ha-afiche-table-wrap",children:e.jsxs("table",{className:"ha-afiche-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Photo"}),e.jsx("th",{children:"Personnel"}),e.jsx("th",{children:"Fonction"}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:xe.map(a=>e.jsxs("tr",{className:a.manque?"is-manque":void 0,children:[e.jsx("td",{children:e.jsx(la,{url:a.photo,prenom:a.prenom,nom:a.nom})}),e.jsxs("td",{children:[e.jsx("strong",{children:`${a.prenom} ${a.nom}`.trim()||"Compte retiré"}),e.jsx("span",{className:"ha-afiche-sous",children:B(a.inscription)})]}),e.jsx("td",{children:Ce(a)}),e.jsx("td",{children:a.quals.length===0?e.jsx("span",{className:"ha-afiche-vide",children:"—"}):a.quals.map(s=>e.jsx("span",{className:"ha-act-chip"+(g.includes(s)?" is-moi":""),children:Q(s)},s))}),e.jsx("td",{children:a.id===(t==null?void 0:t.id)&&e.jsx("button",{type:"button",className:"ha-afiche-moi",onClick:ve,disabled:E,children:E?"…":"Se désinscrire"})})]},a.id))})]})})]})]})]})]}):e.jsxs(ee,{title:"Activité",children:[T&&e.jsx(ae,{kind:"err",children:T}),e.jsx(We,{title:de?"Activité introuvable":"Activité indisponible",hint:de?"Elle a été retirée, ou le lien ne correspond à rien.":"Le chargement a échoué.",action:e.jsx(Ne,{to:"/app/secours/activites",children:"Retour aux activités"})})]})}function _e(n,t){var i,m;return t?n==="medical"?((i=t.fiche)==null?void 0:i.type_benevole)==="medical"||t.role==="volontaire_medical":n==="non_medical"?((m=t.fiche)==null?void 0:m.type_benevole)==="non_medical"||t.role==="volontaire_non_medical":!1:!1}function Ce(n){const t=n.quals.find(i=>i!=="autre")||n.quals[0];return t?Q(t):n.role?Ye(n.role):"—"}function d({k:n,v:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:n}),e.jsx("div",{className:"ha-afiche-v",children:t||"—"})]})}function re({label:n,valeur:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:n}),e.jsx("div",{className:"ha-afiche-nb",children:t})]})}function la({url:n,prenom:t,nom:i}){const m=`${(t||"").charAt(0)}${(i||"").charAt(0)}`.toUpperCase()||"?";return e.jsx("span",{className:"ha-afiche-photo",children:n?e.jsx("img",{src:n,alt:""}):e.jsx("span",{children:m})})}const da=`
.ha-afiche { display: flex; flex-direction: column; gap: 12px; }
.ha-afiche-head, .ha-afiche-carte {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 14px 16px 12px;
}
.ha-afiche-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.ha-afiche-retour { font-size: 12.5px; font-weight: 700; color: var(--accent); text-decoration: none; }
.ha-afiche-type { margin: 6px 0 0; font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche h1 { margin: 2px 0 0; font-size: 1.35rem; color: var(--heading); line-height: 1.2; }
.ha-afiche-quand { margin: 4px 0 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-etat {
  flex: none;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
}
.ha-afiche-etat.is-a_venir { background: #E6F1FB; color: #185FA5; }
.ha-afiche-etat.is-en_cours { background: #E7F6EE; color: #1E7A45; }
.ha-afiche-etat.is-terminee { background: var(--bg-alt); color: var(--text-muted); }
.ha-afiche-chiffres {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.ha-afiche-nb { font-size: 1.35rem; font-weight: 700; color: var(--heading); font-variant-numeric: tabular-nums; }
.ha-dps-temps { display: flex; gap: 8px; flex-wrap: wrap; }
.ha-dps-temps button {
  display: inline-flex; align-items: center; gap: 8px;
  border: 1px solid var(--border); background: var(--card); color: var(--text);
  border-radius: 999px; padding: 7px 12px; font: inherit; font-weight: 700; font-size: 13.5px; cursor: pointer;
}
.ha-dps-temps button span {
  width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center;
  background: var(--bg-alt); color: var(--heading); font-size: 12px;
}
.ha-dps-temps button.is-on { border-color: var(--accent); color: var(--heading); }
.ha-dps-temps button.is-on span { background: var(--accent); color: #fff; }
.ha-dps-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.ha-afiche-onglets { display: flex; gap: 6px; border-bottom: 1px solid var(--border); }
.ha-afiche-onglets button {
  border: none;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-weight: 700;
  font-size: 14px;
  padding: 8px 12px 10px;
  border-bottom: 2px solid transparent;
  cursor: pointer;
}
.ha-afiche-onglets button.is-on { color: var(--accent-blue); border-bottom-color: var(--accent); }
.ha-afiche-grille {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr) minmax(220px, .8fr);
  gap: 12px;
  align-items: start;
}
.ha-afiche-carte h2 { margin: 0; font-size: 1rem; color: var(--heading); }
.ha-afiche-sec {
  margin: 14px 0 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ha-afiche-kv { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.ha-afiche-k { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche-v { margin-top: 2px; font-size: 14px; font-weight: 650; color: var(--text); }
.ha-afiche-vide { margin: 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-lieu { margin: 8px 0; font-weight: 700; color: var(--heading); }
.ha-afiche-maps { color: var(--accent); font-weight: 700; font-size: 13px; }
.ha-afiche-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.ha-act-chip {
  display: inline-flex; align-items: center; gap: 4px;
  margin: 2px 4px 2px 0; padding: 2px 8px; border-radius: 999px;
  font-size: 11.5px; font-weight: 700; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--text-2); white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-afiche-outils { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.ha-afiche-outils select, .ha-afiche-outils input {
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font: inherit; font-size: 13px; padding: 7px 10px;
}
.ha-afiche-outils input { margin-left: auto; min-width: min(240px, 70vw); }
.ha-afiche-table-wrap { overflow: auto; }
.ha-afiche-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 640px; }
.ha-afiche-table th {
  text-align: left; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  color: var(--text-muted); font-weight: 700; padding: 8px 10px; border-bottom: 1px solid var(--border);
}
.ha-afiche-table td { padding: 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.ha-afiche-table tr.is-manque td { background: #fff6f6; }
.ha-afiche-table td strong { display: block; color: var(--accent-blue); }
.ha-afiche-sous { display: block; color: var(--text-muted); font-size: 12px; font-weight: 500; }
.ha-afiche-photo {
  width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
  display: grid; place-items: center; background: var(--accent); color: #fff; font-weight: 700; font-size: 12px;
}
.ha-afiche-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ha-afiche-moi {
  border: 1px solid var(--border); background: var(--card); color: #A32D2D;
  border-radius: 8px; padding: 5px 8px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
}
[data-theme="dark"] .ha-afiche-etat.is-a_venir { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-afiche-etat.is-en_cours { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-afiche-table tr.is-manque td { background: rgba(163,45,45,.16); }
[data-theme="dark"] .ha-afiche-onglets button.is-on,
[data-theme="dark"] .ha-afiche-table td strong { color: var(--heading); }
[data-theme="dark"] .ha-afiche-moi { color: #F0A0A0; }
@media (max-width: 980px) {
  .ha-afiche-grille { grid-template-columns: 1fr; }
  .ha-afiche-chiffres { grid-template-columns: 1fr; }
  .ha-afiche-outils input { margin-left: 0; width: 100%; }
}
`;export{xa as default};
