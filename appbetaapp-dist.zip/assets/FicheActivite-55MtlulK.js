import{i as Se,r as d,j as e,L as me}from"./vendor-react-y2xUrN8v.js";import{u as Ee,s as N,r as Q,n as ze,k as V,E as De,e as G,_ as Y,c as Fe}from"./index-DfOUD55T.js";import{h as Le,i as Be,e as Pe,j as Te,l as J,k as P,a as K,b as T,C as Ie,t as Me,o as Re,s as Ue}from"./activitesSecours-DFpPeqqM.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function y(r){return String(r).padStart(2,"0")}function q(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${y(i.getDate())}-${y(i.getMonth()+1)}-${i.getFullYear()}`}function X(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${y(i.getHours())}:${y(i.getMinutes())}`}function fe(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${i.getFullYear()}-${y(i.getMonth()+1)}-${y(i.getDate())}`}function $(r){return r?`${q(r)} ${X(r)}`:""}function Ke(){var he;const{id:r}=Se(),{profile:i}=Ee(),[a,h]=d.useState(null),[v,Z]=d.useState([]),[I,ee]=d.useState([]),[M,be]=d.useState(null),[S,ae]=d.useState("info"),[b,ve]=d.useState("dimensionner"),[je,w]=d.useState(!0),[ie,te]=d.useState(!1),[E,z]=d.useState(null),[re,_]=d.useState(null),[C,R]=d.useState(!1),[D,ke]=d.useState(""),[U,Ne]=d.useState("");d.useEffect(()=>{se()},[r,i==null?void 0:i.id]);async function se(t=!1){t||w(!0),z(null),te(!1);const l=await N.from("activites_secours").select("id,numero,titre,type,dispositif,public_attendu,lieu,debut,fin,places,competences,created_by,created_at").eq("id",r).maybeSingle();if(l.error){z(l.error.message||"Chargement impossible."),t||h(null),w(!1);return}if(!l.data){te(!0),h(null),w(!1);return}const o=await N.from("activites_secours_inscrits").select("id,user_id,created_at").eq("activite_id",r);if(o.error){z(o.error.message||"Chargement des inscriptions impossible."),h(l.data),Z([]),ee([]),w(!1);return}const n=o.data||[],m=[...new Set(n.map(s=>s.user_id).filter(Boolean))];let g=[];if(m.length){const s=await N.from("profiles").select("id,prenom,nom,role,fiche").in("id",m);s.error?z(s.error.message||"Chargement du personnel impossible."):g=s.data||[]}let f=null;if(l.data.created_by){const s=await N.from("profiles").select("id,prenom,nom").eq("id",l.data.created_by).maybeSingle();s.error||(f=s.data)}h(l.data),Z(n),ee(g),be(f),w(!1)}const ne=d.useMemo(()=>Le(i),[i]),F=v.some(t=>t.user_id===(i==null?void 0:i.id)),x=Number(a==null?void 0:a.places)||0,p=v.length,j=a?Be(a):"a_venir",ye=a?Pe(a):!1,we=x>0&&p>=x,u=Array.isArray(a==null?void 0:a.competences)?a.competences:[],k=a?Te(a):null,_e=a&&fe(a.debut)===fe(a.fin||a.debut),oe=d.useMemo(()=>{const t=new Map(I.map(o=>[o.id,o])),l=U.trim().toLowerCase();return v.map(o=>{const n=t.get(o.user_id),m=(n==null?void 0:n.fiche)||{},g=Array.isArray(m.qualifications)?m.qualifications:[],f=u.some(s=>g.includes(s)||xe(s,n));return{id:o.user_id,inscription:o.created_at,prenom:(n==null?void 0:n.prenom)||"",nom:(n==null?void 0:n.nom)||"",photo:m.photo_url||"",role:(n==null?void 0:n.role)||"",quals:g,manque:u.length>0&&!f}}).filter(o=>D&&!o.quals.includes(D)?!1:l?`${o.prenom} ${o.nom}`.toLowerCase().includes(l):!0).sort((o,n)=>`${o.nom} ${o.prenom}`.localeCompare(`${n.nom} ${n.prenom}`,"fr"))},[v,I,U,D,u]);function A(t){ve(t),t==="dimensionner"&&ae("info"),t==="armer"&&ae("personnel")}function ce(){var n,m,g;const t=((m=(n=Y.bases)==null?void 0:n[0])==null?void 0:m.adresse)||{},l=[[t.rue,t.numero].filter(Boolean).join(" "),[t.cp,t.localite].filter(Boolean).join(" ")].filter(Boolean).join(", "),o=v.map(f=>{const s=I.find(B=>B.id===f.user_id),pe=(s==null?void 0:s.fiche)||{},ue=Array.isArray(pe.qualifications)?pe.qualifications:[],H={prenom:(s==null?void 0:s.prenom)||"",nom:(s==null?void 0:s.nom)||"",quals:ue,role:(s==null?void 0:s.role)||""},qe=u.some(B=>ue.includes(B)||xe(B,s));return{prenom:H.prenom,nom:H.nom,fonction:ge(H),couverture:u.length===0?"Aucune exigée":qe?"Couvre au moins une compétence":"Aucune des compétences demandées"}}).sort((f,s)=>`${f.nom} ${f.prenom}`.localeCompare(`${s.nom} ${s.prenom}`,"fr"));return{organisation:de,adresse:l,logo:`${window.location.origin}${((g=Y.organisation)==null?void 0:g.logoUrl)||"/icons/ha-logo-512-v4.png"}`,imprimePar:`${((i==null?void 0:i.nom)||"").toUpperCase()} ${(i==null?void 0:i.prenom)||""}`.trim(),numero:a.numero,titre:a.titre,type:J(a.type),dispositif:K(a.dispositif)||"",publicAttendu:a.public_attendu==null?"":String(a.public_attendu),debut:$(a.debut),fin:a.fin?$(a.fin):"",duree:k||"",lieu:a.lieu||"",places:x,competences:u.map(T),personnel:o,statut:P(j),inscrits:p}}function Ce(){Me(ce())||_("Le bilan n’a pas pu être téléchargé.")}function Ae(){Re(ce())||_("Le navigateur a bloqué la fenêtre du bilan. Utilisez Récupérer.")}async function le(){if(!(i!=null&&i.id)||!a||C)return;if(R(!0),_(null),!F&&Ue(i,a)){_("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),R(!1);return}const t=F?await N.from("activites_secours_inscrits").delete().eq("activite_id",a.id).eq("user_id",i.id):await N.from("activites_secours_inscrits").insert({activite_id:a.id,user_id:i.id});t.error?_(t.error.message||"Inscription impossible."):await se(!0),R(!1)}let L="S’inscrire",O=!1;F?L="Se désinscrire":ye?we&&(L="Complet",O=!0):(L="Terminée",O=!0);const de=((he=Y.organisation)==null?void 0:he.nom)||"Heart’s Angels ASBL",$e=a!=null&&a.lieu?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.lieu)}`:"";return je?e.jsx(Q,{title:"Activité",children:e.jsx(ze,{})}):a?e.jsxs(Q,{children:[e.jsx("style",{children:He}),E&&e.jsx(V,{kind:"err",children:E}),re&&e.jsx(V,{kind:"err",children:re}),e.jsxs("div",{className:"ha-afiche",children:[e.jsxs("header",{className:"ha-afiche-head",children:[e.jsxs("div",{className:"ha-afiche-top",children:[e.jsxs("div",{children:[e.jsx(me,{to:"/app/secours/activites",className:"ha-afiche-retour",children:"Activités"}),e.jsx("p",{className:"ha-afiche-type",children:J(a.type)}),e.jsx("h1",{children:a.titre}),e.jsxs("p",{className:"ha-afiche-quand",children:[_e?q(a.debut):`du ${q(a.debut)} au ${q(a.fin||a.debut)}`," · ",X(a.debut),a.fin?` – ${X(a.fin)}`:"",k?` (${k})`:""]})]}),e.jsx("span",{className:"ha-afiche-etat is-"+j,children:P(j)})]}),e.jsxs("div",{className:"ha-afiche-chiffres",children:[e.jsx(W,{label:"Personnel inscrit",valeur:p}),e.jsx(W,{label:"Places",valeur:`${p} / ${x}`}),e.jsx(W,{label:"Durée",valeur:k||"—"})]})]}),e.jsxs("nav",{className:"ha-dps-temps","aria-label":"Déroulement du dispositif",children:[e.jsxs("button",{type:"button",className:b==="dimensionner"?"is-on":"",onClick:()=>A("dimensionner"),children:[e.jsx("span",{children:"1"})," Dimensionner"]}),e.jsxs("button",{type:"button",className:b==="armer"?"is-on":"",onClick:()=>A("armer"),children:[e.jsx("span",{children:"2"})," Armer"]}),e.jsxs("button",{type:"button",className:b==="rendre"?"is-on":"",onClick:()=>A("rendre"),children:[e.jsx("span",{children:"3"})," Rendre"]})]}),b!=="rendre"&&e.jsxs("nav",{className:"ha-afiche-onglets","aria-label":"Fiche de l’activité",children:[e.jsx("button",{type:"button",className:S==="info"?"is-on":"",onClick:()=>A("dimensionner"),children:"Information"}),e.jsxs("button",{type:"button",className:S==="personnel"?"is-on":"",onClick:()=>A("armer"),children:["Personnel",p?` ${p}`:""]})]}),b==="rendre"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Bilan de fin"}),e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:8},children:j==="terminee"?"Le dispositif est terminé. Le bilan reprend l’équipe inscrite, la durée et le dimensionnement.":"Le dispositif n’est pas encore terminé. Le bilan reprend déjà ce qui est enregistré."}),e.jsxs("div",{className:"ha-afiche-kv",style:{marginTop:14},children:[e.jsx(c,{k:"Dispositif",v:K(a.dispositif)||"—"}),e.jsx(c,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)}),e.jsx(c,{k:"Équipe",v:`${p} / ${x}`}),e.jsx(c,{k:"Durée",v:k||"—"})]}),e.jsxs("div",{className:"ha-dps-actions",children:[e.jsx(G,{onClick:Ce,children:"Récupérer"}),e.jsx(G,{kind:"soft",onClick:Ae,children:"Imprimer"})]})]}),b!=="rendre"&&S==="info"&&e.jsxs("div",{className:"ha-afiche-grille",children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Détails de l’activité"}),e.jsx("p",{className:"ha-afiche-sec",children:"Identité"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(c,{k:"N°",v:a.numero??"—"}),e.jsx(c,{k:"Statut",v:P(j)}),e.jsx(c,{k:"Type",v:J(a.type)}),e.jsx(c,{k:"Nom",v:a.titre}),e.jsx(c,{k:"Dispositif",v:K(a.dispositif)||"—"}),e.jsx(c,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)})]}),e.jsx("p",{className:"ha-afiche-vide",children:"Le type de dispositif est choisi à la création. Il n’est pas déduit du public."}),e.jsx("p",{className:"ha-afiche-sec",children:"Organisation"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(c,{k:"Organisée par",v:de}),e.jsx(c,{k:"Créée par",v:M?`${M.prenom||""} ${M.nom||""}`.trim():"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Date et horaires"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(c,{k:"Début",v:$(a.debut)}),e.jsx(c,{k:"Fin",v:a.fin?$(a.fin):"—"}),e.jsx(c,{k:"Durée",v:k||"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Suivi"}),e.jsx(c,{k:"Créée le",v:$(a.created_at)||"—"})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Inscription"}),e.jsx("p",{className:"ha-afiche-sec",children:"État"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(c,{k:"Statut",v:P(j)}),e.jsx(c,{k:"Places",v:x?`${Math.max(x-p,0)} libre${x-p>1?"s":""}`:"—"}),e.jsx(c,{k:"Qui peut s’inscrire",v:"Personnel de l’association"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Compétences demandées"}),u.length===0?e.jsx("p",{className:"ha-afiche-vide",children:"Aucune compétence exigée."}):e.jsx("div",{className:"ha-afiche-chips",children:u.map(t=>e.jsxs("span",{className:"ha-act-chip"+(ne.has(t)?" is-moi":" is-autre"),children:[ne.has(t)?"✓":"•"," ",T(t)]},t))}),e.jsx("div",{style:{marginTop:14},children:e.jsx(G,{onClick:le,disabled:O||C,kind:F?"danger":"primary",children:C?"…":L})})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Lieu"}),a.lieu?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-lieu",children:a.lieu}),e.jsx("a",{className:"ha-afiche-maps",href:$e,target:"_blank",rel:"noreferrer",children:"Ouvrir dans Google Maps"})]}):e.jsx("p",{className:"ha-afiche-vide",children:"Aucun lieu renseigné."})]})]}),b!=="rendre"&&S==="personnel"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsxs("div",{className:"ha-afiche-outils",children:[e.jsxs("select",{"aria-label":"Compétence",value:D,onChange:t=>ke(t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les compétences"}),Ie.filter(t=>t.v!=="medical"&&t.v!=="non_medical").map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]}),e.jsx("input",{type:"search",placeholder:"Rechercher","aria-label":"Rechercher une personne",value:U,onChange:t=>Ne(t.target.value)})]}),oe.length===0?e.jsx("p",{className:"ha-afiche-vide",children:v.length===0?"Personne n’est inscrit pour le moment.":"Aucune personne ne correspond."}):e.jsx("div",{className:"ha-afiche-table-wrap",children:e.jsxs("table",{className:"ha-afiche-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Photo"}),e.jsx("th",{children:"Personnel"}),e.jsx("th",{children:"Fonction"}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:oe.map(t=>e.jsxs("tr",{className:t.manque?"is-manque":void 0,children:[e.jsx("td",{children:e.jsx(Oe,{url:t.photo,prenom:t.prenom,nom:t.nom})}),e.jsxs("td",{children:[e.jsx("strong",{children:`${t.prenom} ${t.nom}`.trim()||"Compte retiré"}),e.jsx("span",{className:"ha-afiche-sous",children:q(t.inscription)})]}),e.jsx("td",{children:ge(t)}),e.jsx("td",{children:t.quals.length===0?e.jsx("span",{className:"ha-afiche-vide",children:"—"}):t.quals.map(l=>e.jsx("span",{className:"ha-act-chip"+(u.includes(l)?" is-moi":""),children:T(l)},l))}),e.jsx("td",{children:t.id===(i==null?void 0:i.id)&&e.jsx("button",{type:"button",className:"ha-afiche-moi",onClick:le,disabled:C,children:C?"…":"Se désinscrire"})})]},t.id))})]})})]})]})]}):e.jsxs(Q,{title:"Activité",children:[E&&e.jsx(V,{kind:"err",children:E}),e.jsx(De,{title:ie?"Activité introuvable":"Activité indisponible",hint:ie?"Elle a été retirée, ou le lien ne correspond à rien.":"Le chargement a échoué.",action:e.jsx(me,{to:"/app/secours/activites",children:"Retour aux activités"})})]})}function xe(r,i){var a,h;return i?r==="medical"?((a=i.fiche)==null?void 0:a.type_benevole)==="medical"||i.role==="volontaire_medical":r==="non_medical"?((h=i.fiche)==null?void 0:h.type_benevole)==="non_medical"||i.role==="volontaire_non_medical":!1:!1}function ge(r){const i=r.quals.find(a=>a!=="autre")||r.quals[0];return i?T(i):r.role?Fe(r.role):"—"}function c({k:r,v:i}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:r}),e.jsx("div",{className:"ha-afiche-v",children:i||"—"})]})}function W({label:r,valeur:i}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:r}),e.jsx("div",{className:"ha-afiche-nb",children:i})]})}function Oe({url:r,prenom:i,nom:a}){const h=`${(i||"").charAt(0)}${(a||"").charAt(0)}`.toUpperCase()||"?";return e.jsx("span",{className:"ha-afiche-photo",children:r?e.jsx("img",{src:r,alt:""}):e.jsx("span",{children:h})})}const He=`
.ha-afiche { display: flex; flex-direction: column; gap: 12px; }
.ha-afiche-head, .ha-afiche-carte {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 14px 16px 12px;
}
.ha-afiche-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.ha-afiche-retour { font-size: 12.5px; font-weight: 700; color: var(--accent); text-decoration: none; }
.ha-afiche-type { margin: 6px 0 0; font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche h1 { margin: 2px 0 0; font-size: 1.35rem; color: var(--heading); line-height: 1.2; }
.ha-afiche-quand { margin: 4px 0 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-etat {
  flex: none;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
}
.ha-afiche-etat.is-a_venir { background: #E6F1FB; color: #185FA5; }
.ha-afiche-etat.is-en_cours { background: #E7F6EE; color: #1E7A45; }
.ha-afiche-etat.is-terminee { background: var(--bg-alt); color: var(--text-muted); }
.ha-afiche-chiffres {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.ha-afiche-nb { font-size: 1.35rem; font-weight: 700; color: var(--heading); font-variant-numeric: tabular-nums; }
.ha-dps-temps { display: flex; gap: 8px; flex-wrap: wrap; }
.ha-dps-temps button {
  display: inline-flex; align-items: center; gap: 8px;
  border: 1px solid var(--border); background: var(--card); color: var(--text);
  border-radius: 999px; padding: 7px 12px; font: inherit; font-weight: 700; font-size: 13.5px; cursor: pointer;
}
.ha-dps-temps button span {
  width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center;
  background: var(--bg-alt); color: var(--heading); font-size: 12px;
}
.ha-dps-temps button.is-on { border-color: var(--accent); color: var(--heading); }
.ha-dps-temps button.is-on span { background: var(--accent); color: #fff; }
.ha-dps-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.ha-afiche-onglets { display: flex; gap: 6px; border-bottom: 1px solid var(--border); }
.ha-afiche-onglets button {
  border: none;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-weight: 700;
  font-size: 14px;
  padding: 8px 12px 10px;
  border-bottom: 2px solid transparent;
  cursor: pointer;
}
.ha-afiche-onglets button.is-on { color: var(--accent-blue); border-bottom-color: var(--accent); }
.ha-afiche-grille {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr) minmax(220px, .8fr);
  gap: 12px;
  align-items: start;
}
.ha-afiche-carte h2 { margin: 0; font-size: 1rem; color: var(--heading); }
.ha-afiche-sec {
  margin: 14px 0 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ha-afiche-kv { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.ha-afiche-k { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche-v { margin-top: 2px; font-size: 14px; font-weight: 650; color: var(--text); }
.ha-afiche-vide { margin: 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-lieu { margin: 8px 0; font-weight: 700; color: var(--heading); }
.ha-afiche-maps { color: var(--accent); font-weight: 700; font-size: 13px; }
.ha-afiche-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.ha-act-chip {
  display: inline-flex; align-items: center; gap: 4px;
  margin: 2px 4px 2px 0; padding: 2px 8px; border-radius: 999px;
  font-size: 11.5px; font-weight: 700; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--text-2); white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-afiche-outils { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.ha-afiche-outils select, .ha-afiche-outils input {
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font: inherit; font-size: 13px; padding: 7px 10px;
}
.ha-afiche-outils input { margin-left: auto; min-width: min(240px, 70vw); }
.ha-afiche-table-wrap { overflow: auto; }
.ha-afiche-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 640px; }
.ha-afiche-table th {
  text-align: left; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  color: var(--text-muted); font-weight: 700; padding: 8px 10px; border-bottom: 1px solid var(--border);
}
.ha-afiche-table td { padding: 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.ha-afiche-table tr.is-manque td { background: #fff6f6; }
.ha-afiche-table td strong { display: block; color: var(--accent-blue); }
.ha-afiche-sous { display: block; color: var(--text-muted); font-size: 12px; font-weight: 500; }
.ha-afiche-photo {
  width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
  display: grid; place-items: center; background: var(--accent); color: #fff; font-weight: 700; font-size: 12px;
}
.ha-afiche-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ha-afiche-moi {
  border: 1px solid var(--border); background: var(--card); color: #A32D2D;
  border-radius: 8px; padding: 5px 8px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
}
[data-theme="dark"] .ha-afiche-etat.is-a_venir { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-afiche-etat.is-en_cours { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-afiche-table tr.is-manque td { background: rgba(163,45,45,.16); }
[data-theme="dark"] .ha-afiche-onglets button.is-on,
[data-theme="dark"] .ha-afiche-table td strong { color: var(--heading); }
[data-theme="dark"] .ha-afiche-moi { color: #F0A0A0; }
@media (max-width: 980px) {
  .ha-afiche-grille { grid-template-columns: 1fr; }
  .ha-afiche-chiffres { grid-template-columns: 1fr; }
  .ha-afiche-outils input { margin-left: 0; width: 100%; }
}
`;export{Ke as default};
