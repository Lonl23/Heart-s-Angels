import{r as c,j as e,L as ve}from"./vendor-react-y2xUrN8v.js";import{u as je,s as y,r as ye,k as K,o as ke,q as C,e as L,n as we,E as X}from"./index-BT8ZgH3V.js";import{p as Ce,c as Ae,e as R,r as Ne,d as Se,C as Z,T as V,D as W,l as Ee,a as De,b as Fe,s as $e,f as ee,g as ze}from"./activitesSecours-BLoASeTJ.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const _e={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",dispositif:"",competences:[]};function h(r){return String(r).padStart(2,"0")}function H(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${h(a.getMonth()+1)}-${h(a.getDate())}`}function te(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${h(a.getDate())}-${h(a.getMonth()+1)}-${a.getFullYear()}`}function O(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${h(a.getHours())}:${h(a.getMinutes())}`}function Le(r){const a=te(r.debut),l=O(r.debut);if(!r.fin)return{date:a,heures:l};const m=H(r.debut)===H(r.fin)?O(r.fin):`${te(r.fin)} ${O(r.fin)}`;return{date:a,heures:l&&m?`${l}–${m}`:l}}function re(r){if(!r)return"";const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${h(a.getMonth()+1)}-${h(a.getDate())}T${h(a.getHours())}:${h(a.getMinutes())}`}function ae(r){if(!r)return null;const a=new Date(r);return Number.isNaN(a.getTime())?null:a.toISOString()}function ie(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function qe(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Ie(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Oe(){const{profile:r}=je(),a=Ce(r),[l,x]=c.useState([]),[m,S]=c.useState([]),[k,J]=c.useState(!0),[Q,q]=c.useState(null),[U,u]=c.useState(null),[f,se]=c.useState(null),[E,ne]=c.useState(""),[D,oe]=c.useState(""),[F,ce]=c.useState(""),[I,le]=c.useState(""),[T,de]=c.useState("asc"),[B,M]=c.useState(null),[n,g]=c.useState(null),[A,$]=c.useState(!1);c.useEffect(()=>{z()},[r==null?void 0:r.id]);async function z(t=!1){var d,o;t||J(!0),q(null);const[i,s]=await Promise.all([y.from("activites_secours").select("id,numero,titre,type,dispositif,public_attendu,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),y.from("activites_secours_inscrits").select("id,activite_id,user_id")]);i.error||s.error?(q(((d=i.error)==null?void 0:d.message)||((o=s.error)==null?void 0:o.message)||"Chargement impossible."),x([]),S([])):(x(Array.isArray(i.data)?i.data:[]),S(Array.isArray(s.data)?s.data:[])),J(!1)}const p=c.useMemo(()=>Ae(l,m,r),[l,m,r]),G=c.useMemo(()=>{const t=I.trim().toLowerCase(),i=l.filter(s=>{const d=p.nombres.get(s.id)||0;if(f==="possible"&&!(R(s)&&d<Number(s.places)&&!p.miennes.has(s.id))||f==="competence"&&!(R(s)&&Ne(s,p.mes))||f==="bientot"&&!Se(s.debut)||E&&!(s.competences||[]).includes(E))return!1;const o=H(s.debut);return!(D&&o&&o<D||F&&o&&o>F||t&&!`${s.numero||""} ${s.titre||""} ${s.lieu||""}`.toLowerCase().includes(t))});return i.sort((s,d)=>{const o=String(s.debut).localeCompare(String(d.debut));return T==="asc"?o:-o}),i},[l,p,f,E,D,F,I,T]);function P(t){se(i=>i===t?null:t)}async function ue(t){if(!(r!=null&&r.id)||B)return;M(t.id),u(null);const i=p.miennes.has(t.id);if(!i&&$e(r,t)){u("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),M(null);return}const s=i?await y.from("activites_secours_inscrits").delete().eq("activite_id",t.id).eq("user_id",r.id):await y.from("activites_secours_inscrits").insert({activite_id:t.id,user_id:r.id});s.error?u(s.error.message||"Inscription impossible."):await z(!0),M(null)}function pe(){q(null),g({..._e,competences:[]})}function he(t){g({id:t.id,titre:t.titre||"",type:V.some(i=>i.v===t.type)?t.type:"activite",lieu:t.lieu||"",debut:re(t.debut),fin:re(t.fin),places:String(t.places??1),publicAttendu:t.public_attendu==null?"":String(t.public_attendu),dispositif:W.some(i=>i.v===t.dispositif)?t.dispositif:"",competences:ee(t.competences)})}function b(t){g(i=>({...i,...t}))}function me(t){g(i=>{const s=i.competences.includes(t)?i.competences.filter(d=>d!==t):[...i.competences,t];return{...i,competences:s}})}async function xe(t){if(t.preventDefault(),!n||A)return;const i=n.titre.trim(),s=ae(n.debut),d=ae(n.fin),o=Number(n.places);if(!i){u("Indiquez le titre.");return}if(!s){u("Indiquez le début.");return}if(n.fin&&!d){u("La fin est illisible.");return}if(d&&d<s){u("La fin est avant le début.");return}if(!Number.isInteger(o)||o<1||o>500){u("Le nombre de places doit être entre 1 et 500.");return}const N=ze(n.publicAttendu);if(N===void 0){u("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}if(n.dispositif&&!W.some(j=>j.v===n.dispositif)){u("Le type de dispositif est inconnu.");return}$(!0),u(null);const w={titre:i,type:V.some(j=>j.v===n.type)?n.type:"activite",dispositif:n.dispositif||null,public_attendu:N,lieu:n.lieu.trim()||null,debut:s,fin:d,places:o,competences:ee(n.competences)},v=n.id?await y.from("activites_secours").update(w).eq("id",n.id):await y.from("activites_secours").insert({...w,created_by:(r==null?void 0:r.id)||null});v.error?u(v.error.message||"Enregistrement impossible."):(g(null),await z(!0)),$(!1)}async function be(t){if(!t||A||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;$(!0),u(null);const i=await y.from("activites_secours").delete().eq("id",t);i.error?u(i.error.message||"Suppression impossible."):(g(null),await z(!0)),$(!1)}const fe=!k&&l.length===0,ge=!k&&l.length>0&&G.length===0;return e.jsxs(ye,{title:"Activités",subtitle:"Département secours. Une activité se dimensionne, s’arme, puis se rend en bilan.",action:a?e.jsx(L,{onClick:pe,children:"+ Activité"}):null,children:[e.jsx("style",{children:Be}),Q&&e.jsx(K,{kind:"err",children:Q}),U&&e.jsx(K,{kind:"err",children:U}),e.jsxs("div",{className:"ha-act-cartes",children:[e.jsx(Y,{tone:"possible",on:f==="possible",n:k?"…":p.possible,label:"Inscription possible",icone:e.jsx(ie,{}),onClick:()=>P("possible")}),e.jsx(Y,{tone:"competence",on:f==="competence",n:k?"…":p.competence,label:"Requiert ma compétence",icone:e.jsx(qe,{}),onClick:()=>P("competence")}),e.jsx(Y,{tone:"bientot",on:f==="bientot",n:k?"…":p.bientot,label:"Sur les 30 prochains jours",icone:e.jsx(Ie,{}),onClick:()=>P("bientot")})]}),e.jsxs("div",{className:"ha-act-filtres",children:[e.jsxs("select",{"aria-label":"Compétence",value:E,onChange:t=>ne(t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les activités"}),Z.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]}),e.jsxs("label",{className:"ha-act-dates",children:[e.jsx("span",{className:"ha-sr",children:"Du"}),e.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:D,onChange:t=>oe(t.target.value)}),e.jsx("span",{children:"au"}),e.jsx("span",{className:"ha-sr",children:"Au"}),e.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:F,onChange:t=>ce(t.target.value)})]}),e.jsxs("label",{className:"ha-act-recherche",children:[e.jsx("span",{className:"ha-sr",children:"Rechercher"}),e.jsx("input",{type:"search",placeholder:"Rechercher",value:I,onChange:t=>le(t.target.value)})]})]}),n&&e.jsx(ke,{style:{marginBottom:14},children:e.jsxs("form",{onSubmit:xe,children:[e.jsxs("div",{className:"ha-act-form",children:[e.jsx(C,{label:"Titre",value:n.titre,set:t=>b({titre:t}),required:!0}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),e.jsx("select",{value:n.type,onChange:t=>b({type:t.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:V.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))})]}),e.jsx(C,{label:"Lieu",value:n.lieu,set:t=>b({lieu:t})}),e.jsx(C,{label:"Début",type:"datetime-local",value:n.debut,set:t=>b({debut:t}),required:!0}),e.jsx(C,{label:"Fin",type:"datetime-local",value:n.fin,set:t=>b({fin:t})}),e.jsx(C,{label:"Places",type:"number",value:n.places,set:t=>b({places:t}),required:!0}),e.jsx(C,{label:"Public attendu",type:"number",value:n.publicAttendu,set:t=>b({publicAttendu:t})}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Dispositif"}),e.jsxs("select",{value:n.dispositif,onChange:t=>b({dispositif:t.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[e.jsx("option",{value:"",children:"—"}),W.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]})]})]}),e.jsx("p",{className:"ha-act-note",children:"Le type de dispositif se choisit. Il n’est pas calculé à partir du public."}),e.jsxs("div",{style:{marginBottom:8},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),e.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:Z.map(t=>e.jsx("button",{type:"button",className:"ha-act-choix-btn"+(n.competences.includes(t.v)?" is-on":""),"aria-pressed":n.competences.includes(t.v),onClick:()=>me(t.v),children:t.l},t.v))}),e.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, et type médical ou non médical."})]}),e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[e.jsx(L,{type:"submit",disabled:A,children:n.id?"Enregistrer":"Créer l’activité"}),e.jsx(L,{kind:"soft",onClick:()=>g(null),disabled:A,children:"Annuler"}),n.id&&e.jsx(L,{kind:"danger",onClick:()=>be(n.id),disabled:A,children:"Retirer"})]})]})}),k?e.jsx(we,{}):fe?e.jsx(X,{title:"Aucune activité pour le moment",hint:a?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):ge?e.jsx(X,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):e.jsx("div",{className:"ha-act-table-wrap",children:e.jsxs("table",{className:"ha-act-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Activité"}),e.jsx("th",{children:"Lieu"}),e.jsx("th",{children:e.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>de(t=>t==="asc"?"desc":"asc"),children:["Date ",e.jsx("span",{"aria-hidden":!0,children:T==="asc"?"↑":"↓"})]})}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{children:"Inscrit"}),e.jsx("th",{children:"Actions"})]})}),e.jsx("tbody",{children:G.map(t=>{const i=p.nombres.get(t.id)||0,s=Number(t.places)||0,d=p.miennes.has(t.id),o=R(t),N=i>=s,w=Le(t);let v="S’inscrire",j=!1;return d?v="Se désinscrire":o?N&&(v="Complet",j=!0):(v="Terminée",j=!0),e.jsxs("tr",{children:[e.jsx("td",{className:"ha-act-id",children:t.numero}),e.jsxs("td",{children:[e.jsx(ve,{to:`/app/secours/activites/${t.id}`,className:"ha-act-titre",children:t.titre}),e.jsxs("div",{className:"ha-act-type",children:[Ee(t.type),t.dispositif?` · ${De(t.dispositif,!0)}`:""]})]}),e.jsx("td",{className:"ha-act-lieu",children:t.lieu||"—"}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-quand",children:[e.jsx("strong",{children:w.date}),w.heures&&e.jsx("span",{children:w.heures})]})}),e.jsx("td",{children:(t.competences||[]).length===0?e.jsx("span",{className:"ha-act-aucune",children:"—"}):(t.competences||[]).map(_=>e.jsxs("span",{className:"ha-act-chip"+(p.mes.has(_)?" is-moi":" is-autre"),children:[p.mes.has(_)?"✓":"•"," ",Fe(_)]},_))}),e.jsx("td",{children:e.jsx(Te,{inscrits:i,places:s})}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-actions",children:[e.jsxs("button",{type:"button",className:"ha-act-go"+(d?" is-off":""),disabled:j||B===t.id,onClick:()=>ue(t),children:[e.jsx(ie,{}),B===t.id?"…":v]}),a&&e.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>he(t),children:"Modifier"})]})})]},t.id)})})]})})]})}function Y({tone:r,on:a,n:l,label:x,icone:m,onClick:S}){return e.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(a?" is-on":""),"aria-pressed":a,onClick:S,children:[e.jsx("span",{className:"ha-act-carte-n",children:l}),e.jsx("span",{className:"ha-act-carte-l",children:x}),e.jsx("span",{className:"ha-act-carte-ico is-"+r,children:m})]})}function Te({inscrits:r,places:a}){const l=a>0?Math.min(1,r/a):0,x=a>0&&r>=a,m=r===0?0:Math.max(l*100,18);return e.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${a} place${a>1?"s":""}`,children:[e.jsx("span",{style:{width:`${m}%`,background:x?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),e.jsxs("em",{style:{color:l>=.55||x?"#fff":"var(--text)"},children:[r,"/",a]})]})}const Be=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Oe as default};
