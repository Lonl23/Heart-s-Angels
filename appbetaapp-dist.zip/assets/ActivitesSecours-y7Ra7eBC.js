import{r as u,j as t}from"./vendor-react-y2xUrN8v.js";import{ae as ve,G as je,u as we,s as w,q as ke,j as U,n as ye,p as E,b as M,k as Ce,E as K}from"./index-D2aJGhK2.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const B=[...ve,{v:"medical",l:"Type médical"},{v:"non_medical",l:"Type non médical"}],Ne=new Set(B.map(e=>e.v));function Ae(e){var a;return((a=B.find(n=>n.v===e))==null?void 0:a.l)||e}function X(e){const a=new Set,n=[];for(const i of Array.isArray(e)?e:[])!Ne.has(i)||a.has(i)||(a.add(i),n.push(i));return n}function De(e){const a=(e==null?void 0:e.fiche)||{},n=new Set(je(e==null?void 0:e.role,a));return(a.type_benevole==="medical"||(e==null?void 0:e.role)==="volontaire_medical")&&n.add("medical"),(a.type_benevole==="non_medical"||(e==null?void 0:e.role)==="volontaire_non_medical")&&n.add("non_medical"),n}function ae(e,a){const n=Array.isArray(e==null?void 0:e.competences)?e.competences:[];return!n.length||!a||a.size===0?!1:n.some(i=>a.has(i))}function I(e,a=new Date){const n=e!=null&&e.fin?new Date(e.fin):new Date(e==null?void 0:e.debut);return!Number.isNaN(n.getTime())&&n.getTime()>=a.getTime()}function ne(e,a=new Date){const n=new Date(e);if(Number.isNaN(n.getTime()))return!1;const i=new Date(a.getFullYear(),a.getMonth(),a.getDate()),o=new Date(i);return o.setDate(o.getDate()+30),n>=i&&n<o}function Se(e){var i;const a=e==null?void 0:e.role;return!a||a==="partenaire"?!1:a==="admin"||a==="president"?!0:(((i=e==null?void 0:e.fiche)==null?void 0:i.roles_asbl)||[]).some(o=>o==="president"||o==="vice_president")}function Ee(e,a){const n=new Map,i=new Set;for(const o of e||[])n.set(o.activite_id,(n.get(o.activite_id)||0)+1),a&&o.user_id===a&&i.add(o.activite_id);return{nombres:n,miennes:i}}function _e(e,a,n,i=new Date){const{nombres:o,miennes:v}=Ee(a,n==null?void 0:n.id),f=De(n);let C=0,N=0,k=0;for(const g of e||[]){const p=o.get(g.id)||0,x=I(g,i);x&&p<Number(g.places)&&!v.has(g.id)&&(C+=1),x&&ae(g,f)&&(N+=1),ne(g.debut,i)&&(k+=1)}return{possible:C,competence:N,bientot:k,nombres:o,miennes:v,mes:f}}const Fe={id:null,titre:"",lieu:"",debut:"",fin:"",places:"1",competences:[]};function b(e){return String(e).padStart(2,"0")}function Q(e){const a=new Date(e);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${b(a.getMonth()+1)}-${b(a.getDate())}`}function Z(e){const a=new Date(e);return Number.isNaN(a.getTime())?"":`${b(a.getDate())}-${b(a.getMonth()+1)}-${a.getFullYear()}`}function H(e){const a=new Date(e);return Number.isNaN(a.getTime())?"":`${b(a.getHours())}:${b(a.getMinutes())}`}function $e(e){const a=Z(e.debut),n=H(e.debut);if(!e.fin)return{date:a,heures:n};const o=Q(e.debut)===Q(e.fin)?H(e.fin):`${Z(e.fin)} ${H(e.fin)}`;return{date:a,heures:n&&o?`${n}–${o}`:n}}function ee(e){if(!e)return"";const a=new Date(e);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${b(a.getMonth()+1)}-${b(a.getDate())}T${b(a.getHours())}:${b(a.getMinutes())}`}function te(e){if(!e)return null;const a=new Date(e);return Number.isNaN(a.getTime())?null:a.toISOString()}function re(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function qe(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function ze(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Re(){const{profile:e}=we(),a=Se(e),[n,i]=u.useState([]),[o,v]=u.useState([]),[f,C]=u.useState(!0),[N,k]=u.useState(null),[g,p]=u.useState(null),[x,se]=u.useState(null),[_,ie]=u.useState(""),[F,ce]=u.useState(""),[$,oe]=u.useState(""),[P,le]=u.useState(""),[R,de]=u.useState("asc"),[W,O]=u.useState(null),[l,j]=u.useState(null),[A,q]=u.useState(!1);u.useEffect(()=>{z()},[e==null?void 0:e.id]);async function z(r=!1){var h,d;r||C(!0),k(null);const[c,s]=await Promise.all([w.from("activites_secours").select("id,numero,titre,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),w.from("activites_secours_inscrits").select("id,activite_id,user_id")]);c.error||s.error?(k(((h=c.error)==null?void 0:h.message)||((d=s.error)==null?void 0:d.message)||"Chargement impossible."),i([]),v([])):(i(Array.isArray(c.data)?c.data:[]),v(Array.isArray(s.data)?s.data:[])),C(!1)}const m=u.useMemo(()=>_e(n,o,e),[n,o,e]),G=u.useMemo(()=>{const r=P.trim().toLowerCase(),c=n.filter(s=>{const h=m.nombres.get(s.id)||0;if(x==="possible"&&!(I(s)&&h<Number(s.places)&&!m.miennes.has(s.id))||x==="competence"&&!(I(s)&&ae(s,m.mes))||x==="bientot"&&!ne(s.debut)||_&&!(s.competences||[]).includes(_))return!1;const d=Q(s.debut);return!(F&&d&&d<F||$&&d&&d>$||r&&!`${s.numero||""} ${s.titre||""} ${s.lieu||""}`.toLowerCase().includes(r))});return c.sort((s,h)=>{const d=String(s.debut).localeCompare(String(h.debut));return R==="asc"?d:-d}),c},[n,m,x,_,F,$,P,R]);function V(r){se(c=>c===r?null:r)}async function ue(r){if(!(e!=null&&e.id)||W)return;O(r.id),p(null);const s=m.miennes.has(r.id)?await w.from("activites_secours_inscrits").delete().eq("activite_id",r.id).eq("user_id",e.id):await w.from("activites_secours_inscrits").insert({activite_id:r.id,user_id:e.id});s.error?p(s.error.message||"Inscription impossible."):await z(!0),O(null)}function he(){k(null),j({...Fe,competences:[]})}function pe(r){j({id:r.id,titre:r.titre||"",lieu:r.lieu||"",debut:ee(r.debut),fin:ee(r.fin),places:String(r.places??1),competences:X(r.competences)})}function D(r){j(c=>({...c,...r}))}function me(r){j(c=>{const s=c.competences.includes(r)?c.competences.filter(h=>h!==r):[...c.competences,r];return{...c,competences:s}})}async function xe(r){if(r.preventDefault(),!l||A)return;const c=l.titre.trim(),s=te(l.debut),h=te(l.fin),d=Number(l.places);if(!c){p("Indiquez le titre.");return}if(!s){p("Indiquez le début.");return}if(l.fin&&!h){p("La fin est illisible.");return}if(h&&h<s){p("La fin est avant le début.");return}if(!Number.isInteger(d)||d<1||d>500){p("Le nombre de places doit être entre 1 et 500.");return}q(!0),p(null);const S={titre:c,lieu:l.lieu.trim()||null,debut:s,fin:h,places:d,competences:X(l.competences)},y=l.id?await w.from("activites_secours").update(S).eq("id",l.id):await w.from("activites_secours").insert({...S,created_by:(e==null?void 0:e.id)||null});y.error?p(y.error.message||"Enregistrement impossible."):(j(null),await z(!0)),q(!1)}async function be(r){if(!r||A||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;q(!0),p(null);const c=await w.from("activites_secours").delete().eq("id",r);c.error?p(c.error.message||"Suppression impossible."):(j(null),await z(!0)),q(!1)}const fe=!f&&n.length===0,ge=!f&&n.length>0&&G.length===0;return t.jsxs(ke,{title:"Activités",subtitle:"Département secours. Tout le personnel retrouve ici les activités et peut s’inscrire.",action:a?t.jsx(M,{onClick:he,children:"+ Activité"}):null,children:[t.jsx("style",{children:Le}),N&&t.jsx(U,{kind:"err",children:N}),g&&t.jsx(U,{kind:"err",children:g}),t.jsxs("div",{className:"ha-act-cartes",children:[t.jsx(J,{tone:"possible",on:x==="possible",n:f?"…":m.possible,label:"Inscription possible",icone:t.jsx(re,{}),onClick:()=>V("possible")}),t.jsx(J,{tone:"competence",on:x==="competence",n:f?"…":m.competence,label:"Requiert ma compétence",icone:t.jsx(qe,{}),onClick:()=>V("competence")}),t.jsx(J,{tone:"bientot",on:x==="bientot",n:f?"…":m.bientot,label:"Sur les 30 prochains jours",icone:t.jsx(ze,{}),onClick:()=>V("bientot")})]}),t.jsxs("div",{className:"ha-act-filtres",children:[t.jsxs("select",{"aria-label":"Compétence",value:_,onChange:r=>ie(r.target.value),children:[t.jsx("option",{value:"",children:"Toutes les activités"}),B.map(r=>t.jsx("option",{value:r.v,children:r.l},r.v))]}),t.jsxs("label",{className:"ha-act-dates",children:[t.jsx("span",{className:"ha-sr",children:"Du"}),t.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:F,onChange:r=>ce(r.target.value)}),t.jsx("span",{children:"au"}),t.jsx("span",{className:"ha-sr",children:"Au"}),t.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:$,onChange:r=>oe(r.target.value)})]}),t.jsxs("label",{className:"ha-act-recherche",children:[t.jsx("span",{className:"ha-sr",children:"Rechercher"}),t.jsx("input",{type:"search",placeholder:"Rechercher",value:P,onChange:r=>le(r.target.value)})]})]}),l&&t.jsx(ye,{style:{marginBottom:14},children:t.jsxs("form",{onSubmit:xe,children:[t.jsxs("div",{className:"ha-act-form",children:[t.jsx(E,{label:"Titre",value:l.titre,set:r=>D({titre:r}),required:!0}),t.jsx(E,{label:"Lieu",value:l.lieu,set:r=>D({lieu:r})}),t.jsx(E,{label:"Début",type:"datetime-local",value:l.debut,set:r=>D({debut:r}),required:!0}),t.jsx(E,{label:"Fin",type:"datetime-local",value:l.fin,set:r=>D({fin:r})}),t.jsx(E,{label:"Places",type:"number",value:l.places,set:r=>D({places:r}),required:!0})]}),t.jsxs("div",{style:{marginBottom:8},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),t.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:B.map(r=>t.jsx("button",{type:"button",className:"ha-act-choix-btn"+(l.competences.includes(r.v)?" is-on":""),"aria-pressed":l.competences.includes(r.v),onClick:()=>me(r.v),children:r.l},r.v))}),t.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, et type médical ou non médical."})]}),t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(M,{type:"submit",disabled:A,children:l.id?"Enregistrer":"Créer l’activité"}),t.jsx(M,{kind:"soft",onClick:()=>j(null),disabled:A,children:"Annuler"}),l.id&&t.jsx(M,{kind:"danger",onClick:()=>be(l.id),disabled:A,children:"Retirer"})]})]})}),f?t.jsx(Ce,{}):fe?t.jsx(K,{title:"Aucune activité pour le moment",hint:a?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):ge?t.jsx(K,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):t.jsx("div",{className:"ha-act-table-wrap",children:t.jsxs("table",{className:"ha-act-table",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"ID"}),t.jsx("th",{children:"Activité"}),t.jsx("th",{children:"Lieu"}),t.jsx("th",{children:t.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>de(r=>r==="asc"?"desc":"asc"),children:["Date ",t.jsx("span",{"aria-hidden":!0,children:R==="asc"?"↑":"↓"})]})}),t.jsx("th",{children:"Compétence"}),t.jsx("th",{children:"Inscrit"}),t.jsx("th",{children:"Actions"})]})}),t.jsx("tbody",{children:G.map(r=>{const c=m.nombres.get(r.id)||0,s=Number(r.places)||0,h=m.miennes.has(r.id),d=I(r),S=c>=s,y=$e(r);let T="S’inscrire",Y=!1;return h?T="Se désinscrire":d?S&&(T="Complet",Y=!0):(T="Terminée",Y=!0),t.jsxs("tr",{children:[t.jsx("td",{className:"ha-act-id",children:r.numero}),t.jsx("td",{children:t.jsx("div",{className:"ha-act-titre",children:r.titre})}),t.jsx("td",{className:"ha-act-lieu",children:r.lieu||"—"}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-quand",children:[t.jsx("strong",{children:y.date}),y.heures&&t.jsx("span",{children:y.heures})]})}),t.jsx("td",{children:(r.competences||[]).length===0?t.jsx("span",{className:"ha-act-aucune",children:"—"}):(r.competences||[]).map(L=>t.jsxs("span",{className:"ha-act-chip"+(m.mes.has(L)?" is-moi":" is-autre"),children:[m.mes.has(L)?"✓":"•"," ",Ae(L)]},L))}),t.jsx("td",{children:t.jsx(Te,{inscrits:c,places:s})}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-actions",children:[t.jsxs("button",{type:"button",className:"ha-act-go"+(h?" is-off":""),disabled:Y||W===r.id,onClick:()=>ue(r),children:[t.jsx(re,{}),W===r.id?"…":T]}),a&&t.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>pe(r),children:"Modifier"})]})})]},r.id)})})]})})]})}function J({tone:e,on:a,n,label:i,icone:o,onClick:v}){return t.jsxs("button",{type:"button",className:"ha-act-carte is-"+e+(a?" is-on":""),"aria-pressed":a,onClick:v,children:[t.jsx("span",{className:"ha-act-carte-n",children:n}),t.jsx("span",{className:"ha-act-carte-l",children:i}),t.jsx("span",{className:"ha-act-carte-ico is-"+e,children:o})]})}function Te({inscrits:e,places:a}){const n=a>0?Math.min(1,e/a):0,i=a>0&&e>=a,o=e===0?0:Math.max(n*100,18);return t.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${e} inscrit${e>1?"s":""} sur ${a} place${a>1?"s":""}`,children:[t.jsx("span",{style:{width:`${o}%`,background:i?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),t.jsxs("em",{style:{color:n>=.55||i?"#fff":"var(--text)"},children:[e,"/",a]})]})}const Le=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Re as default};
