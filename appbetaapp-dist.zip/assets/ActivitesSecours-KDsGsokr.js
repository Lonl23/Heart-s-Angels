import{r as l,j as t,L as ee}from"./vendor-react-y2xUrN8v.js";import{u as Ne,s as N,r as qe,k as te,o as Ae,q as j,e as S,n as Se,E as re}from"./index-m5KQByts.js";import{p as Ee,c as De,e as R,r as Fe,d as _e,C as ae,T as W,D as ue,s as V,l as ze,a as ie,b as $e,f as Ie,g as U,h as Me,i as se,j as Le,k as Te}from"./activitesSecours-BOnT5FJm.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function H(){return Object.fromEntries(ue.map(r=>[r.v,0]))}const Be={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",adresse:"",organisateurNom:"",organisateurContact:"",equipes:H(),competences:[]};function b(r){return String(r).padStart(2,"0")}function J(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${b(a.getMonth()+1)}-${b(a.getDate())}`}function ne(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${b(a.getDate())}-${b(a.getMonth()+1)}-${a.getFullYear()}`}function Q(r){const a=new Date(r);return Number.isNaN(a.getTime())?"":`${b(a.getHours())}:${b(a.getMinutes())}`}function Pe(r){const a=ne(r.debut),u=Q(r.debut);if(!r.fin)return{date:a,heures:u};const f=J(r.debut)===J(r.fin)?Q(r.fin):`${ne(r.fin)} ${Q(r.fin)}`;return{date:a,heures:u&&f?`${u}–${f}`:u}}function oe(r){if(!r)return"";const a=new Date(r);return Number.isNaN(a.getTime())?"":`${a.getFullYear()}-${b(a.getMonth()+1)}-${b(a.getDate())}T${b(a.getHours())}:${b(a.getMinutes())}`}function ce(r){if(!r)return null;const a=new Date(r);return Number.isNaN(a.getTime())?null:a.toISOString()}function le(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Oe(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Re(){return t.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[t.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),t.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Ge(){const{profile:r}=Ne(),a=Ee(r),[u,y]=l.useState([]),[f,E]=l.useState([]),[q,G]=l.useState(!0),[K,I]=l.useState(null),[X,d]=l.useState(null),[C,de]=l.useState(null),[D,pe]=l.useState(""),[F,he]=l.useState(""),[_,me]=l.useState(""),[M,xe]=l.useState(""),[L,be]=l.useState("asc"),[T,B]=l.useState(null),[i,w]=l.useState(null),[A,z]=l.useState(!1);l.useEffect(()=>{$()},[r==null?void 0:r.id]);async function $(e=!1){var o,c;e||G(!0),I(null);const[s,n]=await Promise.all([N.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,adresse,organisateur_nom,organisateur_contact,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),N.from("activites_secours_inscrits").select("id,activite_id,user_id")]);s.error||n.error?(I(((o=s.error)==null?void 0:o.message)||((c=n.error)==null?void 0:c.message)||"Chargement impossible."),y([]),E([])):(y(Array.isArray(s.data)?s.data:[]),E(Array.isArray(n.data)?n.data:[])),G(!1)}const p=l.useMemo(()=>De(u,f,r),[u,f,r]),Z=l.useMemo(()=>{const e=M.trim().toLowerCase(),s=u.filter(n=>{const o=p.nombres.get(n.id)||0;if(C==="possible"&&!(R(n)&&o<Number(n.places)&&!p.miennes.has(n.id))||C==="competence"&&!(R(n)&&Fe(n,p.mes))||C==="bientot"&&!_e(n.debut)||D&&!(n.competences||[]).includes(D))return!1;const c=J(n.debut);return!(F&&c&&c<F||_&&c&&c>_||e&&!`${n.numero||""} ${n.titre||""} ${n.lieu||""}`.toLowerCase().includes(e))});return s.sort((n,o)=>{const c=String(n.debut).localeCompare(String(o.debut));return L==="asc"?c:-c}),s},[u,p,C,D,F,_,M,L]);function P(e){de(s=>s===e?null:e)}async function fe(e){if(!(r!=null&&r.id)||T)return;B(e.id),d(null);const s=p.miennes.has(e.id);if(!s&&Ie(r,e)){d("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),B(null);return}const n=s?await N.from("activites_secours_inscrits").delete().eq("activite_id",e.id).eq("user_id",r.id):await N.from("activites_secours_inscrits").insert({activite_id:e.id,user_id:r.id});n.error?d(n.error.message||"Inscription impossible."):await $(!0),B(null)}function ge(){I(null),w({...Be,equipes:H(),competences:[]})}function ve(e){w({id:e.id,titre:e.titre||"",type:W.some(s=>s.v===e.type)?e.type:"activite",lieu:e.lieu||"",debut:oe(e.debut),fin:oe(e.fin),places:String(e.places??1),publicAttendu:e.public_attendu==null?"":String(e.public_attendu),adresse:e.adresse||"",organisateurNom:e.organisateur_nom||"",organisateurContact:e.organisateur_contact||"",equipes:{...H(),...Me(e)},competences:U(e.competences)})}function x(e){w(s=>({...s,...e}))}function O(e,s,n=!1){se.has(e)&&w(o=>{var v;const c=Number(((v=o.equipes)==null?void 0:v[e])||0);let h=n?Number(s):c+Number(s);(!Number.isFinite(h)||h<0)&&(h=0),h=Math.min(20,Math.floor(h));const g={...o.equipes,[e]:h},m=V(g);return{...o,equipes:g,places:m?m.places:o.places,competences:m?U(m.competences):[]}})}function je(e){w(s=>{const n=s.competences.includes(e)?s.competences.filter(o=>o!==e):[...s.competences,e];return{...s,competences:n}})}async function ye(e){if(e.preventDefault(),!i||A)return;const s=i.titre.trim(),n=ce(i.debut),o=ce(i.fin),c=Number(i.places);if(!s){d("Indiquez le titre.");return}if(!n){d("Indiquez le début.");return}if(i.fin&&!o){d("La fin est illisible.");return}if(o&&o<n){d("La fin est avant le début.");return}if(!Number.isInteger(c)||c<1||c>500){d("Le nombre de places doit être entre 1 et 500.");return}const h=Le(i.publicAttendu);if(h===void 0){d("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}const g=Te(i.equipes);if(Object.keys(i.equipes||{}).some(k=>!se.has(k))){d("Une des équipes est inconnue.");return}z(!0),d(null);const m={titre:s,type:W.some(k=>k.v===i.type)?i.type:"activite",dispositifs:g,dispositif:g[0]||null,public_attendu:h,lieu:i.lieu.trim()||null,adresse:i.adresse.trim()||null,organisateur_nom:i.organisateurNom.trim()||null,organisateur_contact:i.organisateurContact.trim()||null,debut:n,fin:o,places:c,competences:U(i.competences)},v=i.id?await N.from("activites_secours").update(m).eq("id",i.id):await N.from("activites_secours").insert({...m,created_by:(r==null?void 0:r.id)||null});v.error?d(v.error.message||"Enregistrement impossible."):(w(null),await $(!0)),z(!1)}async function we(e){if(!e||A||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;z(!0),d(null);const s=await N.from("activites_secours").delete().eq("id",e);s.error?d(s.error.message||"Suppression impossible."):(w(null),await $(!0)),z(!1)}const ke=!q&&u.length===0,Ce=!q&&u.length>0&&Z.length===0;return t.jsxs(qe,{title:"Activités",subtitle:"Département secours. Une activité se dimensionne, s’arme, puis se rend en bilan.",action:a?t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(ee,{to:"/app/secours/conventions",children:t.jsx(S,{kind:"soft",children:"Conventions DPS"})}),t.jsx(S,{onClick:ge,children:"+ Activité"})]}):null,children:[t.jsx("style",{children:Ve}),K&&t.jsx(te,{kind:"err",children:K}),X&&t.jsx(te,{kind:"err",children:X}),t.jsxs("div",{className:"ha-act-cartes",children:[t.jsx(Y,{tone:"possible",on:C==="possible",n:q?"…":p.possible,label:"Inscription possible",icone:t.jsx(le,{}),onClick:()=>P("possible")}),t.jsx(Y,{tone:"competence",on:C==="competence",n:q?"…":p.competence,label:"Requiert ma compétence",icone:t.jsx(Oe,{}),onClick:()=>P("competence")}),t.jsx(Y,{tone:"bientot",on:C==="bientot",n:q?"…":p.bientot,label:"Sur les 30 prochains jours",icone:t.jsx(Re,{}),onClick:()=>P("bientot")})]}),t.jsxs("div",{className:"ha-act-filtres",children:[t.jsxs("select",{"aria-label":"Compétence",value:D,onChange:e=>pe(e.target.value),children:[t.jsx("option",{value:"",children:"Toutes les activités"}),ae.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))]}),t.jsxs("label",{className:"ha-act-dates",children:[t.jsx("span",{className:"ha-sr",children:"Du"}),t.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:F,onChange:e=>he(e.target.value)}),t.jsx("span",{children:"au"}),t.jsx("span",{className:"ha-sr",children:"Au"}),t.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:_,onChange:e=>me(e.target.value)})]}),t.jsxs("label",{className:"ha-act-recherche",children:[t.jsx("span",{className:"ha-sr",children:"Rechercher"}),t.jsx("input",{type:"search",placeholder:"Rechercher",value:M,onChange:e=>xe(e.target.value)})]})]}),i&&t.jsx(Ae,{style:{marginBottom:14},children:t.jsxs("form",{onSubmit:ye,children:[t.jsxs("div",{className:"ha-act-form",children:[t.jsx(j,{label:"Titre",value:i.titre,set:e=>x({titre:e}),required:!0}),t.jsxs("label",{style:{marginBottom:10,display:"block"},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),t.jsx("select",{value:i.type,onChange:e=>x({type:e.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:W.map(e=>t.jsx("option",{value:e.v,children:e.l},e.v))})]}),t.jsx(j,{label:"Lieu (libellé)",value:i.lieu,set:e=>x({lieu:e})}),t.jsx(j,{label:"Adresse exacte du site",value:i.adresse,set:e=>x({adresse:e})}),t.jsx(j,{label:"Organisateur",value:i.organisateurNom,set:e=>x({organisateurNom:e})}),t.jsx(j,{label:"Contact organisateur",value:i.organisateurContact,set:e=>x({organisateurContact:e})}),t.jsx(j,{label:"Début",type:"datetime-local",value:i.debut,set:e=>x({debut:e}),required:!0}),t.jsx(j,{label:"Fin",type:"datetime-local",value:i.fin,set:e=>x({fin:e})}),t.jsx(j,{label:"Places",type:"number",value:i.places,set:e=>x({places:e}),required:!0}),t.jsx(j,{label:"Public attendu",type:"number",value:i.publicAttendu,set:e=>x({publicAttendu:e})})]}),t.jsxs("div",{style:{marginBottom:10},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Équipes / dispositifs"}),t.jsx("div",{className:"ha-act-equipes-qte",role:"group","aria-label":"Quantité par équipe",children:ue.map(e=>{var n;const s=Number(((n=i.equipes)==null?void 0:n[e.v])||0);return t.jsxs("div",{className:"ha-act-equipe-ligne"+(s>0?" is-on":""),children:[t.jsxs("div",{className:"ha-act-equipe-nom",children:[t.jsx("strong",{children:e.court}),t.jsx("span",{children:e.l.replace(/^[^—]+—\s*/,"")})]}),t.jsxs("div",{className:"ha-act-equipe-stepper",children:[t.jsx("button",{type:"button","aria-label":`Retirer un ${e.court}`,disabled:s<=0,onClick:()=>O(e.v,-1),children:"−"}),t.jsx("input",{type:"number",min:0,max:20,value:s,"aria-label":`Nombre de ${e.court}`,onChange:o=>O(e.v,o.target.value,!0)}),t.jsx("button",{type:"button","aria-label":`Ajouter un ${e.court}`,disabled:s>=20,onClick:()=>O(e.v,1),children:"+"})]})]},e.v)})})]}),Object.values(i.equipes||{}).some(e=>e>0)&&V(i.equipes)&&t.jsxs("p",{className:"ha-act-note",style:{color:"var(--heading)"},children:["Effectif minimum : ",V(i.equipes).resume,". Places et compétences sont préremplies — vous pouvez encore les ajuster."]}),t.jsx("p",{className:"ha-act-note",children:"Indiquez combien de chaque équipe (ex. 2 AMBU + 1 PMA). Un préventif peut en combiner plusieurs. Matrices = département secours uniquement. « Secouriste minimum » = ordre des qualifications 1→7."}),t.jsxs("div",{style:{marginBottom:8},children:[t.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),t.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:ae.map(e=>t.jsx("button",{type:"button",className:"ha-act-choix-btn"+(i.competences.includes(e.v)?" is-on":""),"aria-pressed":i.competences.includes(e.v),onClick:()=>je(e.v),children:e.l},e.v))}),t.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, SIAMU, et type médical ou non médical."})]}),t.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[t.jsx(S,{type:"submit",disabled:A,children:i.id?"Enregistrer":"Créer l’activité"}),t.jsx(S,{kind:"soft",onClick:()=>w(null),disabled:A,children:"Annuler"}),i.id&&t.jsx(S,{kind:"danger",onClick:()=>we(i.id),disabled:A,children:"Retirer"})]})]})}),q?t.jsx(Se,{}):ke?t.jsx(re,{title:"Aucune activité pour le moment",hint:a?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):Ce?t.jsx(re,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):t.jsx("div",{className:"ha-act-table-wrap",children:t.jsxs("table",{className:"ha-act-table",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{children:"ID"}),t.jsx("th",{children:"Activité"}),t.jsx("th",{children:"Lieu"}),t.jsx("th",{children:t.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>be(e=>e==="asc"?"desc":"asc"),children:["Date ",t.jsx("span",{"aria-hidden":!0,children:L==="asc"?"↑":"↓"})]})}),t.jsx("th",{children:"Compétence"}),t.jsx("th",{children:"Inscrit"}),t.jsx("th",{children:"Actions"})]})}),t.jsx("tbody",{children:Z.map(e=>{const s=p.nombres.get(e.id)||0,n=Number(e.places)||0,o=p.miennes.has(e.id),c=R(e),h=s>=n,g=Pe(e);let m="S’inscrire",v=!1;return o?m="Se désinscrire":c?h&&(m="Complet",v=!0):(m="Terminée",v=!0),t.jsxs("tr",{children:[t.jsx("td",{className:"ha-act-id",children:e.numero}),t.jsxs("td",{children:[t.jsx(ee,{to:`/app/secours/activites/${e.id}`,className:"ha-act-titre",children:e.titre}),t.jsxs("div",{className:"ha-act-type",children:[ze(e.type),ie(e)?` · ${ie(e)}`:""]})]}),t.jsx("td",{className:"ha-act-lieu",children:e.lieu||"—"}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-quand",children:[t.jsx("strong",{children:g.date}),g.heures&&t.jsx("span",{children:g.heures})]})}),t.jsx("td",{children:(e.competences||[]).length===0?t.jsx("span",{className:"ha-act-aucune",children:"—"}):(e.competences||[]).map(k=>t.jsxs("span",{className:"ha-act-chip"+(p.mes.has(k)?" is-moi":" is-autre"),children:[p.mes.has(k)?"✓":"•"," ",$e(k)]},k))}),t.jsx("td",{children:t.jsx(We,{inscrits:s,places:n})}),t.jsx("td",{children:t.jsxs("div",{className:"ha-act-actions",children:[t.jsxs("button",{type:"button",className:"ha-act-go"+(o?" is-off":""),disabled:v||T===e.id,onClick:()=>fe(e),children:[t.jsx(le,{}),T===e.id?"…":m]}),a&&t.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>ve(e),children:"Modifier"})]})})]},e.id)})})]})})]})}function Y({tone:r,on:a,n:u,label:y,icone:f,onClick:E}){return t.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(a?" is-on":""),"aria-pressed":a,onClick:E,children:[t.jsx("span",{className:"ha-act-carte-n",children:u}),t.jsx("span",{className:"ha-act-carte-l",children:y}),t.jsx("span",{className:"ha-act-carte-ico is-"+r,children:f})]})}function We({inscrits:r,places:a}){const u=a>0?Math.min(1,r/a):0,y=a>0&&r>=a,f=r===0?0:Math.max(u*100,18);return t.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${a} place${a>1?"s":""}`,children:[t.jsx("span",{style:{width:`${f}%`,background:y?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),t.jsxs("em",{style:{color:u>=.55||y?"#fff":"var(--text)"},children:[r,"/",a]})]})}const Ve=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-equipes-qte { display: flex; flex-direction: column; gap: 8px; margin-top: 8px; }
.ha-act-equipe-ligne {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface);
  grid-column: 1 / -1;
}
.ha-act-equipe-ligne.is-on { border-color: var(--accent); }
.ha-act-equipe-nom { min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.ha-act-equipe-nom strong { font-size: 13.5px; color: var(--heading); }
.ha-act-equipe-nom span { font-size: 11.5px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 52vw; }
.ha-act-equipe-stepper { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }
.ha-act-equipe-stepper button {
  width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--heading); font-size: 18px; line-height: 1;
  font-family: inherit; cursor: pointer;
}
.ha-act-equipe-stepper button:disabled { opacity: .35; cursor: default; }
.ha-act-equipe-stepper input {
  width: 44px; text-align: center; padding: 6px 4px; border: 1px solid var(--border);
  border-radius: 8px; background: var(--surface); color: var(--text); font-family: inherit; font-size: 14px;
}
.ha-act-equipe-stepper input::-webkit-outer-spin-button,
.ha-act-equipe-stepper input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ha-act-equipe-stepper input[type=number] { -moz-appearance: textfield; appearance: textfield; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Ge as default};
