import{i as He,r as l,j as e,L as Ne}from"./vendor-react-y2xUrN8v.js";import{u as Qe,s as k,r as X,n as Ge,k as Z,E as We,e as U,_ as ee,c as Ye}from"./index-DOUqbfDJ.js";import{n as ae,j as we,k as Je,e as Ke,m as Xe,o as Ze,a as ea,l as ie,q as O,b as te,t as qe,f as V,u as aa,v as ia,C as ta,w as sa,x as ra,s as na}from"./activitesSecours-DoZYrEpN.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function C(s){return String(s).padStart(2,"0")}function F(s){const t=new Date(s);return Number.isNaN(t.getTime())?"":`${C(t.getDate())}-${C(t.getMonth()+1)}-${t.getFullYear()}`}function re(s){const t=new Date(s);return Number.isNaN(t.getTime())?"":`${C(t.getHours())}:${C(t.getMinutes())}`}function Ae(s){const t=new Date(s);return Number.isNaN(t.getTime())?"":`${t.getFullYear()}-${C(t.getMonth()+1)}-${C(t.getDate())}`}function z(s){return s?`${F(s)} ${re(s)}`:""}function ma(){var je,ke;const{id:s}=He(),{profile:t}=Qe(),[a,u]=l.useState(null),[w,ne]=l.useState([]),[$,oe]=l.useState([]),[H,$e]=l.useState(null),[B,ce]=l.useState("info"),[y,Se]=l.useState("dimensionner"),[Ee,S]=l.useState(!0),[le,de]=l.useState(!1),[T,L]=l.useState(null),[he,g]=l.useState(null),[E,Q]=l.useState(!1),[P,De]=l.useState(""),[G,ze]=l.useState(""),[p,W]=l.useState(null),[Fe,Be]=l.useState([]),[Y,pe]=l.useState(!1);l.useEffect(()=>{ue()},[s,t==null?void 0:t.id]);async function ue(i=!1){i||S(!0),L(null),de(!1);const n=await k.from("activites_secours").select("id,numero,titre,type,dispositif,public_attendu,lieu,debut,fin,places,competences,armement,created_by,created_at").eq("id",s).maybeSingle();if(n.error){L(n.error.message||"Chargement impossible."),i||u(null),S(!1);return}if(!n.data){de(!0),u(null),S(!1);return}const o=await k.from("activites_secours_inscrits").select("id,user_id,created_at").eq("activite_id",s);if(o.error){L(o.error.message||"Chargement des inscriptions impossible."),u(n.data),ne([]),oe([]),S(!1);return}const r=o.data||[],N=[...new Set(r.map(h=>h.user_id).filter(Boolean))];let j=[];if(N.length){const h=await k.from("profiles").select("id,prenom,nom,role,fiche").in("id",N);h.error?L(h.error.message||"Chargement du personnel impossible."):j=h.data||[]}let x=null;if(n.data.created_by){const h=await k.from("profiles").select("id,prenom,nom").eq("id",n.data.created_by).maybeSingle();h.error||(x=h.data)}u(n.data),W(ae(n.data.armement,n.data.dispositif)),ne(r),oe(j),$e(x);const c=await k.from("plaques_vehicules").select("plaque,libelle").eq("actif",!0).order("plaque");c.error||Be(c.data||[]),S(!1)}const me=l.useMemo(()=>we(t),[t]),I=w.some(i=>i.user_id===(t==null?void 0:t.id)),b=Number(a==null?void 0:a.places)||0,m=w.length,q=a?Je(a):"a_venir",Te=a?Ke(a):!1,Le=b>0&&m>=b,f=Array.isArray(a==null?void 0:a.competences)?a.competences:[],A=a?Xe(a):null,Pe=a&&Ae(a.debut)===Ae(a.fin||a.debut),_=l.useMemo(()=>Ze(a==null?void 0:a.dispositif,$),[a==null?void 0:a.dispositif,$]),v=a!=null&&a.dispositif?ea(a.dispositif):null,fe=l.useMemo(()=>{const i=new Map($.map(o=>[o.id,o])),n=G.trim().toLowerCase();return w.map(o=>{const r=i.get(o.user_id),N=(r==null?void 0:r.fiche)||{},j=r?[...we(r)]:[],x=j.filter(h=>h!=="medical"&&h!=="non_medical"&&h!=="volontaire_non_medical"),c=f.some(h=>j.includes(h)||_e(h,r));return{id:o.user_id,inscription:o.created_at,prenom:(r==null?void 0:r.prenom)||"",nom:(r==null?void 0:r.nom)||"",photo:N.photo_url||"",role:(r==null?void 0:r.role)||"",quals:x,manque:f.length>0&&!c}}).filter(o=>P&&!o.quals.includes(P)?!1:n?`${o.prenom} ${o.nom}`.toLowerCase().includes(n):!0).sort((o,r)=>`${o.nom} ${o.prenom}`.localeCompare(`${r.nom} ${r.prenom}`,"fr"))},[w,$,G,P,f]);function D(i){Se(i),i==="dimensionner"&&ce("info"),i==="armer"&&ce("personnel")}function xe(i){W(n=>({...n||ae(null,a==null?void 0:a.dispositif),...i}))}function Ie(i){W(n=>{const o=n||ae(null,a==null?void 0:a.dispositif);return{...o,items:o.items.map(r=>r.id===i?{...r,ok:!r.ok}:r)}})}async function Me(){if(!(a!=null&&a.id)||!p||Y)return;pe(!0),g(null);const i={plaque:p.plaque||"",note:p.note||"",items:p.items||[]},{error:n}=await k.from("activites_secours").update({armement:i}).eq("id",a.id);n?g(n.message||"Armement non enregistré."):(u(o=>({...o,armement:i})),g(null)),pe(!1)}function ge(){var r,N,j;const i=((N=(r=ee.bases)==null?void 0:r[0])==null?void 0:N.adresse)||{},n=[[i.rue,i.numero].filter(Boolean).join(" "),[i.cp,i.localite].filter(Boolean).join(" ")].filter(Boolean).join(", "),o=w.map(x=>{const c=$.find(R=>R.id===x.user_id),h=(c==null?void 0:c.fiche)||{},ye=Array.isArray(h.qualifications)?h.qualifications:[],K={prenom:(c==null?void 0:c.prenom)||"",nom:(c==null?void 0:c.nom)||"",quals:ye,role:(c==null?void 0:c.role)||""},Ve=f.some(R=>ye.includes(R)||_e(R,c));return{prenom:K.prenom,nom:K.nom,fonction:Ce(K),couverture:f.length===0?"Aucune exigée":Ve?"Couvre au moins une compétence":"Aucune des compétences demandées"}}).sort((x,c)=>`${x.nom} ${x.prenom}`.localeCompare(`${c.nom} ${c.prenom}`,"fr"));return{organisation:ve,adresse:n,logo:`${window.location.origin}${((j=ee.organisation)==null?void 0:j.logoUrl)||"/icons/ha-logo-512-v4.png"}`,imprimePar:`${((t==null?void 0:t.nom)||"").toUpperCase()} ${(t==null?void 0:t.prenom)||""}`.trim(),numero:a.numero,titre:a.titre,type:ie(a.type),dispositif:te(a.dispositif)||"",publicAttendu:a.public_attendu==null?"":String(a.public_attendu),debut:z(a.debut),fin:a.fin?z(a.fin):"",duree:A||"",lieu:a.lieu||"",places:b,competences:f.map(V),personnel:o,statut:O(q),inscrits:m}}function Re(){sa(ge())||g("Le bilan n’a pas pu être téléchargé.")}function Ue(){ra(ge())||g("Le navigateur a bloqué la fenêtre du bilan. Utilisez Récupérer.")}async function be(){if(!(t!=null&&t.id)||!a||E)return;if(Q(!0),g(null),!I&&na(t,a)){g("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),Q(!1);return}const i=I?await k.from("activites_secours_inscrits").delete().eq("activite_id",a.id).eq("user_id",t.id):await k.from("activites_secours_inscrits").insert({activite_id:a.id,user_id:t.id});i.error?g(i.error.message||"Inscription impossible."):await ue(!0),Q(!1)}let M="S’inscrire",J=!1;I?M="Se désinscrire":Te?Le&&(M="Complet",J=!0):(M="Terminée",J=!0);const ve=((je=ee.organisation)==null?void 0:je.nom)||"Heart’s Angels ASBL",Oe=a!=null&&a.lieu?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.lieu)}`:"";return Ee?e.jsx(X,{title:"Activité",children:e.jsx(Ge,{})}):a?e.jsxs(X,{children:[e.jsx("style",{children:ca}),T&&e.jsx(Z,{kind:"err",children:T}),he&&e.jsx(Z,{kind:"err",children:he}),e.jsxs("div",{className:"ha-afiche",children:[e.jsxs("header",{className:"ha-afiche-head",children:[e.jsxs("div",{className:"ha-afiche-top",children:[e.jsxs("div",{children:[e.jsx(Ne,{to:"/app/secours/activites",className:"ha-afiche-retour",children:"Activités"}),e.jsx("p",{className:"ha-afiche-type",children:ie(a.type)}),e.jsx("h1",{children:a.titre}),e.jsxs("p",{className:"ha-afiche-quand",children:[Pe?F(a.debut):`du ${F(a.debut)} au ${F(a.fin||a.debut)}`," · ",re(a.debut),a.fin?` – ${re(a.fin)}`:"",A?` (${A})`:""]})]}),e.jsx("span",{className:"ha-afiche-etat is-"+q,children:O(q)})]}),e.jsxs("div",{className:"ha-afiche-chiffres",children:[e.jsx(se,{label:"Personnel inscrit",valeur:m}),e.jsx(se,{label:"Places",valeur:`${m} / ${b}`}),e.jsx(se,{label:"Durée",valeur:A||"—"})]})]}),e.jsxs("nav",{className:"ha-dps-temps","aria-label":"Déroulement du dispositif",children:[e.jsxs("button",{type:"button",className:y==="dimensionner"?"is-on":"",onClick:()=>D("dimensionner"),children:[e.jsx("span",{children:"1"})," Dimensionner"]}),e.jsxs("button",{type:"button",className:y==="armer"?"is-on":"",onClick:()=>D("armer"),children:[e.jsx("span",{children:"2"})," Armer"]}),e.jsxs("button",{type:"button",className:y==="rendre"?"is-on":"",onClick:()=>D("rendre"),children:[e.jsx("span",{children:"3"})," Rendre"]})]}),y!=="rendre"&&e.jsxs("nav",{className:"ha-afiche-onglets","aria-label":"Fiche de l’activité",children:[e.jsx("button",{type:"button",className:B==="info"?"is-on":"",onClick:()=>D("dimensionner"),children:"Information"}),e.jsxs("button",{type:"button",className:B==="personnel"?"is-on":"",onClick:()=>D("armer"),children:["Personnel",m?` ${m}`:""]})]}),y==="rendre"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Bilan de fin"}),e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:8},children:q==="terminee"?"Le dispositif est terminé. Le bilan reprend l’équipe inscrite, la durée et le dimensionnement.":"Le dispositif n’est pas encore terminé. Le bilan reprend déjà ce qui est enregistré."}),e.jsxs("div",{className:"ha-afiche-kv",style:{marginTop:14},children:[e.jsx(d,{k:"Dispositif",v:te(a.dispositif)||"—"}),e.jsx(d,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)}),e.jsx(d,{k:"Équipe",v:`${m} / ${b}`}),e.jsx(d,{k:"Durée",v:A||"—"})]}),e.jsxs("div",{className:"ha-dps-actions",children:[e.jsx(U,{onClick:Re,children:"Récupérer"}),e.jsx(U,{kind:"soft",onClick:Ue,children:"Imprimer"})]})]}),y!=="rendre"&&B==="info"&&e.jsxs("div",{className:"ha-afiche-grille",children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Détails de l’activité"}),e.jsx("p",{className:"ha-afiche-sec",children:"Identité"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"N°",v:a.numero??"—"}),e.jsx(d,{k:"Statut",v:O(q)}),e.jsx(d,{k:"Type",v:ie(a.type)}),e.jsx(d,{k:"Nom",v:a.titre}),e.jsx(d,{k:"Dispositif",v:te(a.dispositif)||"—"}),e.jsx(d,{k:"Effectif min.",v:(v==null?void 0:v.resume)||"—"}),e.jsx(d,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)})]}),e.jsx("p",{className:"ha-afiche-vide",children:"Le type d’équipe se choisit à la création. Il n’est pas déduit du public (département secours uniquement)."}),v&&e.jsx("p",{className:"ha-afiche-vide",style:{color:_.ok?"var(--heading)":"#A32D2D",marginTop:8},children:_.ok?"Équipe inscrite : effectif minimum atteint.":`Équipe incomplète — manque : ${qe(_)}.`}),e.jsx("p",{className:"ha-afiche-sec",children:"Organisation"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Organisée par",v:ve}),e.jsx(d,{k:"Créée par",v:H?`${H.prenom||""} ${H.nom||""}`.trim():"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Date et horaires"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Début",v:z(a.debut)}),e.jsx(d,{k:"Fin",v:a.fin?z(a.fin):"—"}),e.jsx(d,{k:"Durée",v:A||"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Suivi"}),e.jsx(d,{k:"Créée le",v:z(a.created_at)||"—"})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Inscription"}),e.jsx("p",{className:"ha-afiche-sec",children:"État"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Statut",v:O(q)}),e.jsx(d,{k:"Places",v:b?`${Math.max(b-m,0)} libre${b-m>1?"s":""}`:"—"}),e.jsx(d,{k:"Qui peut s’inscrire",v:"Personnel de l’association"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Compétences demandées"}),f.length===0?e.jsx("p",{className:"ha-afiche-vide",children:"Aucune compétence exigée."}):e.jsx("div",{className:"ha-afiche-chips",children:f.map(i=>e.jsxs("span",{className:"ha-act-chip"+(me.has(i)?" is-moi":" is-autre"),children:[me.has(i)?"✓":"•"," ",V(i)]},i))}),e.jsx("div",{style:{marginTop:14},children:e.jsx(U,{onClick:be,disabled:J||E,kind:I?"danger":"primary",children:E?"…":M})})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Lieu"}),a.lieu?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-lieu",children:a.lieu}),e.jsx("a",{className:"ha-afiche-maps",href:Oe,target:"_blank",rel:"noreferrer",children:"Ouvrir dans Google Maps"})]}):e.jsx("p",{className:"ha-afiche-vide",children:"Aucun lieu renseigné."})]})]}),y!=="rendre"&&B==="personnel"&&e.jsxs(e.Fragment,{children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Effectif requis"}),v?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:v.resume}),e.jsx("p",{style:{marginTop:10,fontWeight:650,color:_.ok?"var(--heading)":"#A32D2D"},children:_.ok?"Minimum atteint avec les inscrits.":`Manque : ${qe(_)}`}),((ke=v.alternatives)==null?void 0:ke.length)>1&&e.jsxs("p",{className:"ha-afiche-vide",style:{marginTop:8},children:["Compositions acceptées : ",v.alternatives.map((i,n)=>e.jsxs("span",{children:[n?" · ou · ":"",i.map(o=>`${o.n} ${aa(o.role)}`).join(" + ")]},n))]})]}):e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:"Aucun type d’équipe choisi à la création."})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Armement"}),p&&e.jsxs(e.Fragment,{children:[e.jsxs("label",{style:{display:"block",marginTop:8,marginBottom:10},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Véhicule (plaque)"}),e.jsxs("select",{value:p.plaque||"",onChange:i=>xe({plaque:i.target.value}),style:{width:"100%",maxWidth:320,padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[e.jsx("option",{value:"",children:"—"}),Fe.map(i=>e.jsxs("option",{value:i.plaque,children:[i.plaque,i.libelle?` — ${i.libelle}`:""]},i.plaque))]})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:8,marginBottom:12},children:p.items.map(i=>e.jsxs("label",{style:{display:"flex",alignItems:"center",gap:10,cursor:"pointer"},children:[e.jsx("input",{type:"checkbox",checked:!!i.ok,onChange:()=>Ie(i.id)}),e.jsx("span",{children:i.label})]},i.id))}),e.jsxs("label",{style:{display:"block",marginBottom:12},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Note / dérogation"}),e.jsx("textarea",{value:p.note||"",onChange:i=>xe({note:i.target.value}),rows:2,style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit",resize:"vertical"}})]}),e.jsxs("p",{className:"ha-afiche-vide",style:{marginBottom:10},children:[ia(p)?"Checklist complète.":"Checklist incomplète — précisez une dérogation si besoin.",p.plaque?` Véhicule : ${p.plaque}.`:" Aucune plaque choisie."]}),e.jsx(U,{onClick:Me,disabled:Y,children:Y?"…":"Enregistrer l’armement"})]})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Personnel inscrit"}),e.jsxs("div",{className:"ha-afiche-outils",children:[e.jsxs("select",{"aria-label":"Compétence",value:P,onChange:i=>De(i.target.value),children:[e.jsx("option",{value:"",children:"Toutes les compétences"}),ta.filter(i=>i.v!=="medical"&&i.v!=="non_medical").map(i=>e.jsx("option",{value:i.v,children:i.l},i.v))]}),e.jsx("input",{type:"search",placeholder:"Rechercher","aria-label":"Rechercher une personne",value:G,onChange:i=>ze(i.target.value)})]}),fe.length===0?e.jsx("p",{className:"ha-afiche-vide",children:w.length===0?"Personne n’est inscrit pour le moment.":"Aucune personne ne correspond."}):e.jsx("div",{className:"ha-afiche-table-wrap",children:e.jsxs("table",{className:"ha-afiche-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Photo"}),e.jsx("th",{children:"Personnel"}),e.jsx("th",{children:"Fonction"}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:fe.map(i=>e.jsxs("tr",{className:i.manque?"is-manque":void 0,children:[e.jsx("td",{children:e.jsx(oa,{url:i.photo,prenom:i.prenom,nom:i.nom})}),e.jsxs("td",{children:[e.jsx("strong",{children:`${i.prenom} ${i.nom}`.trim()||"Compte retiré"}),e.jsx("span",{className:"ha-afiche-sous",children:F(i.inscription)})]}),e.jsx("td",{children:Ce(i)}),e.jsx("td",{children:i.quals.length===0?e.jsx("span",{className:"ha-afiche-vide",children:"—"}):i.quals.map(n=>e.jsx("span",{className:"ha-act-chip"+(f.includes(n)?" is-moi":""),children:V(n)},n))}),e.jsx("td",{children:i.id===(t==null?void 0:t.id)&&e.jsx("button",{type:"button",className:"ha-afiche-moi",onClick:be,disabled:E,children:E?"…":"Se désinscrire"})})]},i.id))})]})})]})]})]})]}):e.jsxs(X,{title:"Activité",children:[T&&e.jsx(Z,{kind:"err",children:T}),e.jsx(We,{title:le?"Activité introuvable":"Activité indisponible",hint:le?"Elle a été retirée, ou le lien ne correspond à rien.":"Le chargement a échoué.",action:e.jsx(Ne,{to:"/app/secours/activites",children:"Retour aux activités"})})]})}function _e(s,t){var a,u;return t?s==="medical"?((a=t.fiche)==null?void 0:a.type_benevole)==="medical"||t.role==="volontaire_medical":s==="non_medical"?((u=t.fiche)==null?void 0:u.type_benevole)==="non_medical"||t.role==="volontaire_non_medical":!1:!1}function Ce(s){const t=s.quals.find(a=>a!=="autre")||s.quals[0];return t?V(t):s.role?Ye(s.role):"—"}function d({k:s,v:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:s}),e.jsx("div",{className:"ha-afiche-v",children:t||"—"})]})}function se({label:s,valeur:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:s}),e.jsx("div",{className:"ha-afiche-nb",children:t})]})}function oa({url:s,prenom:t,nom:a}){const u=`${(t||"").charAt(0)}${(a||"").charAt(0)}`.toUpperCase()||"?";return e.jsx("span",{className:"ha-afiche-photo",children:s?e.jsx("img",{src:s,alt:""}):e.jsx("span",{children:u})})}const ca=`
.ha-afiche { display: flex; flex-direction: column; gap: 12px; }
.ha-afiche-head, .ha-afiche-carte {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 14px 16px 12px;
}
.ha-afiche-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.ha-afiche-retour { font-size: 12.5px; font-weight: 700; color: var(--accent); text-decoration: none; }
.ha-afiche-type { margin: 6px 0 0; font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche h1 { margin: 2px 0 0; font-size: 1.35rem; color: var(--heading); line-height: 1.2; }
.ha-afiche-quand { margin: 4px 0 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-etat {
  flex: none;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
}
.ha-afiche-etat.is-a_venir { background: #E6F1FB; color: #185FA5; }
.ha-afiche-etat.is-en_cours { background: #E7F6EE; color: #1E7A45; }
.ha-afiche-etat.is-terminee { background: var(--bg-alt); color: var(--text-muted); }
.ha-afiche-chiffres {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.ha-afiche-nb { font-size: 1.35rem; font-weight: 700; color: var(--heading); font-variant-numeric: tabular-nums; }
.ha-dps-temps { display: flex; gap: 8px; flex-wrap: wrap; }
.ha-dps-temps button {
  display: inline-flex; align-items: center; gap: 8px;
  border: 1px solid var(--border); background: var(--card); color: var(--text);
  border-radius: 999px; padding: 7px 12px; font: inherit; font-weight: 700; font-size: 13.5px; cursor: pointer;
}
.ha-dps-temps button span {
  width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center;
  background: var(--bg-alt); color: var(--heading); font-size: 12px;
}
.ha-dps-temps button.is-on { border-color: var(--accent); color: var(--heading); }
.ha-dps-temps button.is-on span { background: var(--accent); color: #fff; }
.ha-dps-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.ha-afiche-onglets { display: flex; gap: 6px; border-bottom: 1px solid var(--border); }
.ha-afiche-onglets button {
  border: none;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-weight: 700;
  font-size: 14px;
  padding: 8px 12px 10px;
  border-bottom: 2px solid transparent;
  cursor: pointer;
}
.ha-afiche-onglets button.is-on { color: var(--accent-blue); border-bottom-color: var(--accent); }
.ha-afiche-grille {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr) minmax(220px, .8fr);
  gap: 12px;
  align-items: start;
}
.ha-afiche-carte h2 { margin: 0; font-size: 1rem; color: var(--heading); }
.ha-afiche-sec {
  margin: 14px 0 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ha-afiche-kv { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.ha-afiche-k { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche-v { margin-top: 2px; font-size: 14px; font-weight: 650; color: var(--text); }
.ha-afiche-vide { margin: 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-lieu { margin: 8px 0; font-weight: 700; color: var(--heading); }
.ha-afiche-maps { color: var(--accent); font-weight: 700; font-size: 13px; }
.ha-afiche-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.ha-act-chip {
  display: inline-flex; align-items: center; gap: 4px;
  margin: 2px 4px 2px 0; padding: 2px 8px; border-radius: 999px;
  font-size: 11.5px; font-weight: 700; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--text-2); white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-afiche-outils { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.ha-afiche-outils select, .ha-afiche-outils input {
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font: inherit; font-size: 13px; padding: 7px 10px;
}
.ha-afiche-outils input { margin-left: auto; min-width: min(240px, 70vw); }
.ha-afiche-table-wrap { overflow: auto; }
.ha-afiche-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 640px; }
.ha-afiche-table th {
  text-align: left; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  color: var(--text-muted); font-weight: 700; padding: 8px 10px; border-bottom: 1px solid var(--border);
}
.ha-afiche-table td { padding: 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.ha-afiche-table tr.is-manque td { background: #fff6f6; }
.ha-afiche-table td strong { display: block; color: var(--accent-blue); }
.ha-afiche-sous { display: block; color: var(--text-muted); font-size: 12px; font-weight: 500; }
.ha-afiche-photo {
  width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
  display: grid; place-items: center; background: var(--accent); color: #fff; font-weight: 700; font-size: 12px;
}
.ha-afiche-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ha-afiche-moi {
  border: 1px solid var(--border); background: var(--card); color: #A32D2D;
  border-radius: 8px; padding: 5px 8px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
}
[data-theme="dark"] .ha-afiche-etat.is-a_venir { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-afiche-etat.is-en_cours { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-afiche-table tr.is-manque td { background: rgba(163,45,45,.16); }
[data-theme="dark"] .ha-afiche-onglets button.is-on,
[data-theme="dark"] .ha-afiche-table td strong { color: var(--heading); }
[data-theme="dark"] .ha-afiche-moi { color: #F0A0A0; }
@media (max-width: 980px) {
  .ha-afiche-grille { grid-template-columns: 1fr; }
  .ha-afiche-chiffres { grid-template-columns: 1fr; }
  .ha-afiche-outils input { margin-left: 0; width: 100%; }
}
`;export{ma as default};
