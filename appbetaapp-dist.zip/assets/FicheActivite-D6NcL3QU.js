import{i as Ge,r as c,j as e,L as Ne}from"./vendor-react-y2xUrN8v.js";import{u as We,s as k,r as X,n as Ye,k as Z,E as Je,e as U,_ as ee,c as Ke}from"./index-CrILBbmT.js";import{n as ae,m as qe,o as Xe,e as Ze,q as ea,t as aa,h as ia,u as ta,s as sa,a as ra,l as ie,v as O,w as we,b as V,x as Ae,y as na,z as oa,C as ca,A as la,B as da,f as ha,E as ua}from"./activitesSecours-pgaT3M_v.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";function C(n){return String(n).padStart(2,"0")}function F(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${C(t.getDate())}-${C(t.getMonth()+1)}-${t.getFullYear()}`}function se(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${C(t.getHours())}:${C(t.getMinutes())}`}function _e(n){const t=new Date(n);return Number.isNaN(t.getTime())?"":`${t.getFullYear()}-${C(t.getMonth()+1)}-${C(t.getDate())}`}function z(n){return n?`${F(n)} ${se(n)}`:""}function ja(){var ke;const{id:n}=Ge(),{profile:t}=We(),[a,f]=c.useState(null),[q,re]=c.useState([]),[$,ne]=c.useState([]),[H,Se]=c.useState(null),[B,oe]=c.useState("info"),[y,Ee]=c.useState("dimensionner"),[De,S]=c.useState(!0),[ce,le]=c.useState(!1),[P,T]=c.useState(null),[de,v]=c.useState(null),[E,Q]=c.useState(!1),[L,ze]=c.useState(""),[G,Fe]=c.useState(""),[p,W]=c.useState(null),[Be,Pe]=c.useState([]),[Y,he]=c.useState(!1);c.useEffect(()=>{ue()},[n,t==null?void 0:t.id]);async function ue(i=!1){i||S(!0),T(null),le(!1);const r=await k.from("activites_secours").select("id,numero,titre,type,dispositif,dispositifs,public_attendu,lieu,debut,fin,places,competences,armement,created_by,created_at").eq("id",n).maybeSingle();if(r.error){T(r.error.message||"Chargement impossible."),i||f(null),S(!1);return}if(!r.data){le(!0),f(null),S(!1);return}const o=await k.from("activites_secours_inscrits").select("id,user_id,created_at").eq("activite_id",n);if(o.error){T(o.error.message||"Chargement des inscriptions impossible."),f(r.data),re([]),ne([]),S(!1);return}const s=o.data||[],b=[...new Set(s.map(h=>h.user_id).filter(Boolean))];let m=[];if(b.length){const h=await k.from("profiles").select("id,prenom,nom,role,fiche").in("id",b);h.error?T(h.error.message||"Chargement du personnel impossible."):m=h.data||[]}let u=null;if(r.data.created_by){const h=await k.from("profiles").select("id,prenom,nom").eq("id",r.data.created_by).maybeSingle();h.error||(u=h.data)}f(r.data),W(ae(r.data.armement,r.data)),re(s),ne(m),Se(u);const l=await k.from("plaques_vehicules").select("plaque,libelle").eq("actif",!0).order("plaque");l.error||Pe(l.data||[]),S(!1)}const pe=c.useMemo(()=>qe(t),[t]),M=q.some(i=>i.user_id===(t==null?void 0:t.id)),j=Number(a==null?void 0:a.places)||0,x=q.length,w=a?Xe(a):"a_venir",Te=a?Ze(a):!1,Le=j>0&&x>=j,g=Array.isArray(a==null?void 0:a.competences)?a.competences:[],A=a?ea(a):null,Me=a&&_e(a.debut)===_e(a.fin||a.debut),me=c.useMemo(()=>aa(a),[a]),Ie=c.useMemo(()=>ia(a),[a]),_=c.useMemo(()=>ta(a,$),[a,$]),N=c.useMemo(()=>sa(a),[a]),fe=c.useMemo(()=>ra(a),[a]),xe=c.useMemo(()=>{const i=new Map($.map(o=>[o.id,o])),r=G.trim().toLowerCase();return q.map(o=>{const s=i.get(o.user_id),b=(s==null?void 0:s.fiche)||{},m=s?[...qe(s)]:[],u=m.filter(h=>h!=="medical"&&h!=="non_medical"&&h!=="volontaire_non_medical"),l=g.some(h=>m.includes(h)||Ce(h,s));return{id:o.user_id,inscription:o.created_at,prenom:(s==null?void 0:s.prenom)||"",nom:(s==null?void 0:s.nom)||"",photo:b.photo_url||"",role:(s==null?void 0:s.role)||"",quals:u,manque:g.length>0&&!l}}).filter(o=>L&&!o.quals.includes(L)?!1:r?`${o.prenom} ${o.nom}`.toLowerCase().includes(r):!0).sort((o,s)=>`${o.nom} ${o.prenom}`.localeCompare(`${s.nom} ${s.prenom}`,"fr"))},[q,$,G,L,g]);function D(i){Ee(i),i==="dimensionner"&&oe("info"),i==="armer"&&oe("personnel")}function ge(i){W(r=>({...r||ae(null,a),...i}))}function Re(i){W(r=>{const o=r||ae(null,a);return{...o,items:o.items.map(s=>s.id===i?{...s,ok:!s.ok}:s)}})}async function Ue(){if(!(a!=null&&a.id)||!p||Y)return;he(!0),v(null);const i={plaque:p.plaque||"",note:p.note||"",items:p.items||[]},{error:r}=await k.from("activites_secours").update({armement:i}).eq("id",a.id);r?v(r.message||"Armement non enregistré."):(f(o=>({...o,armement:i})),v(null)),he(!1)}function be(){var s,b,m;const i=((b=(s=ee.bases)==null?void 0:s[0])==null?void 0:b.adresse)||{},r=[[i.rue,i.numero].filter(Boolean).join(" "),[i.cp,i.localite].filter(Boolean).join(" ")].filter(Boolean).join(", "),o=q.map(u=>{const l=$.find(R=>R.id===u.user_id),h=(l==null?void 0:l.fiche)||{},ye=Array.isArray(h.qualifications)?h.qualifications:[],K={prenom:(l==null?void 0:l.prenom)||"",nom:(l==null?void 0:l.nom)||"",quals:ye,role:(l==null?void 0:l.role)||""},Qe=g.some(R=>ye.includes(R)||Ce(R,l));return{prenom:K.prenom,nom:K.nom,fonction:$e(K),couverture:g.length===0?"Aucune exigée":Qe?"Couvre au moins une compétence":"Aucune des compétences demandées"}}).sort((u,l)=>`${u.nom} ${u.prenom}`.localeCompare(`${l.nom} ${l.prenom}`,"fr"));return{organisation:je,adresse:r,logo:`${window.location.origin}${((m=ee.organisation)==null?void 0:m.logoUrl)||"/icons/ha-logo-512-v4.png"}`,imprimePar:`${((t==null?void 0:t.nom)||"").toUpperCase()} ${(t==null?void 0:t.prenom)||""}`.trim(),numero:a.numero,titre:a.titre,type:ie(a.type),dispositif:Ae(a.dispositif)||"",publicAttendu:a.public_attendu==null?"":String(a.public_attendu),debut:z(a.debut),fin:a.fin?z(a.fin):"",duree:A||"",lieu:a.lieu||"",places:j,competences:g.map(V),personnel:o,statut:O(w),inscrits:x}}function Oe(){la(be())||v("Le bilan n’a pas pu être téléchargé.")}function Ve(){da(be())||v("Le navigateur a bloqué la fenêtre du bilan. Utilisez Récupérer.")}async function ve(){if(!(t!=null&&t.id)||!a||E)return;if(Q(!0),v(null),!M&&ha(t,a)){v("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),Q(!1);return}const i=M?await k.from("activites_secours_inscrits").delete().eq("activite_id",a.id).eq("user_id",t.id):await k.from("activites_secours_inscrits").insert({activite_id:a.id,user_id:t.id});i.error?v(i.error.message||"Inscription impossible."):await ue(!0),Q(!1)}let I="S’inscrire",J=!1;M?I="Se désinscrire":Te?Le&&(I="Complet",J=!0):(I="Terminée",J=!0);const je=((ke=ee.organisation)==null?void 0:ke.nom)||"Heart’s Angels ASBL",He=a!=null&&a.lieu?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.lieu)}`:"";return De?e.jsx(X,{title:"Activité",children:e.jsx(Ye,{})}):a?e.jsxs(X,{children:[e.jsx("style",{children:ma}),P&&e.jsx(Z,{kind:"err",children:P}),de&&e.jsx(Z,{kind:"err",children:de}),e.jsxs("div",{className:"ha-afiche",children:[e.jsxs("header",{className:"ha-afiche-head",children:[e.jsxs("div",{className:"ha-afiche-top",children:[e.jsxs("div",{children:[e.jsx(Ne,{to:"/app/secours/activites",className:"ha-afiche-retour",children:"Activités"}),e.jsx("p",{className:"ha-afiche-type",children:ie(a.type)}),e.jsx("h1",{children:a.titre}),e.jsxs("p",{className:"ha-afiche-quand",children:[Me?F(a.debut):`du ${F(a.debut)} au ${F(a.fin||a.debut)}`," · ",se(a.debut),a.fin?` – ${se(a.fin)}`:"",A?` (${A})`:""]})]}),e.jsx("span",{className:"ha-afiche-etat is-"+w,children:O(w)})]}),e.jsxs("div",{className:"ha-afiche-chiffres",children:[e.jsx(te,{label:"Personnel inscrit",valeur:x}),e.jsx(te,{label:"Places",valeur:`${x} / ${j}`}),e.jsx(te,{label:"Durée",valeur:A||"—"})]})]}),e.jsxs("nav",{className:"ha-dps-temps","aria-label":"Déroulement du dispositif",children:[e.jsxs("button",{type:"button",className:y==="dimensionner"?"is-on":"",onClick:()=>D("dimensionner"),children:[e.jsx("span",{children:"1"})," Dimensionner"]}),e.jsxs("button",{type:"button",className:y==="armer"?"is-on":"",onClick:()=>D("armer"),children:[e.jsx("span",{children:"2"})," Armer"]}),e.jsxs("button",{type:"button",className:y==="rendre"?"is-on":"",onClick:()=>D("rendre"),children:[e.jsx("span",{children:"3"})," Rendre"]})]}),y!=="rendre"&&e.jsxs("nav",{className:"ha-afiche-onglets","aria-label":"Fiche de l’activité",children:[e.jsx("button",{type:"button",className:B==="info"?"is-on":"",onClick:()=>D("dimensionner"),children:"Information"}),e.jsxs("button",{type:"button",className:B==="personnel"?"is-on":"",onClick:()=>D("armer"),children:["Personnel",x?` ${x}`:""]})]}),y==="rendre"&&e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Bilan de fin"}),e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:8},children:w==="terminee"?"Le dispositif est terminé. Le bilan reprend l’équipe inscrite, la durée et le dimensionnement.":"Le dispositif n’est pas encore terminé. Le bilan reprend déjà ce qui est enregistré."}),e.jsxs("div",{className:"ha-afiche-kv",style:{marginTop:14},children:[e.jsx(d,{k:"Équipes",v:fe||"—"}),e.jsx(d,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)}),e.jsx(d,{k:"Personnel",v:`${x} / ${j}`}),e.jsx(d,{k:"Durée",v:A||"—"})]}),e.jsxs("div",{className:"ha-dps-actions",children:[e.jsx(U,{onClick:Oe,children:"Récupérer"}),e.jsx(U,{kind:"soft",onClick:Ve,children:"Imprimer"})]})]}),y!=="rendre"&&B==="info"&&e.jsxs("div",{className:"ha-afiche-grille",children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Détails de l’activité"}),e.jsx("p",{className:"ha-afiche-sec",children:"Identité"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"N°",v:a.numero??"—"}),e.jsx(d,{k:"Statut",v:O(w)}),e.jsx(d,{k:"Type",v:ie(a.type)}),e.jsx(d,{k:"Nom",v:a.titre}),e.jsx(d,{k:"Équipes",v:fe||"—"}),e.jsx(d,{k:"Effectif min.",v:(N==null?void 0:N.resume)||"—"}),e.jsx(d,{k:"Public attendu",v:a.public_attendu==null?"—":String(a.public_attendu)})]}),e.jsx("p",{className:"ha-afiche-vide",children:"Les équipes se choisissent à la création (plusieurs possibles). Pas de calcul depuis le public. « Minimum » = ordre des qualifications 1→7."}),N&&e.jsx("p",{className:"ha-afiche-vide",style:{color:_.ok?"var(--heading)":"#A32D2D",marginTop:8},children:_.ok?"Équipes inscrites : effectifs minimum atteints.":`Équipe incomplète — manque : ${we(_)}.`}),e.jsx("p",{className:"ha-afiche-sec",children:"Organisation"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Organisée par",v:je}),e.jsx(d,{k:"Créée par",v:H?`${H.prenom||""} ${H.nom||""}`.trim():"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Date et horaires"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Début",v:z(a.debut)}),e.jsx(d,{k:"Fin",v:a.fin?z(a.fin):"—"}),e.jsx(d,{k:"Durée",v:A||"—"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Suivi"}),e.jsx(d,{k:"Créée le",v:z(a.created_at)||"—"})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Inscription"}),e.jsx("p",{className:"ha-afiche-sec",children:"État"}),e.jsxs("div",{className:"ha-afiche-kv",children:[e.jsx(d,{k:"Statut",v:O(w)}),e.jsx(d,{k:"Places",v:j?`${Math.max(j-x,0)} libre${j-x>1?"s":""}`:"—"}),e.jsx(d,{k:"Qui peut s’inscrire",v:"Personnel de l’association"})]}),e.jsx("p",{className:"ha-afiche-sec",children:"Compétences demandées"}),g.length===0?e.jsx("p",{className:"ha-afiche-vide",children:"Aucune compétence exigée."}):e.jsx("div",{className:"ha-afiche-chips",children:g.map(i=>e.jsxs("span",{className:"ha-act-chip"+(pe.has(i)?" is-moi":" is-autre"),children:[pe.has(i)?"✓":"•"," ",V(i)]},i))}),e.jsx("div",{style:{marginTop:14},children:e.jsx(U,{onClick:ve,disabled:J||E,kind:M?"danger":"primary",children:E?"…":I})})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Lieu"}),a.lieu?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-lieu",children:a.lieu}),e.jsx("a",{className:"ha-afiche-maps",href:He,target:"_blank",rel:"noreferrer",children:"Ouvrir dans Google Maps"})]}):e.jsx("p",{className:"ha-afiche-vide",children:"Aucun lieu renseigné."})]})]}),y!=="rendre"&&B==="personnel"&&e.jsxs(e.Fragment,{children:[e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Effectif requis"}),me.length?e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:N==null?void 0:N.resume}),e.jsx("p",{style:{marginTop:10,fontWeight:650,color:_.ok?"var(--heading)":"#A32D2D"},children:_.ok?"Minimum atteint avec les inscrits.":`Manque : ${we(_)}`}),me.map(i=>{var s;const r=ua(i),o=Ie[i]||0;return!((s=r==null?void 0:r.alternatives)!=null&&s.length)||!o?null:e.jsxs("p",{className:"ha-afiche-vide",style:{marginTop:8},children:[e.jsxs("strong",{children:[o>1?`${o}× `:"",Ae(i,!0)]}),r.alternatives.length>1?" — compositions : ":" — ",r.alternatives.map((b,m)=>e.jsxs("span",{children:[m?" · ou · ":"",b.map(u=>`${u.n} ${na(u.role)}`).join(" + ")]},m)),o>1?" (chacun)":""]},i)})]}):e.jsx("p",{className:"ha-afiche-vide",style:{marginTop:6},children:"Aucune équipe choisie à la création."})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Armement"}),p&&e.jsxs(e.Fragment,{children:[e.jsxs("label",{style:{display:"block",marginTop:8,marginBottom:10},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Véhicule (plaque)"}),e.jsxs("select",{value:p.plaque||"",onChange:i=>ge({plaque:i.target.value}),style:{width:"100%",maxWidth:320,padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[e.jsx("option",{value:"",children:"—"}),Be.map(i=>e.jsxs("option",{value:i.plaque,children:[i.plaque,i.libelle?` — ${i.libelle}`:""]},i.plaque))]})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:8,marginBottom:12},children:p.items.map(i=>e.jsxs("label",{style:{display:"flex",alignItems:"center",gap:10,cursor:"pointer"},children:[e.jsx("input",{type:"checkbox",checked:!!i.ok,onChange:()=>Re(i.id)}),e.jsx("span",{children:i.label})]},i.id))}),e.jsxs("label",{style:{display:"block",marginBottom:12},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Note / dérogation"}),e.jsx("textarea",{value:p.note||"",onChange:i=>ge({note:i.target.value}),rows:2,style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit",resize:"vertical"}})]}),e.jsxs("p",{className:"ha-afiche-vide",style:{marginBottom:10},children:[oa(p)?"Checklist complète.":"Checklist incomplète — précisez une dérogation si besoin.",p.plaque?` Véhicule : ${p.plaque}.`:" Aucune plaque choisie."]}),e.jsx(U,{onClick:Ue,disabled:Y,children:Y?"…":"Enregistrer l’armement"})]})]}),e.jsxs("section",{className:"ha-afiche-carte",children:[e.jsx("h2",{children:"Personnel inscrit"}),e.jsxs("div",{className:"ha-afiche-outils",children:[e.jsxs("select",{"aria-label":"Compétence",value:L,onChange:i=>ze(i.target.value),children:[e.jsx("option",{value:"",children:"Toutes les compétences"}),ca.filter(i=>i.v!=="medical"&&i.v!=="non_medical").map(i=>e.jsx("option",{value:i.v,children:i.l},i.v))]}),e.jsx("input",{type:"search",placeholder:"Rechercher","aria-label":"Rechercher une personne",value:G,onChange:i=>Fe(i.target.value)})]}),xe.length===0?e.jsx("p",{className:"ha-afiche-vide",children:q.length===0?"Personne n’est inscrit pour le moment.":"Aucune personne ne correspond."}):e.jsx("div",{className:"ha-afiche-table-wrap",children:e.jsxs("table",{className:"ha-afiche-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Photo"}),e.jsx("th",{children:"Personnel"}),e.jsx("th",{children:"Fonction"}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:xe.map(i=>e.jsxs("tr",{className:i.manque?"is-manque":void 0,children:[e.jsx("td",{children:e.jsx(pa,{url:i.photo,prenom:i.prenom,nom:i.nom})}),e.jsxs("td",{children:[e.jsx("strong",{children:`${i.prenom} ${i.nom}`.trim()||"Compte retiré"}),e.jsx("span",{className:"ha-afiche-sous",children:F(i.inscription)})]}),e.jsx("td",{children:$e(i)}),e.jsx("td",{children:i.quals.length===0?e.jsx("span",{className:"ha-afiche-vide",children:"—"}):i.quals.map(r=>e.jsx("span",{className:"ha-act-chip"+(g.includes(r)?" is-moi":""),children:V(r)},r))}),e.jsx("td",{children:i.id===(t==null?void 0:t.id)&&e.jsx("button",{type:"button",className:"ha-afiche-moi",onClick:ve,disabled:E,children:E?"…":"Se désinscrire"})})]},i.id))})]})})]})]})]})]}):e.jsxs(X,{title:"Activité",children:[P&&e.jsx(Z,{kind:"err",children:P}),e.jsx(Je,{title:ce?"Activité introuvable":"Activité indisponible",hint:ce?"Elle a été retirée, ou le lien ne correspond à rien.":"Le chargement a échoué.",action:e.jsx(Ne,{to:"/app/secours/activites",children:"Retour aux activités"})})]})}function Ce(n,t){var a,f;return t?n==="medical"?((a=t.fiche)==null?void 0:a.type_benevole)==="medical"||t.role==="volontaire_medical":n==="non_medical"?((f=t.fiche)==null?void 0:f.type_benevole)==="non_medical"||t.role==="volontaire_non_medical":!1:!1}function $e(n){const t=n.quals.find(a=>a!=="autre")||n.quals[0];return t?V(t):n.role?Ke(n.role):"—"}function d({k:n,v:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:n}),e.jsx("div",{className:"ha-afiche-v",children:t||"—"})]})}function te({label:n,valeur:t}){return e.jsxs("div",{children:[e.jsx("div",{className:"ha-afiche-k",children:n}),e.jsx("div",{className:"ha-afiche-nb",children:t})]})}function pa({url:n,prenom:t,nom:a}){const f=`${(t||"").charAt(0)}${(a||"").charAt(0)}`.toUpperCase()||"?";return e.jsx("span",{className:"ha-afiche-photo",children:n?e.jsx("img",{src:n,alt:""}):e.jsx("span",{children:f})})}const ma=`
.ha-afiche { display: flex; flex-direction: column; gap: 12px; }
.ha-afiche-head, .ha-afiche-carte {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 14px 16px 12px;
}
.ha-afiche-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.ha-afiche-retour { font-size: 12.5px; font-weight: 700; color: var(--accent); text-decoration: none; }
.ha-afiche-type { margin: 6px 0 0; font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche h1 { margin: 2px 0 0; font-size: 1.35rem; color: var(--heading); line-height: 1.2; }
.ha-afiche-quand { margin: 4px 0 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-etat {
  flex: none;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
}
.ha-afiche-etat.is-a_venir { background: #E6F1FB; color: #185FA5; }
.ha-afiche-etat.is-en_cours { background: #E7F6EE; color: #1E7A45; }
.ha-afiche-etat.is-terminee { background: var(--bg-alt); color: var(--text-muted); }
.ha-afiche-chiffres {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 12px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.ha-afiche-nb { font-size: 1.35rem; font-weight: 700; color: var(--heading); font-variant-numeric: tabular-nums; }
.ha-dps-temps { display: flex; gap: 8px; flex-wrap: wrap; }
.ha-dps-temps button {
  display: inline-flex; align-items: center; gap: 8px;
  border: 1px solid var(--border); background: var(--card); color: var(--text);
  border-radius: 999px; padding: 7px 12px; font: inherit; font-weight: 700; font-size: 13.5px; cursor: pointer;
}
.ha-dps-temps button span {
  width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center;
  background: var(--bg-alt); color: var(--heading); font-size: 12px;
}
.ha-dps-temps button.is-on { border-color: var(--accent); color: var(--heading); }
.ha-dps-temps button.is-on span { background: var(--accent); color: #fff; }
.ha-dps-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.ha-afiche-onglets { display: flex; gap: 6px; border-bottom: 1px solid var(--border); }
.ha-afiche-onglets button {
  border: none;
  background: transparent;
  color: var(--text-muted);
  font: inherit;
  font-weight: 700;
  font-size: 14px;
  padding: 8px 12px 10px;
  border-bottom: 2px solid transparent;
  cursor: pointer;
}
.ha-afiche-onglets button.is-on { color: var(--accent-blue); border-bottom-color: var(--accent); }
.ha-afiche-grille {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 1fr) minmax(220px, .8fr);
  gap: 12px;
  align-items: start;
}
.ha-afiche-carte h2 { margin: 0; font-size: 1rem; color: var(--heading); }
.ha-afiche-sec {
  margin: 14px 0 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ha-afiche-kv { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px; }
.ha-afiche-k { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .04em; }
.ha-afiche-v { margin-top: 2px; font-size: 14px; font-weight: 650; color: var(--text); }
.ha-afiche-vide { margin: 0; color: var(--text-muted); font-size: 13px; }
.ha-afiche-lieu { margin: 8px 0; font-weight: 700; color: var(--heading); }
.ha-afiche-maps { color: var(--accent); font-weight: 700; font-size: 13px; }
.ha-afiche-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.ha-act-chip {
  display: inline-flex; align-items: center; gap: 4px;
  margin: 2px 4px 2px 0; padding: 2px 8px; border-radius: 999px;
  font-size: 11.5px; font-weight: 700; border: 1px solid var(--border);
  background: var(--bg-alt); color: var(--text-2); white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-afiche-outils { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.ha-afiche-outils select, .ha-afiche-outils input {
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font: inherit; font-size: 13px; padding: 7px 10px;
}
.ha-afiche-outils input { margin-left: auto; min-width: min(240px, 70vw); }
.ha-afiche-table-wrap { overflow: auto; }
.ha-afiche-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 640px; }
.ha-afiche-table th {
  text-align: left; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  color: var(--text-muted); font-weight: 700; padding: 8px 10px; border-bottom: 1px solid var(--border);
}
.ha-afiche-table td { padding: 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
.ha-afiche-table tr.is-manque td { background: #fff6f6; }
.ha-afiche-table td strong { display: block; color: var(--accent-blue); }
.ha-afiche-sous { display: block; color: var(--text-muted); font-size: 12px; font-weight: 500; }
.ha-afiche-photo {
  width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
  display: grid; place-items: center; background: var(--accent); color: #fff; font-weight: 700; font-size: 12px;
}
.ha-afiche-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ha-afiche-moi {
  border: 1px solid var(--border); background: var(--card); color: #A32D2D;
  border-radius: 8px; padding: 5px 8px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
}
[data-theme="dark"] .ha-afiche-etat.is-a_venir { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-afiche-etat.is-en_cours { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-afiche-table tr.is-manque td { background: rgba(163,45,45,.16); }
[data-theme="dark"] .ha-afiche-onglets button.is-on,
[data-theme="dark"] .ha-afiche-table td strong { color: var(--heading); }
[data-theme="dark"] .ha-afiche-moi { color: #F0A0A0; }
@media (max-width: 980px) {
  .ha-afiche-grille { grid-template-columns: 1fr; }
  .ha-afiche-chiffres { grid-template-columns: 1fr; }
  .ha-afiche-outils input { margin-left: 0; width: 100%; }
}
`;export{ja as default};
