const d="/papier/entete.png",s="/papier/pied.png";function p(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}function m(){return`
  @page {
    size: A4 portrait;
    margin: 0 0 20mm 0;
    @bottom-center {
      content: "Page " counter(page) " sur " counter(pages);
      font-family: "Arial Narrow", "Franklin Gothic Medium", Calibri, Arial, sans-serif;
      font-size: 10pt;
      color: #111;
    }
  }
  html, body { margin: 0; padding: 0; background: #fff; }
  table.ha-papier { width: 210mm; border-collapse: collapse; table-layout: fixed; }
  table.ha-papier > thead { display: table-header-group; }
  table.ha-papier > tfoot { display: table-footer-group; }
  table.ha-papier > thead > tr > td,
  table.ha-papier > tfoot > tr > td,
  table.ha-papier > tbody > tr > td { border: 0; padding: 0; vertical-align: top; }
  img.ha-papier-entete {
    width: 210mm; height: ${40.4}mm;
    object-fit: fill; display: block; border: 0;
  }
  .ha-papier-pied-espace { height: ${7.3+4}mm; }
  .ha-papier-pied {
    position: fixed; left: 0; bottom: 9mm; width: 210mm;
    height: ${7.3}mm; z-index: 10000; pointer-events: none;
  }
  .ha-papier-pied img {
    width: 210mm; height: ${7.3}mm;
    object-fit: fill; display: block; border: 0;
  }
  .ha-papier-corps { padding: 2mm 16mm 2mm; }
  `}function h(e,{entete:t,pied:i}){return'<div class="ha-papier-pied" aria-hidden="true"><img src="'+p(i)+'" alt=""></div><table class="ha-papier"><thead><tr><td><img class="ha-papier-entete" src="'+p(t)+'" alt=""></td></tr></thead><tfoot><tr><td><div class="ha-papier-pied-espace"></div></td></tr></tfoot><tbody><tr><td class="ha-papier-corps">'+e+"</td></tr></tbody></table>"}let r=null;async function c(e){const t=await fetch(e);if(!t.ok)throw new Error("Papier officiel introuvable ("+e+").");const i=await t.blob();return await new Promise((a,o)=>{const n=new FileReader;n.onload=()=>a(n.result),n.onerror=o,n.readAsDataURL(i)})}async function u(){if(r)return r;const[e,t]=await Promise.all([c(d),c(s)]);return r={entete:e,pied:t},r}function f(e,t,i){return'<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+p(e)+"</title><style>"+i+"</style></head><body>"+t+"</body></html>"}async function w(e,t,i,a){const o=await u();return f(e,h(t,o),m()+(i||""))}function b(){var e,t,i;return!!((e=window.navigator)!=null&&e.standalone||(t=window.matchMedia)!=null&&t.call(window,"(display-mode: standalone)").matches||(i=window.matchMedia)!=null&&i.call(window,"(pointer: coarse)").matches||window.innerWidth<720)}function l(e,t){const i=new Blob([t],{type:"text/html;charset=utf-8"}),a=document.createElement("a");a.href=URL.createObjectURL(i),a.download=e,a.rel="noopener",document.body.appendChild(a),a.click(),a.remove(),setTimeout(()=>URL.revokeObjectURL(a.href),4e3)}function g(e,t){if(b()){typeof t=="function"?t(e):l("document-a4.html",e);return}let a=null;try{a=window.open("","_blank")}catch{a=null}if(a&&a!==window){a.document.open(),a.document.write(e),a.document.close();const o=()=>{try{a.focus(),a.print()}catch{}};a.document.readyState==="complete"?setTimeout(o,350):a.addEventListener("load",()=>setTimeout(o,350));return}typeof t=="function"?t(e):l("document-a4.html",e)}function y(e){const t=e==null?void 0:e.contentWindow;if(t)try{t.focus(),t.print()}catch{}}export{g as a,p as e,w as h,y as i,l as t};
