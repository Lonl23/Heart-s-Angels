import{r as c,j as e,L as ye}from"./vendor-react-y2xUrN8v.js";import{u as ke,s as y,r as we,k as X,o as Ce,q as C,e as _,n as Ae,E as Z}from"./index-DOUqbfDJ.js";import{p as Ne,c as Se,e as R,r as Ee,d as De,C as ee,T as V,D as W,a as te,l as Fe,b as $e,f as qe,s as ze,g as O,h as _e,i as Ie}from"./activitesSecours-DoZYrEpN.js";import"./vendor-CRxSQiq7.js";import"./vendor-supabase-DBBGb5oX.js";const Le={id:null,titre:"",type:"activite",lieu:"",debut:"",fin:"",places:"1",publicAttendu:"",dispositif:"",competences:[]};function h(r){return String(r).padStart(2,"0")}function J(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${i.getFullYear()}-${h(i.getMonth()+1)}-${h(i.getDate())}`}function re(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${h(i.getDate())}-${h(i.getMonth()+1)}-${i.getFullYear()}`}function Y(r){const i=new Date(r);return Number.isNaN(i.getTime())?"":`${h(i.getHours())}:${h(i.getMinutes())}`}function Te(r){const i=re(r.debut),l=Y(r.debut);if(!r.fin)return{date:i,heures:l};const m=J(r.debut)===J(r.fin)?Y(r.fin):`${re(r.fin)} ${Y(r.fin)}`;return{date:i,heures:l&&m?`${l}–${m}`:l}}function ie(r){if(!r)return"";const i=new Date(r);return Number.isNaN(i.getTime())?"":`${i.getFullYear()}-${h(i.getMonth()+1)}-${h(i.getDate())}T${h(i.getHours())}:${h(i.getMinutes())}`}function ae(r){if(!r)return null;const i=new Date(r);return Number.isNaN(i.getTime())?null:i.toISOString()}function se(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"8",r:"3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M5.5 19.2c1.2-3 3.4-4.4 6.5-4.4s5.3 1.4 6.5 4.4",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Be(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"7.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M8.2 12.2l2.4 2.4 5.2-5.3",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Me(){return e.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16","aria-hidden":!0,children:[e.jsx("rect",{x:"4",y:"5.5",width:"16",height:"14",rx:"2",fill:"none",stroke:"currentColor",strokeWidth:"1.8"}),e.jsx("path",{d:"M4 10h16M8 3.8v3.2M16 3.8v3.2",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round"})]})}function Je(){const{profile:r}=ke(),i=Ne(r),[l,b]=c.useState([]),[m,S]=c.useState([]),[k,Q]=c.useState(!0),[U,I]=c.useState(null),[G,u]=c.useState(null),[f,ne]=c.useState(null),[E,oe]=c.useState(""),[D,ce]=c.useState(""),[F,le]=c.useState(""),[L,de]=c.useState(""),[T,ue]=c.useState("asc"),[B,M]=c.useState(null),[s,g]=c.useState(null),[A,$]=c.useState(!1);c.useEffect(()=>{q()},[r==null?void 0:r.id]);async function q(t=!1){var d,o;t||Q(!0),I(null);const[a,n]=await Promise.all([y.from("activites_secours").select("id,numero,titre,type,dispositif,public_attendu,lieu,debut,fin,places,competences,created_by").order("debut",{ascending:!0}),y.from("activites_secours_inscrits").select("id,activite_id,user_id")]);a.error||n.error?(I(((d=a.error)==null?void 0:d.message)||((o=n.error)==null?void 0:o.message)||"Chargement impossible."),b([]),S([])):(b(Array.isArray(a.data)?a.data:[]),S(Array.isArray(n.data)?n.data:[])),Q(!1)}const p=c.useMemo(()=>Se(l,m,r),[l,m,r]),K=c.useMemo(()=>{const t=L.trim().toLowerCase(),a=l.filter(n=>{const d=p.nombres.get(n.id)||0;if(f==="possible"&&!(R(n)&&d<Number(n.places)&&!p.miennes.has(n.id))||f==="competence"&&!(R(n)&&Ee(n,p.mes))||f==="bientot"&&!De(n.debut)||E&&!(n.competences||[]).includes(E))return!1;const o=J(n.debut);return!(D&&o&&o<D||F&&o&&o>F||t&&!`${n.numero||""} ${n.titre||""} ${n.lieu||""}`.toLowerCase().includes(t))});return a.sort((n,d)=>{const o=String(n.debut).localeCompare(String(d.debut));return T==="asc"?o:-o}),a},[l,p,f,E,D,F,L,T]);function P(t){ne(a=>a===t?null:t)}async function pe(t){if(!(r!=null&&r.id)||B)return;M(t.id),u(null);const a=p.miennes.has(t.id);if(!a&&ze(r,t)){u("Votre sélection médicale est échue. L’inscription n’est pas possible : cette activité demande un chauffeur."),M(null);return}const n=a?await y.from("activites_secours_inscrits").delete().eq("activite_id",t.id).eq("user_id",r.id):await y.from("activites_secours_inscrits").insert({activite_id:t.id,user_id:r.id});n.error?u(n.error.message||"Inscription impossible."):await q(!0),M(null)}function he(){I(null),g({...Le,competences:[]})}function me(t){g({id:t.id,titre:t.titre||"",type:V.some(a=>a.v===t.type)?t.type:"activite",lieu:t.lieu||"",debut:ie(t.debut),fin:ie(t.fin),places:String(t.places??1),publicAttendu:t.public_attendu==null?"":String(t.public_attendu),dispositif:W.some(a=>a.v===t.dispositif)?t.dispositif:"",competences:O(t.competences)})}function x(t){g(a=>({...a,...t}))}function xe(t){const a=_e(t);if(!a){x({dispositif:t});return}x({dispositif:t,places:a.places,competences:O(a.competences)})}function be(t){g(a=>{const n=a.competences.includes(t)?a.competences.filter(d=>d!==t):[...a.competences,t];return{...a,competences:n}})}async function fe(t){if(t.preventDefault(),!s||A)return;const a=s.titre.trim(),n=ae(s.debut),d=ae(s.fin),o=Number(s.places);if(!a){u("Indiquez le titre.");return}if(!n){u("Indiquez le début.");return}if(s.fin&&!d){u("La fin est illisible.");return}if(d&&d<n){u("La fin est avant le début.");return}if(!Number.isInteger(o)||o<1||o>500){u("Le nombre de places doit être entre 1 et 500.");return}const N=Ie(s.publicAttendu);if(N===void 0){u("Le public attendu doit être un nombre entre 0 et 500 000, ou rester vide.");return}if(s.dispositif&&!W.some(j=>j.v===s.dispositif)){u("Le type de dispositif est inconnu.");return}$(!0),u(null);const w={titre:a,type:V.some(j=>j.v===s.type)?s.type:"activite",dispositif:s.dispositif||null,public_attendu:N,lieu:s.lieu.trim()||null,debut:n,fin:d,places:o,competences:O(s.competences)},v=s.id?await y.from("activites_secours").update(w).eq("id",s.id):await y.from("activites_secours").insert({...w,created_by:(r==null?void 0:r.id)||null});v.error?u(v.error.message||"Enregistrement impossible."):(g(null),await q(!0)),$(!1)}async function ge(t){if(!t||A||!window.confirm("Retirer cette activité ? Les inscriptions partent avec elle."))return;$(!0),u(null);const a=await y.from("activites_secours").delete().eq("id",t);a.error?u(a.error.message||"Suppression impossible."):(g(null),await q(!0)),$(!1)}const ve=!k&&l.length===0,je=!k&&l.length>0&&K.length===0;return e.jsxs(we,{title:"Activités",subtitle:"Département secours. Une activité se dimensionne, s’arme, puis se rend en bilan.",action:i?e.jsx(_,{onClick:he,children:"+ Activité"}):null,children:[e.jsx("style",{children:Re}),U&&e.jsx(X,{kind:"err",children:U}),G&&e.jsx(X,{kind:"err",children:G}),e.jsxs("div",{className:"ha-act-cartes",children:[e.jsx(H,{tone:"possible",on:f==="possible",n:k?"…":p.possible,label:"Inscription possible",icone:e.jsx(se,{}),onClick:()=>P("possible")}),e.jsx(H,{tone:"competence",on:f==="competence",n:k?"…":p.competence,label:"Requiert ma compétence",icone:e.jsx(Be,{}),onClick:()=>P("competence")}),e.jsx(H,{tone:"bientot",on:f==="bientot",n:k?"…":p.bientot,label:"Sur les 30 prochains jours",icone:e.jsx(Me,{}),onClick:()=>P("bientot")})]}),e.jsxs("div",{className:"ha-act-filtres",children:[e.jsxs("select",{"aria-label":"Compétence",value:E,onChange:t=>oe(t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les activités"}),ee.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]}),e.jsxs("label",{className:"ha-act-dates",children:[e.jsx("span",{className:"ha-sr",children:"Du"}),e.jsx("input",{type:"date","aria-label":"Date de début, à partir du",value:D,onChange:t=>ce(t.target.value)}),e.jsx("span",{children:"au"}),e.jsx("span",{className:"ha-sr",children:"Au"}),e.jsx("input",{type:"date","aria-label":"Date de début, jusqu’au",value:F,onChange:t=>le(t.target.value)})]}),e.jsxs("label",{className:"ha-act-recherche",children:[e.jsx("span",{className:"ha-sr",children:"Rechercher"}),e.jsx("input",{type:"search",placeholder:"Rechercher",value:L,onChange:t=>de(t.target.value)})]})]}),s&&e.jsx(Ce,{style:{marginBottom:14},children:e.jsxs("form",{onSubmit:fe,children:[e.jsxs("div",{className:"ha-act-form",children:[e.jsx(C,{label:"Titre",value:s.titre,set:t=>x({titre:t}),required:!0}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Type"}),e.jsx("select",{value:s.type,onChange:t=>x({type:t.target.value}),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:V.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))})]}),e.jsx(C,{label:"Lieu",value:s.lieu,set:t=>x({lieu:t})}),e.jsx(C,{label:"Début",type:"datetime-local",value:s.debut,set:t=>x({debut:t}),required:!0}),e.jsx(C,{label:"Fin",type:"datetime-local",value:s.fin,set:t=>x({fin:t})}),e.jsx(C,{label:"Places",type:"number",value:s.places,set:t=>x({places:t}),required:!0}),e.jsx(C,{label:"Public attendu",type:"number",value:s.publicAttendu,set:t=>x({publicAttendu:t})}),e.jsxs("label",{style:{marginBottom:10,display:"block"},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)",display:"block",marginBottom:5},children:"Équipe / dispositif"}),e.jsxs("select",{value:s.dispositif,onChange:t=>xe(t.target.value),style:{width:"100%",padding:"9px 12px",border:"1px solid var(--border)",borderRadius:9,fontSize:13.5,background:"var(--surface)",color:"var(--text)",fontFamily:"inherit"},children:[e.jsx("option",{value:"",children:"—"}),W.map(t=>e.jsx("option",{value:t.v,children:t.l},t.v))]})]})]}),s.dispositif&&te(s.dispositif)&&e.jsxs("p",{className:"ha-act-note",style:{color:"var(--heading)"},children:["Effectif minimum : ",te(s.dispositif).resume,". Places et compétences sont préremplies — vous pouvez encore les ajuster."]}),e.jsx("p",{className:"ha-act-note",children:"Le type d’équipe se choisit. Il n’est pas calculé à partir du public. Ces matrices concernent uniquement le département secours (pas les souhaits)."}),e.jsxs("div",{style:{marginBottom:8},children:[e.jsx("span",{style:{fontSize:12.5,color:"var(--text-muted)"},children:"Compétences requises"}),e.jsx("div",{className:"ha-act-choix",role:"group","aria-label":"Compétences requises",children:ee.map(t=>e.jsx("button",{type:"button",className:"ha-act-choix-btn"+(s.competences.includes(t.v)?" is-on":""),"aria-pressed":s.competences.includes(t.v),onClick:()=>be(t.v),children:t.l},t.v))}),e.jsx("p",{className:"ha-act-note",children:"La carte « Requiert ma compétence » compare ces valeurs à la fiche : qualifications, SIAMU, et type médical ou non médical."})]}),e.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap"},children:[e.jsx(_,{type:"submit",disabled:A,children:s.id?"Enregistrer":"Créer l’activité"}),e.jsx(_,{kind:"soft",onClick:()=>g(null),disabled:A,children:"Annuler"}),s.id&&e.jsx(_,{kind:"danger",onClick:()=>ge(s.id),disabled:A,children:"Retirer"})]})]})}),k?e.jsx(Ae,{}):ve?e.jsx(Z,{title:"Aucune activité pour le moment",hint:i?"Ajoutez la première activité du département secours.":"Quand une activité sera publiée, elle apparaîtra ici."}):je?e.jsx(Z,{title:"Aucune activité ne correspond",hint:"Élargissez les filtres ou la recherche."}):e.jsx("div",{className:"ha-act-table-wrap",children:e.jsxs("table",{className:"ha-act-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Activité"}),e.jsx("th",{children:"Lieu"}),e.jsx("th",{children:e.jsxs("button",{type:"button",className:"ha-act-tri",onClick:()=>ue(t=>t==="asc"?"desc":"asc"),children:["Date ",e.jsx("span",{"aria-hidden":!0,children:T==="asc"?"↑":"↓"})]})}),e.jsx("th",{children:"Compétence"}),e.jsx("th",{children:"Inscrit"}),e.jsx("th",{children:"Actions"})]})}),e.jsx("tbody",{children:K.map(t=>{const a=p.nombres.get(t.id)||0,n=Number(t.places)||0,d=p.miennes.has(t.id),o=R(t),N=a>=n,w=Te(t);let v="S’inscrire",j=!1;return d?v="Se désinscrire":o?N&&(v="Complet",j=!0):(v="Terminée",j=!0),e.jsxs("tr",{children:[e.jsx("td",{className:"ha-act-id",children:t.numero}),e.jsxs("td",{children:[e.jsx(ye,{to:`/app/secours/activites/${t.id}`,className:"ha-act-titre",children:t.titre}),e.jsxs("div",{className:"ha-act-type",children:[Fe(t.type),t.dispositif?` · ${$e(t.dispositif,!0)}`:""]})]}),e.jsx("td",{className:"ha-act-lieu",children:t.lieu||"—"}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-quand",children:[e.jsx("strong",{children:w.date}),w.heures&&e.jsx("span",{children:w.heures})]})}),e.jsx("td",{children:(t.competences||[]).length===0?e.jsx("span",{className:"ha-act-aucune",children:"—"}):(t.competences||[]).map(z=>e.jsxs("span",{className:"ha-act-chip"+(p.mes.has(z)?" is-moi":" is-autre"),children:[p.mes.has(z)?"✓":"•"," ",qe(z)]},z))}),e.jsx("td",{children:e.jsx(Pe,{inscrits:a,places:n})}),e.jsx("td",{children:e.jsxs("div",{className:"ha-act-actions",children:[e.jsxs("button",{type:"button",className:"ha-act-go"+(d?" is-off":""),disabled:j||B===t.id,onClick:()=>pe(t),children:[e.jsx(se,{}),B===t.id?"…":v]}),i&&e.jsx("button",{type:"button",className:"ha-act-mod",onClick:()=>me(t),children:"Modifier"})]})})]},t.id)})})]})})]})}function H({tone:r,on:i,n:l,label:b,icone:m,onClick:S}){return e.jsxs("button",{type:"button",className:"ha-act-carte is-"+r+(i?" is-on":""),"aria-pressed":i,onClick:S,children:[e.jsx("span",{className:"ha-act-carte-n",children:l}),e.jsx("span",{className:"ha-act-carte-l",children:b}),e.jsx("span",{className:"ha-act-carte-ico is-"+r,children:m})]})}function Pe({inscrits:r,places:i}){const l=i>0?Math.min(1,r/i):0,b=i>0&&r>=i,m=r===0?0:Math.max(l*100,18);return e.jsxs("div",{className:"ha-act-barre",role:"img","aria-label":`${r} inscrit${r>1?"s":""} sur ${i} place${i>1?"s":""}`,children:[e.jsx("span",{style:{width:`${m}%`,background:b?"#1F9D55":"linear-gradient(90deg, #185FA5, #7A5BD6)"}}),e.jsxs("em",{style:{color:l>=.55||b?"#fff":"var(--text)"},children:[r,"/",i]})]})}const Re=`
.ha-act-cartes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}
.ha-act-carte {
  position: relative;
  text-align: center;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 18px 46px 14px;
  box-shadow: 0 1px 2px rgba(20, 18, 16, .04);
  color: var(--text);
  overflow: hidden;
}
.ha-act-carte::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 0;
  height: 3px;
}
.ha-act-carte.is-possible::before { background: #185FA5; }
.ha-act-carte.is-competence::before { background: #2E9B57; }
.ha-act-carte.is-bientot::before { background: #D4534A; }
.ha-act-carte.is-on {
  border-color: #185FA5;
  background: var(--blue-light);
  box-shadow: 0 0 0 1px #185FA5;
}
.ha-act-carte-n {
  display: block;
  font-size: 1.85rem;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.1;
  color: var(--text);
}
.ha-act-carte-l {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.3;
}
.ha-act-carte-ico {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  display: grid;
  place-items: center;
}
.ha-act-carte-ico.is-possible { background: #E6F1FB; color: #185FA5; }
.ha-act-carte-ico.is-competence { background: #E5F6EC; color: #1E7A45; }
.ha-act-carte-ico.is-bientot { background: #FDECEA; color: #C8435A; }
.ha-act-filtres {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  margin-bottom: 14px;
}
.ha-act-filtres select,
.ha-act-filtres input,
.ha-act-dates {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font: inherit;
  font-size: 13px;
}
.ha-act-filtres select,
.ha-act-filtres input { padding: 7px 10px; }
.ha-act-dates {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
}
.ha-act-dates input {
  border: none;
  background: transparent;
  padding: 5px 2px;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ha-act-dates span { color: var(--text-muted); font-size: 12.5px; }
.ha-act-recherche { margin-left: auto; }
.ha-act-recherche input { min-width: min(240px, 70vw); }
.ha-act-table-wrap {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: auto;
}
.ha-act-table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 860px; }
.ha-act-table th {
  text-align: left;
  font-size: 11px;
  letter-spacing: .04em;
  text-transform: uppercase;
  color: var(--text-muted);
  font-weight: 700;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  white-space: nowrap;
}
.ha-act-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
.ha-act-table tr:last-child td { border-bottom: none; }
.ha-act-id { font-variant-numeric: tabular-nums; font-weight: 700; color: var(--text-2); width: 3.2rem; }
.ha-act-titre { color: var(--accent-blue); font-weight: 700; text-decoration: none; }
.ha-act-titre:hover { text-decoration: underline; }
.ha-act-type { margin-top: 2px; font-size: 12px; color: var(--text-muted); font-weight: 600; }
.ha-act-lieu { color: var(--text-2); max-width: 240px; }
.ha-act-quand { display: flex; flex-direction: column; gap: 2px; font-variant-numeric: tabular-nums; }
.ha-act-quand strong { font-weight: 700; color: var(--text); }
.ha-act-quand span { color: var(--text-muted); font-size: 12px; }
.ha-act-tri {
  border: none; background: transparent; padding: 0;
  font: inherit; font-size: 11px; letter-spacing: .04em; text-transform: uppercase;
  font-weight: 700; color: var(--accent-blue); cursor: pointer;
}
.ha-act-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 2px 4px 2px 0;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 700;
  border: 1px solid transparent;
  white-space: nowrap;
}
.ha-act-chip.is-moi { color: #1E7A45; background: #E7F6EE; border-color: #B7E4C7; }
.ha-act-chip.is-autre { color: #C26A12; background: #FFF4E8; border-color: #F3D2A8; }
.ha-act-aucune { color: var(--text-faint); }
.ha-act-barre {
  position: relative;
  height: 22px;
  min-width: 96px;
  border-radius: 999px;
  background: var(--bg-alt);
  overflow: hidden;
}
.ha-act-barre > span { display: block; height: 100%; border-radius: inherit; }
.ha-act-barre em {
  position: absolute; inset: 0;
  display: grid; place-items: center;
  font-style: normal; font-size: 12px; font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.ha-act-actions { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.ha-act-go, .ha-act-mod {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 8px; font: inherit; font-size: 12.5px; font-weight: 700;
  cursor: pointer;
}
.ha-act-go {
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text);
  padding: 6px 10px;
}
.ha-act-go:hover:not(:disabled) { border-color: var(--accent); color: var(--heading); }
.ha-act-go.is-off { color: #A32D2D; }
.ha-act-go:disabled { opacity: .55; cursor: not-allowed; }
.ha-act-mod {
  border: none; background: transparent; color: var(--accent); padding: 0 2px; font-weight: 600;
}
.ha-act-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0 12px;
}
.ha-act-choix { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.ha-act-choix-btn {
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-2);
  border-radius: 999px;
  padding: 4px 10px;
  font: inherit;
  font-size: 12.5px;
  font-weight: 600;
}
.ha-act-choix-btn.is-on { background: var(--accent); border-color: var(--accent); color: #fff; }
.ha-act-note { margin: 8px 0 12px; font-size: 12px; color: var(--text-muted); }
.ha-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0;
}
[data-theme="dark"] .ha-act-titre,
[data-theme="dark"] .ha-act-tri { color: var(--heading); }
[data-theme="dark"] .ha-act-carte-ico.is-possible { background: rgba(24,95,165,.28); color: #8EBFEE; }
[data-theme="dark"] .ha-act-carte-ico.is-competence { background: rgba(46,155,87,.22); color: #8ED7A8; }
[data-theme="dark"] .ha-act-carte-ico.is-bientot { background: rgba(200,67,90,.22); color: #F0A0A8; }
[data-theme="dark"] .ha-act-chip.is-moi { color: #B7E08A; background: rgba(59,109,17,.22); border-color: rgba(59,109,17,.45); }
[data-theme="dark"] .ha-act-chip.is-autre { color: #F0C36A; background: rgba(186,117,23,.2); border-color: rgba(186,117,23,.45); }
[data-theme="dark"] .ha-act-go.is-off { color: #F0A0A0; }
@media (max-width: 800px) {
  .ha-act-cartes { grid-template-columns: 1fr; }
  .ha-act-recherche { margin-left: 0; width: 100%; }
  .ha-act-recherche input { width: 100%; }
}
`;export{Je as default};
