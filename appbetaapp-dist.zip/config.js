/* ════════════════════════════════════════════════════════════════════════════
 *  ⚙️  CONFIGURATION — LE SEUL FICHIER À MODIFIER (éditable sans recompiler)
 *  Ce fichier est déployé À CÔTÉ de l'application compilée. Renseignez ici les
 *  informations propres à l'organisation et à son serveur, puis rechargez la page.
 *  Version bêta cPanel : https://appbetaapp.heartsangels.be
 * ════════════════════════════════════════════════════════════════════════════ */
window.__APP_CONFIG__ = {
  organisation: {
    nom:     "Heart's Angels ASBL",
    forme:   "ASBL",
    pays:    "BE",
    langue:  "fr",
    devise:  "EUR",
    tauxKm:  0.4326,
    accent:  "#1BB0CE",
    logoUrl: "/icons/ha-logo-512-v4.png",
  },
  domaine: "https://appbetaapp.heartsangels.be",
  vapidPublicKey: "BItos40GJksoCJRK7W0cWt5VgloRmYkwwf9Q9rZ3hkCXR9xEruCiZhN-yboXw5ijt54bvIMo83wle2QoM5VTz_U",
  supabase: {
    url:     "https://vppmvjqbzdeftrhdoert.supabase.co",
    anonKey: "sb_publishable_A_Bu4P4-Fn-sy3xF58U4Cg_kJ_aLSIH",
  },
  bases: [
    {
      nom: "Solumob Jemeppe-sur-Meuse",
      adresse: { rue: "Rue sous les vignes", numero: "8", cp: "4101", localite: "Seraing", pays: "Belgique" },
    },
  ],
}
