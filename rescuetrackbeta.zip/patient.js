import {
  enregistrerPatient,
  lirePatient,
  lirePreventif
} from "./rt-KFLEYYHZ.js";
import {
  requireAuth,
  rt
} from "./rt-LFQLLWEX.js";

// eid.js
async function isEidSupported() {
  return "serial" in navigator;
}
async function readEidCard() {
  if (!("serial" in navigator)) {
    throw new Error("Web Serial API non support\xE9e. Utilisez Chrome ou Edge.");
  }
  let port;
  try {
    port = await navigator.serial.requestPort();
    await port.open({ baudRate: 115200 });
  } catch (err) {
    throw new Error("Impossible d'ouvrir le port s\xE9rie : " + err.message);
  }
  const writer = port.writable.getWriter();
  const reader = port.readable.getReader();
  try {
    const cmd = new Uint8Array([
      0,
      164,
      4,
      0,
      15,
      160,
      0,
      0,
      1,
      119,
      80,
      75,
      67,
      83,
      45,
      49,
      53
    ]);
    await writer.write(cmd);
    let buffer = new Uint8Array(0);
    const deadline = Date.now() + 5e3;
    while (Date.now() < deadline) {
      const { value, done } = await reader.read();
      if (done) break;
      const merged = new Uint8Array(buffer.length + value.length);
      merged.set(buffer);
      merged.set(value, buffer.length);
      buffer = merged;
      if (buffer.length >= 20) break;
    }
    return parseEidResponse(buffer);
  } finally {
    writer.releaseLock();
    reader.releaseLock();
    await port.close();
  }
}
async function readEidCardViaBridge() {
  try {
    const response = await fetch("http://localhost:13579/eid-data", {
      method: "GET",
      signal: AbortSignal.timeout(8e3)
    });
    if (!response.ok) throw new Error("Bridge non disponible");
    const data = await response.json();
    return {
      lastName: data.surname || data.lastName || "",
      firstName: data.givenName || data.firstName || "",
      birthDate: formatEidDate(data.dateOfBirth || ""),
      sex: mapEidSex(data.gender || data.sex || ""),
      nationalNumber: data.nationalNumber || data.rrn || "",
      nationality: data.nationality || "BE",
      address: {
        street: data.streetAndNumber || "",
        postalCode: data.zipCode || data.postalCode || "",
        locality: data.municipality || data.locality || ""
      }
    };
  } catch (err) {
    throw new Error("Le middleware eID n'est pas accessible : " + err.message);
  }
}
function formatEidDate(raw) {
  if (!raw) return "";
  const clean = String(raw).replace(/\D/g, "");
  if (clean.length === 8) {
    const dd = clean.slice(0, 2);
    const mm = clean.slice(2, 4);
    const yyyy = clean.slice(4, 8);
    const month = parseInt(mm, 10);
    if (month >= 1 && month <= 12) {
      return `${yyyy}-${mm}-${dd}`;
    }
    return `${clean.slice(0, 4)}-${clean.slice(4, 6)}-${clean.slice(6, 8)}`;
  }
  return "";
}
function mapEidSex(raw) {
  const s = String(raw || "").toUpperCase();
  if (s === "M" || s === "H" || s === "MALE" || s === "HOMME") return "Homme";
  if (s === "F" || s === "FEMALE" || s === "FEMME") return "Femme";
  return "Ind\xE9termin\xE9 / inconnu";
}
function parseEidResponse(buffer) {
  const text = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
  return {
    lastName: extractTlvField(text, "surname") || "Inconnu",
    firstName: extractTlvField(text, "givenName") || "Inconnu",
    birthDate: "",
    sex: "Ind\xE9termin\xE9 / inconnu",
    nationalNumber: "",
    nationality: "BE",
    address: { street: "", postalCode: "", locality: "" }
  };
}
function extractTlvField(text, field) {
  const idx = text.indexOf(field);
  if (idx < 0) return "";
  return text.slice(idx + field.length, idx + field.length + 40).replace(/[^\x20-\x7E\xC0-\xFF]/g, "").trim();
}
function injectEidButton(containerEl, onSuccess) {
  isEidSupported().then((supported) => {
    if (!supported) return;
    const section = document.createElement("div");
    section.className = "eid-section";
    section.innerHTML = `
      <div class="eid-icon">\u{1FAAA}</div>
      <div class="eid-text">
        <strong>Lecture carte eID</strong>
        <span>Remplissage automatique via carte d'identit\xE9 belge</span>
      </div>
      <button type="button" id="eidReadBtn" class="btn-secondary" style="min-width:130px">
        Lire la carte
      </button>
    `;
    containerEl.insertAdjacentElement("afterbegin", section);
    document.getElementById("eidReadBtn").addEventListener("click", async () => {
      const btn = document.getElementById("eidReadBtn");
      btn.disabled = true;
      btn.textContent = "Lecture\u2026";
      try {
        let data;
        try {
          data = await readEidCardViaBridge();
        } catch {
          data = await readEidCard();
        }
        onSuccess(data);
        btn.textContent = "\u2713 Lu";
        setTimeout(() => {
          btn.disabled = false;
          btn.textContent = "Lire la carte";
        }, 3e3);
      } catch (err) {
        alert("Erreur lecture eID : " + err.message);
        btn.disabled = false;
        btn.textContent = "Lire la carte";
      }
    });
  });
}

// toast.js
var container = null;
function ensureContainer() {
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
}
function showToast(message, type = "info", duration = 3500) {
  ensureContainer();
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  const icon = type === "success" ? "\u2713" : type === "error" ? "\u2715" : "\u2139";
  const marque = document.createElement("span");
  marque.style.fontWeight = "700";
  marque.style.fontSize = "16px";
  marque.textContent = icon;
  const texte = document.createElement("span");
  texte.textContent = message;
  toast.append(marque, texte);
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = "toastSlideIn 0.3s ease reverse";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// patient.js
function tick() {
  document.getElementById("time").textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
setInterval(tick, 1e3);
tick();
var session = await requireAuth();
if (!session) throw new Error("Auth requise");
var currentEventId = sessionStorage.getItem("currentEventId");
if (!currentEventId) {
  location.href = rt("evenements.html");
  throw new Error("Pr\xE9ventif requis");
}
var selectedPatientId = sessionStorage.getItem("selectedPatientId");
var unknownIdentityCheckbox = document.getElementById("unknownIdentityCheckbox");
var sex = document.getElementById("sex");
var triageCurrent = document.getElementById("triageCurrent");
var lastName = document.getElementById("lastName");
var firstName = document.getElementById("firstName");
var birthDate = document.getElementById("birthDate");
var ageDisplay = document.getElementById("ageDisplay");
var nationality = document.getElementById("nationality");
var nationalNumber = document.getElementById("nationalNumber");
var patientAddress = document.getElementById("patientAddress");
var postalCode = document.getElementById("postalCode");
var locality = document.getElementById("locality");
var pmaDisplay = document.getElementById("pmaDisplay");
var triageInitialDisplay = document.getElementById("triageInitialDisplay");
var pathology = document.getElementById("pathology");
var chiefComplaint = document.getElementById("chiefComplaint");
var clinicalNotes = document.getElementById("clinicalNotes");
var currentEvent = null;
var existingPatient = null;
var unknownIdentity = false;
function getCurrentPma() {
  return { id: sessionStorage.getItem("currentPmaId") || "", name: sessionStorage.getItem("currentPmaName") || "" };
}
function extractBirthDateFromBelgianNationalNumber(niss) {
  const digits = String(niss || "").replace(/\D/g, "");
  if (digits.length < 6) return "";
  const yy = parseInt(digits.slice(0, 2), 10);
  const mm = parseInt(digits.slice(2, 4), 10);
  const dd = parseInt(digits.slice(4, 6), 10);
  if (Number.isNaN(yy) || Number.isNaN(mm) || Number.isNaN(dd) || mm < 1 || mm > 12 || dd < 1 || dd > 31) return "";
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear() % 100;
  const fullYear = yy <= currentYear ? 2e3 + yy : 1900 + yy;
  return `${fullYear}-${String(mm).padStart(2, "0")}-${String(dd).padStart(2, "0")}`;
}
function calculateAge(dateString) {
  if (!dateString) return "";
  if (unknownIdentity && dateString === "1900-01-01") return "";
  const birth = new Date(dateString);
  const today = /* @__PURE__ */ new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || monthDiff === 0 && today.getDate() < birth.getDate()) age--;
  return Number.isNaN(age) || age < 0 ? "" : age;
}
function updateAgeField() {
  const age = calculateAge(birthDate.value);
  ageDisplay.value = age === "" ? "" : `${age} an(s)`;
}
function updatePostalRules() {
  const age = calculateAge(birthDate.value);
  const optional = unknownIdentity || age !== "" && age < 18;
  postalCode.required = !optional;
  locality.required = !optional;
}
function tryAutofillBirthDateFromNationalNumber() {
  if (nationality.value !== "BE" || unknownIdentity) return;
  const extracted = extractBirthDateFromBelgianNationalNumber(nationalNumber.value);
  if (extracted) {
    birthDate.value = extracted;
    updateAgeField();
    updatePostalRules();
  }
}
function applyUnknownIdentityState() {
  if (unknownIdentity) {
    lastName.value = "Doe";
    firstName.value = "Jane";
    birthDate.value = "1900-01-01";
    nationality.value = "";
    nationalNumber.value = "";
    sex.value = "Ind\xE9termin\xE9 / inconnu";
  }
  updateAgeField();
  updatePostalRules();
}
function validateBaseData() {
  if (!triageCurrent.value) {
    showToast("Le triage courant est obligatoire.", "error");
    return false;
  }
  if (!unknownIdentity && (!lastName.value.trim() || !firstName.value.trim() || !birthDate.value || !sex.value || !nationality.value)) {
    showToast("Les champs d'identit\xE9 obligatoires ne sont pas complets.", "error");
    return false;
  }
  return true;
}
function buildFiche() {
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const currentPma = getCurrentPma();
  const pathologie = pathology.value;
  return {
    pmaId: existingPatient?.pmaId || currentPma.id,
    pmaName: existingPatient?.pmaName || currentPma.name,
    timeIn: existingPatient?.timeIn || nowIso,
    timeOut: existingPatient?.timeOut || null,
    unknownIdentity,
    triageInitial: existingPatient?.triageInitial || triageCurrent.value,
    triageCurrent: triageCurrent.value,
    triageOut: existingPatient?.triageOut || "",
    destination: existingPatient?.destination || "",
    hospitalTransportMode: existingPatient?.hospitalTransportMode || "",
    hospitalName: existingPatient?.hospitalName || "",
    hospitalVectorName: existingPatient?.hospitalVectorName || "",
    mission112Number: existingPatient?.mission112Number || "",
    sex: sex.value,
    lastName: lastName.value.trim(),
    firstName: firstName.value.trim(),
    birthDate: birthDate.value,
    nationality: nationality.value,
    nationalNumber: nationalNumber.value.trim(),
    patientAddress: patientAddress.value.trim(),
    postalCode: postalCode.value.trim(),
    locality: locality.value.trim(),
    pathology: pathologie,
    chiefComplaint: chiefComplaint.value.trim(),
    clinicalNotes: clinicalNotes.value.trim(),
    secouristeBlock: { pathology: pathologie }
  };
}
function fillPatient(patient) {
  unknownIdentity = Boolean(patient.unknownIdentity);
  unknownIdentityCheckbox.checked = unknownIdentity;
  document.getElementById("patientCodeDisplay").textContent = patient.patientCode || "En attente";
  sex.value = patient.sex || "";
  triageCurrent.value = patient.triageCurrent || patient.triageInitial || "";
  lastName.value = patient.lastName || "";
  firstName.value = patient.firstName || "";
  birthDate.value = patient.birthDate || "";
  nationality.value = patient.nationality || "";
  nationalNumber.value = patient.nationalNumber || "";
  patientAddress.value = patient.patientAddress || "";
  postalCode.value = patient.postalCode || "";
  locality.value = patient.locality || "";
  pmaDisplay.value = patient.pmaName || "";
  triageInitialDisplay.value = patient.triageInitial || "";
  pathology.value = patient.pathology || "";
  chiefComplaint.value = patient.chiefComplaint || "";
  clinicalNotes.value = patient.clinicalNotes || "";
  updateAgeField();
  updatePostalRules();
}
function remplirEid(data) {
  unknownIdentity = false;
  unknownIdentityCheckbox.checked = false;
  if (data.lastName) lastName.value = data.lastName;
  if (data.firstName) firstName.value = data.firstName;
  if (data.birthDate) birthDate.value = data.birthDate;
  if (data.sex) sex.value = data.sex;
  if (data.nationalNumber) nationalNumber.value = data.nationalNumber;
  if (data.nationality) nationality.value = data.nationality;
  if (data.address) patientAddress.value = data.address;
  updateAgeField();
  updatePostalRules();
}
unknownIdentityCheckbox.addEventListener("change", () => {
  unknownIdentity = unknownIdentityCheckbox.checked;
  applyUnknownIdentityState();
});
birthDate.addEventListener("change", () => {
  updateAgeField();
  updatePostalRules();
});
nationality.addEventListener("change", tryAutofillBirthDateFromNationalNumber);
nationalNumber.addEventListener("input", tryAutofillBirthDateFromNationalNumber);
injectEidButton(document.getElementById("eidMount"), remplirEid);
document.getElementById("savePatientBtn").addEventListener("click", async () => {
  if (!validateBaseData()) return;
  const btn = document.getElementById("savePatientBtn");
  btn.disabled = true;
  try {
    await enregistrerPatient(currentEvent.id, buildFiche(), existingPatient?.id || null);
    sessionStorage.removeItem("selectedPatientId");
    location.href = rt("event.html");
  } catch (error) {
    btn.disabled = false;
    showToast(error.message || "L'enregistrement a \xE9chou\xE9.", "error");
  }
});
document.getElementById("backToEventBtn").addEventListener("click", () => {
  sessionStorage.removeItem("selectedPatientId");
  location.href = rt("event.html");
});
currentEvent = await lirePreventif(currentEventId);
if (!currentEvent) {
  location.href = rt("evenements.html");
  throw new Error("Pr\xE9ventif introuvable");
}
if (selectedPatientId) existingPatient = await lirePatient(selectedPatientId);
document.getElementById("patientModeLabel").textContent = existingPatient ? "Modification de fiche" : "Nouvelle fiche patient";
document.getElementById("eventContext").textContent = [currentEvent.description, currentEvent.commune, currentEvent.province || "province non renseign\xE9e"].filter(Boolean).join(" \xB7 ");
if (existingPatient) fillPatient(existingPatient);
else {
  const currentPma = getCurrentPma();
  pmaDisplay.value = currentPma.name || "Tout le pr\xE9ventif";
  document.getElementById("patientCodeDisplay").textContent = "Attribu\xE9 \xE0 l'enregistrement";
  updateAgeField();
  updatePostalRules();
}
