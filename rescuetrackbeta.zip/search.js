import {
  echapper,
  listerPatients,
  listerPreventifs
} from "./rt-KFLEYYHZ.js";
import {
  logout,
  requireAuth,
  rt
} from "./rt-LFQLLWEX.js";

// search.js
function tick() {
  document.getElementById("time").textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
setInterval(tick, 1e3);
tick();
var session = await requireAuth();
if (!session) throw new Error("Auth requise");
document.getElementById("connectedUser").textContent = `${session.profile.prenom || ""} ${session.profile.nom || ""}`.trim();
document.getElementById("backBtn").addEventListener("click", () => {
  location.href = rt("province.html");
});
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await logout();
  location.href = rt("index.html");
});
var fmt = (d) => {
  if (!d) return "\u2014";
  const [y, m, j] = String(d).split("-");
  return j && m && y ? `${j}-${m}-${y}` : d;
};
var sexe = (s) => s === "Homme" ? "\u2642" : s === "Femme" ? "\u2640" : "?";
var normaliser = (str) => String(str || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
var patients = [];
var preventifs = {};
function render() {
  const q = normaliser(document.getElementById("searchInput").value);
  const triage = document.getElementById("triageFilter").value;
  const eventId = document.getElementById("eventFilter2").value;
  let results = patients;
  if (eventId) results = results.filter((p) => p.eventId === eventId);
  if (triage) results = results.filter((p) => p.triageCurrent === triage);
  if (q.length >= 2) results = results.filter((p) => [p.lastName, p.firstName, p.patientCode, p.nationalNumber, p.birthDate, p.locality].map(normaliser).some((f) => f.includes(q)));
  results = [...results].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  document.getElementById("resultCount").textContent = results.length === 0 ? "Aucun r\xE9sultat." : results.length === 1 ? "1 fiche trouv\xE9e." : `${results.length} fiches trouv\xE9es.`;
  const tbody = document.getElementById("searchResultsBody");
  if (!results.length) {
    tbody.innerHTML = '<tr><td colspan="11" class="empty-row">Aucune fiche correspondante.</td></tr>';
    return;
  }
  tbody.innerHTML = results.map((p) => {
    const ev = preventifs[p.eventId];
    return `<tr>
      <td style="font-family:'DM Mono',monospace;font-size:12px">${echapper(p.patientCode || "\u2014")}</td>
      <td><strong>${echapper(p.lastName || "\u2014")}</strong></td>
      <td>${echapper(p.firstName || "\u2014")}</td>
      <td>${echapper(fmt(p.birthDate))}</td>
      <td>${sexe(p.sex)}</td>
      <td class="triage-${echapper(p.triageInitial)}">${echapper(p.triageInitial || "\u2014")}</td>
      <td class="triage-${echapper(p.triageCurrent)}">${echapper(p.triageCurrent || "\u2014")}</td>
      <td>${echapper(p.pmaName || "\u2014")}</td>
      <td style="font-size:12px">${echapper(ev?.description || "\u2014")}</td>
      <td>${p.timeOut ? "\u2713" : "\u2014"}</td>
      <td><button class="table-action-btn" data-patient="${echapper(p.id)}" data-event="${echapper(p.eventId)}">Ouvrir</button></td>
    </tr>`;
  }).join("");
  tbody.querySelectorAll("[data-patient]").forEach((btn) => btn.addEventListener("click", () => {
    sessionStorage.setItem("currentEventId", btn.dataset.event);
    sessionStorage.setItem("selectedPatientId", btn.dataset.patient);
    location.href = rt("patient.html");
  }));
}
var liste = await listerPreventifs();
liste.forEach((ev) => {
  preventifs[ev.id] = ev;
});
document.getElementById("eventFilter2").insertAdjacentHTML("beforeend", liste.map((ev) => `<option value="${echapper(ev.id)}">${echapper(fmt(ev.date))} \u2013 ${echapper(ev.description)}</option>`).join(""));
patients = await listerPatients();
document.getElementById("searchInput").addEventListener("input", render);
document.getElementById("triageFilter").addEventListener("change", render);
document.getElementById("eventFilter2").addEventListener("change", render);
render();
