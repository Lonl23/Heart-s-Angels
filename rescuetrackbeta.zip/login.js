import {
  apresConnexion,
  rt,
  supabase
} from "./rt-LFQLLWEX.js";

// login.js
var time = document.getElementById("time");
setInterval(() => {
  time.textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}, 1e3);
var params = new URLSearchParams(location.search);
var err = document.getElementById("loginError");
if (params.get("refus") === "1") {
  err.textContent = "Cet acc\xE8s est r\xE9serv\xE9 au personnel. Les dossiers de souhaits passent par Heart's Angels.";
}
var { data } = await supabase.auth.getSession();
if (data.session && params.get("refus") !== "1") location.replace(rt("province.html"));
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  err.textContent = "";
  const btn = document.getElementById("loginBtn");
  btn.disabled = true;
  const { error } = await supabase.auth.signInWithPassword({
    email: document.getElementById("email").value.trim(),
    password: document.getElementById("password").value
  });
  btn.disabled = false;
  if (error) {
    err.textContent = "Identifiants incorrects.";
    return;
  }
  location.href = apresConnexion(params.get("next"), location.pathname);
});
