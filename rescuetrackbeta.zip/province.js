import {
  logout,
  requireAuth,
  rt
} from "./rt-LFQLLWEX.js";

// province.js
function tick() {
  document.getElementById("time").textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
setInterval(tick, 1e3);
tick();
var session = await requireAuth();
if (!session) throw new Error("Auth requise");
document.getElementById("connectedUser").textContent = `${session.profile.prenom || ""} ${session.profile.nom || ""}`.trim();
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await logout();
  location.href = rt("index.html");
});
document.getElementById("dashboardBtn").addEventListener("click", () => {
  location.href = rt("dashboard.html");
});
document.getElementById("searchBtn").addEventListener("click", () => {
  location.href = rt("search.html");
});
var label = document.getElementById("selectedProvinceLabel");
var map = document.getElementById("svgMapContainer");
var libelle = (p) => !p ? "Aucune province s\xE9lectionn\xE9e" : p === "__aucune__" ? "Pr\xE9ventifs sans province renseign\xE9e" : p;
function choisir(province) {
  if (!province) return;
  map.querySelectorAll("[data-province]").forEach((el) => el.classList.toggle("active", el.dataset.province === province));
  sessionStorage.setItem("selectedProvince", province);
  label.textContent = libelle(province);
  location.href = rt("evenements.html");
}
var res = await fetch(rt("be.svg"));
map.innerHTML = await res.text();
map.querySelectorAll("[data-province]").forEach((shape) => {
  shape.classList.add("province-shape");
  shape.addEventListener("click", () => choisir(shape.dataset.province));
  shape.addEventListener("mouseenter", () => {
    label.textContent = libelle(shape.dataset.province);
  });
  shape.addEventListener("mouseleave", () => {
    label.textContent = libelle(sessionStorage.getItem("selectedProvince"));
  });
});
document.querySelectorAll(".province-list-btn").forEach((b) => b.addEventListener("click", () => choisir(b.dataset.province)));
label.textContent = libelle(sessionStorage.getItem("selectedProvince"));
