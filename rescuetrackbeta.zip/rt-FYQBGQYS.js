import {
  supabase
} from "./rt-LFQLLWEX.js";

// model.js
var LIBELLES_DISPOSITIF = {
  paps: "PAPS",
  ps: "Poste de secours",
  echo: "\xC9cho",
  pma_cat2: "PMA cat. 2",
  pma_cat1: "PMA cat. 1",
  pma_cat0: "PMA cat. 0",
  ambu_112: "Ambulance 112",
  ambu: "Ambulance"
};
var TRIAGES = ["U1", "U2", "U3H", "U3NH", "IMPLIQUE", "DCD"];
var TRIAGE_LIBELLES = {
  U1: "Urgence vitale",
  U2: "Urgence relative",
  U3H: "Non urgent, h\xF4pital",
  U3NH: "Non urgent, sans h\xF4pital",
  IMPLIQUE: "Impliqu\xE9",
  DCD: "D\xE9c\xE8s"
};
function estPreventif(activite) {
  if (!activite) return false;
  if (activite.type === "preventif") return true;
  if (activite.dispositif) return true;
  return Array.isArray(activite.dispositifs) && activite.dispositifs.length > 0;
}
function provinceDepuisCp(cp) {
  const m = String(cp || "").match(/(\d{4})/);
  if (!m) return "";
  const n = Number(m[1]);
  if (n >= 1e3 && n <= 1299) return "Bruxelles";
  if (n >= 1300 && n <= 1499) return "Brabant wallon";
  if (n >= 1500 && n <= 1999 || n >= 3e3 && n <= 3499) return "Brabant flamand";
  if (n >= 2e3 && n <= 2999) return "Anvers";
  if (n >= 3500 && n <= 3999) return "Limbourg";
  if (n >= 4e3 && n <= 4999) return "Li\xE8ge";
  if (n >= 5e3 && n <= 5999) return "Namur";
  if (n >= 6e3 && n <= 6599 || n >= 7e3 && n <= 7999) return "Hainaut";
  if (n >= 6600 && n <= 6999) return "Luxembourg";
  if (n >= 8e3 && n <= 8999) return "Flandre occidentale";
  if (n >= 9e3 && n <= 9999) return "Flandre orientale";
  return "";
}
function provinceDuneActivite(activite) {
  if (!activite) return "";
  return provinceDepuisCp(activite.adresse_cp) || provinceDepuisCp(activite.adresse) || provinceDepuisCp(activite.lieu) || "";
}
function unitesDuPreventif(activite) {
  const raw = Array.isArray(activite?.dispositifs) && activite.dispositifs.length ? activite.dispositifs : activite?.dispositif ? [activite.dispositif] : [];
  const totaux = {};
  raw.forEach((code) => {
    totaux[code] = (totaux[code] || 0) + 1;
  });
  const vus = {};
  return raw.map((code) => {
    vus[code] = (vus[code] || 0) + 1;
    const label = LIBELLES_DISPOSITIF[code] || code;
    const name = totaux[code] > 1 ? `${label} ${vus[code]}` : label;
    return { id: `${code}:${vus[code]}`, name, type: code };
  });
}
function jourBruxelles(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Brussels",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(d);
}
function heureBruxelles(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("fr-BE", {
    timeZone: "Europe/Brussels",
    hour: "2-digit",
    minute: "2-digit"
  }).format(d);
}
function statutPreventif(activite, maintenant = /* @__PURE__ */ new Date()) {
  const debut = activite?.debut ? new Date(activite.debut) : null;
  const fin = activite?.fin ? new Date(activite.fin) : null;
  if (debut && maintenant < debut) return "Pr\xE9vu";
  if (fin && maintenant > fin) return "Cl\xF4tur\xE9";
  return "Ouvert";
}
function echapper(valeur) {
  return String(valeur ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function ficheVersPatient(row) {
  const f = row?.fiche && typeof row.fiche === "object" ? row.fiche : {};
  const pathologie = f.pathology || f.secouristeBlock?.pathology || "";
  return {
    id: row.id,
    eventId: row.preventif_id,
    patientCode: row.code_patient || f.patientCode || "",
    patientSequence: row.numero_local,
    lastName: row.nom || f.lastName || "",
    firstName: row.prenom || f.firstName || "",
    birthDate: row.date_naissance || f.birthDate || "",
    sex: row.sexe || f.sex || "",
    triageInitial: row.triage_initial || f.triageInitial || "",
    triageCurrent: row.triage_actuel || f.triageCurrent || "",
    triageOut: row.triage_sortie || f.triageOut || "",
    timeIn: row.heure_entree || f.timeIn || null,
    timeOut: row.heure_sortie || f.timeOut || null,
    destination: row.destination || f.destination || "",
    hospitalTransportMode: f.hospitalTransportMode || "",
    hospitalName: f.hospitalName || "",
    hospitalVectorName: f.hospitalVectorName || "",
    mission112Number: f.mission112Number || "",
    pmaId: f.pmaId || "",
    pmaName: f.pmaName || "",
    unknownIdentity: Boolean(f.unknownIdentity),
    nationality: f.nationality || "",
    nationalNumber: f.nationalNumber || "",
    patientAddress: f.patientAddress || "",
    postalCode: f.postalCode || "",
    locality: f.locality || "",
    pathology: pathologie,
    chiefComplaint: f.chiefComplaint || "",
    clinicalNotes: f.clinicalNotes || "",
    secouristeBlock: { pathology: pathologie },
    createdAt: row.created_at || ""
  };
}

// data.js
function versEvenement(activite) {
  return {
    id: activite.id,
    description: activite.titre || "Pr\xE9ventif",
    date: jourBruxelles(activite.debut),
    debut: activite.debut,
    fin: activite.fin,
    province: provinceDuneActivite(activite),
    commune: activite.adresse_ville || activite.lieu || "",
    lieu: activite.lieu || "",
    status: statutPreventif(activite),
    numero: activite.numero,
    pmas: unitesDuPreventif(activite)
  };
}
async function listerPreventifs() {
  const { data, error } = await supabase.from("activites_secours").select("id,numero,titre,type,lieu,adresse,adresse_cp,adresse_ville,debut,fin,dispositifs,dispositif").order("debut", { ascending: false });
  if (error) throw error;
  return (data || []).filter(estPreventif).map(versEvenement);
}
async function lirePreventif(id) {
  const { data, error } = await supabase.from("activites_secours").select("id,numero,titre,type,lieu,adresse,adresse_cp,adresse_ville,debut,fin,dispositifs,dispositif").eq("id", id).maybeSingle();
  if (error) throw error;
  if (!data || !estPreventif(data)) return null;
  return versEvenement(data);
}
var COLONNES = "id,preventif_id,numero_local,code_patient,nom,prenom,date_naissance,sexe,triage_initial,triage_actuel,triage_sortie,heure_entree,heure_sortie,destination,fiche,created_at";
async function listerPatients(preventifId) {
  let req = supabase.from("rescuetrack_fiches").select(COLONNES).order("numero_local", { ascending: true });
  if (preventifId) req = req.eq("preventif_id", preventifId);
  const { data, error } = await req;
  if (error) throw error;
  return (data || []).map(ficheVersPatient);
}
async function lirePatient(id) {
  const { data, error } = await supabase.from("rescuetrack_fiches").select(COLONNES).eq("id", id).maybeSingle();
  if (error) throw error;
  return data ? ficheVersPatient(data) : null;
}
async function enregistrerPatient(preventifId, fiche, id) {
  const { data, error } = await supabase.rpc("rescuetrack_enregistrer_fiche", {
    p_id: id || null,
    p_preventif: preventifId,
    p_fiche: fiche
  });
  if (error) throw error;
  return data;
}
async function listerLogbook(preventifId) {
  const { data, error } = await supabase.from("rescuetrack_logbook").select("id,preventif_id,dispositif,texte,auteur,created_at").eq("preventif_id", preventifId).order("created_at", { ascending: false });
  if (error) throw error;
  return data || [];
}
async function ajouterLogbook(preventifId, texte, dispositif, auteur) {
  const { data: userData } = await supabase.auth.getUser();
  const { error } = await supabase.from("rescuetrack_logbook").insert({
    preventif_id: preventifId,
    texte,
    dispositif: dispositif || null,
    auteur: auteur || null,
    created_by: userData.user?.id
  });
  if (error) throw error;
}

export {
  TRIAGES,
  TRIAGE_LIBELLES,
  heureBruxelles,
  echapper,
  listerPreventifs,
  lirePreventif,
  listerPatients,
  lirePatient,
  enregistrerPatient,
  listerLogbook,
  ajouterLogbook
};
