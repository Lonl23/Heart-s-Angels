import {
  echapper,
  heureBruxelles,
  listerPreventifs
} from "./rt-FYQBGQYS.js";
import {
  logout,
  requireAuth,
  rt
} from "./rt-LFQLLWEX.js";

// evenements.js
function tick() {
  document.getElementById("time").textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
setInterval(tick, 1e3);
tick();
var session = await requireAuth();
if (!session) throw new Error("Auth requise");
var province = sessionStorage.getItem("selectedProvince");
if (!province) {
  location.href = rt("province.html");
  throw new Error("Province requise");
}
document.getElementById("connectedUser").textContent = `${session.profile.prenom || ""} ${session.profile.nom || ""} \xB7 ${province === "__aucune__" ? "sans province" : province}`;
document.getElementById("pageTitle").textContent = province === "__aucune__" ? "Pr\xE9ventifs sans province" : `Pr\xE9ventifs \xB7 ${province}`;
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await logout();
  location.href = rt("index.html");
});
document.getElementById("changeProvinceBtn").addEventListener("click", () => {
  location.href = rt("province.html");
});
var fmt = (d) => {
  if (!d) return "\u2014";
  const [y, m, j] = d.split("-");
  return `${j}-${m}-${y}`;
};
var body = document.getElementById("eventsTableBody");
try {
  const tous = await listerPreventifs();
  const events = tous.filter((ev) => province === "__aucune__" ? !ev.province : ev.province === province);
  if (!events.length) {
    body.innerHTML = '<tr><td colspan="6" class="empty-row">Aucun pr\xE9ventif pour cette s\xE9lection. Ils se cr\xE9ent dans app.heartsangels.be.</td></tr>';
  } else {
    body.innerHTML = events.map((ev) => `<tr><td><strong>${echapper(ev.description)}</strong></td><td>${fmt(ev.date)}${ev.debut ? ` \xB7 ${echapper(heureBruxelles(ev.debut))}` : ""}</td><td>${echapper(ev.commune || "\u2014")}</td><td>${echapper(ev.status)}</td><td>${ev.pmas.length}</td><td><button class="table-action-btn" data-id="${echapper(ev.id)}">Ouvrir</button></td></tr>`).join("");
    body.querySelectorAll("[data-id]").forEach((btn) => btn.addEventListener("click", () => {
      sessionStorage.setItem("currentEventId", btn.dataset.id);
      sessionStorage.removeItem("currentPmaId");
      sessionStorage.removeItem("currentPmaName");
      location.href = rt("event.html");
    }));
  }
} catch (error) {
  body.innerHTML = `<tr><td colspan="6" class="empty-row">${echapper(error.message)}</td></tr>`;
}
